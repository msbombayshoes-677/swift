import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AuthScreen } from './components/AuthScreen';
import { TraineeScreen } from './components/TraineeScreen';
import { InstructorScreen } from './components/InstructorScreen';
import { AdminScreen } from './components/AdminScreen';
import { ParentScreen } from './components/ParentScreen';
import { GraduationCap, RefreshCw, AlertTriangle } from 'lucide-react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error in App:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#FBFDF8] flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center shadow-lg mb-4 border border-amber-200">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">System Notice</h1>
          <p className="text-xs text-slate-600 font-medium max-w-md mt-2 leading-relaxed">
            The application encountered a transient runtime issue or network state sync error.
          </p>
          <p className="text-[11px] font-mono bg-slate-100 text-slate-700 p-3 rounded-lg mt-3 max-w-lg overflow-x-auto text-left border border-slate-200">
            {this.state.error?.message || 'Unknown render error'}
          </p>
          <button
            onClick={() => {
              this.setState({ hasError: false, error: null });
              window.location.reload();
            }}
            className="mt-6 inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-[#386B39] text-white font-bold text-xs shadow-md hover:bg-[#2e572f] transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Reload Portal</span>
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

const MainAppContent: React.FC = () => {
  const {
    userRole,
    currentUserProfile,
    currentAdmin,
    currentInstructor,
    currentTrainee,
    currentParentTrainee,
    isLoading,
    logout,
  } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FBFDF8] flex flex-col items-center justify-center p-4 text-center">
        <div className="w-20 h-20 rounded-3xl bg-[#386B39] text-white flex items-center justify-center shadow-xl shadow-[#386B39]/20 animate-pulse mb-4 border border-[#386B39]/30">
          <GraduationCap className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-xl font-black text-[#111F11] tracking-tight">ITI DigiDiary</h1>
        <p className="text-xs text-slate-500 font-semibold mt-1">Govt. ITI Anantnag</p>
        <div className="mt-6 flex items-center space-x-1.5 text-xs text-[#386B39] font-bold">
          <div className="w-2 h-2 rounded-full bg-[#386B39] animate-ping" />
          <span>Synchronizing Portal &amp; GPS Services...</span>
        </div>
      </div>
    );
  }

  // Active role profile determination
  const activeProfile =
    (userRole === 'admin' ? currentAdmin : null) ||
    (userRole === 'instructor' ? currentInstructor : null) ||
    (userRole === 'trainee' ? currentTrainee : null) ||
    (userRole === 'parent' ? currentParentTrainee : null) ||
    currentUserProfile;

  // Not logged in -> Show Role-Based AuthScreen
  if (!userRole || !activeProfile) {
    return <AuthScreen />;
  }

  // Render role-specific screen matching Android Jetpack Compose architecture
  switch (userRole) {
    case 'trainee':
      return <TraineeScreen trainee={(currentTrainee || activeProfile) as any} onLogout={logout} />;
    case 'instructor':
      return <InstructorScreen instructor={(currentInstructor || activeProfile) as any} onLogout={logout} />;
    case 'admin':
      return <AdminScreen admin={(currentAdmin || activeProfile) as any} onLogout={logout} />;
    case 'parent':
      return <ParentScreen trainee={(currentParentTrainee || activeProfile) as any} onLogout={logout} />;
    default:
      return <AuthScreen />;
  }
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <MainAppContent />
      </AuthProvider>
    </ErrorBoundary>
  );
}
