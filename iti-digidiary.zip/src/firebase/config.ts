// Import the functions you need from the SDKs you need
import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore, doc, getDocFromServer } from 'firebase/firestore';
import { getStorage, FirebaseStorage } from 'firebase/storage';
import appletConfig from '../../firebase-applet-config.json';

export interface FirebaseWebConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId?: string;
  measurementId?: string;
  firestoreDatabaseId?: string;
}

// Key for storing custom user-provided config in local storage
const STORAGE_KEY = 'iti_firebase_web_config';

// Primary provisioned Firebase configuration
export const firebaseConfig: FirebaseWebConfig = {
  apiKey: appletConfig.apiKey || "AIzaSyCQPmkNVh1BmaoQn3vBBlqunznXISVBn6s",
  authDomain: appletConfig.authDomain || "itianantnag-6d0cd.firebaseapp.com",
  projectId: appletConfig.projectId || "itianantnag-6d0cd",
  storageBucket: appletConfig.storageBucket || "itianantnag-6d0cd.firebasestorage.app",
  messagingSenderId: appletConfig.messagingSenderId || "194189224489",
  appId: appletConfig.appId || "1:194189224489:web:d0600729a07097f4c74a38",
  measurementId: appletConfig.measurementId || "G-CHK836Z08P",
  firestoreDatabaseId: appletConfig.firestoreDatabaseId || "",
};

// Default fallback config from user's Firebase project
const DEFAULT_PROJECT_CONFIG: FirebaseWebConfig = firebaseConfig;

// Default config from env variables or placeholder
export function getStoredFirebaseConfig(): FirebaseWebConfig | null {
  try {
    const custom = localStorage.getItem(STORAGE_KEY);
    if (custom) {
      const parsed = JSON.parse(custom);
      if (parsed.apiKey && parsed.projectId) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Could not read custom Firebase config from localStorage', e);
  }

  // Check env variables
  const env = (import.meta as any).env || {};
  const envConfig: FirebaseWebConfig = {
    apiKey: env.VITE_FIREBASE_API_KEY || DEFAULT_PROJECT_CONFIG.apiKey,
    authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || DEFAULT_PROJECT_CONFIG.authDomain,
    projectId: env.VITE_FIREBASE_PROJECT_ID || DEFAULT_PROJECT_CONFIG.projectId,
    storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || DEFAULT_PROJECT_CONFIG.storageBucket,
    messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || DEFAULT_PROJECT_CONFIG.messagingSenderId,
    appId: env.VITE_FIREBASE_APP_ID || DEFAULT_PROJECT_CONFIG.appId,
    measurementId: env.VITE_FIREBASE_MEASUREMENT_ID || DEFAULT_PROJECT_CONFIG.measurementId || '',
  };

  if (envConfig.apiKey && envConfig.projectId) {
    return envConfig;
  }

  return DEFAULT_PROJECT_CONFIG;
}

export function saveCustomFirebaseConfig(config: FirebaseWebConfig) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  // Reload to re-initialize with new credentials
  window.location.reload();
}

export function getFirebaseConfig(): FirebaseWebConfig {
  const cfg = getStoredFirebaseConfig();
  if (cfg) return cfg;
  return firebaseConfig;
}

export function clearCustomFirebaseConfig() {
  localStorage.removeItem(STORAGE_KEY);
  window.location.reload();
}

export function resetFirebaseConfig() {
  clearCustomFirebaseConfig();
}

// Initialize Firebase App
let firebaseApp: FirebaseApp | null = null;
let firebaseAuth: Auth | null = null;
let firebaseDb: Firestore | null = null;
let firebaseStorageInstance: FirebaseStorage | null = null;

const initialConfig = getStoredFirebaseConfig();

export function isFirebaseConfigured(): boolean {
  const cfg = getStoredFirebaseConfig();
  return Boolean(cfg && cfg.apiKey && cfg.projectId);
}

if (initialConfig && initialConfig.apiKey && initialConfig.projectId) {
  try {
    if (getApps().length === 0) {
      firebaseApp = initializeApp(initialConfig);
    } else {
      firebaseApp = getApp();
    }
    firebaseAuth = getAuth(firebaseApp);
    if (initialConfig.firestoreDatabaseId) {
      firebaseDb = getFirestore(firebaseApp, initialConfig.firestoreDatabaseId);
    } else {
      firebaseDb = getFirestore(firebaseApp);
    }

    try {
      firebaseStorageInstance = getStorage(firebaseApp);
    } catch {
      // Storage optional
    }
  } catch (err) {
    console.error('Firebase initialization error:', err);
  }
}

export const app = firebaseApp;
export const auth = firebaseAuth;
export const db = firebaseDb;
export const storage = firebaseStorageInstance;
export const analytics: null = null;

// Defensive error logger matching Skill guidelines
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  return errInfo;
}

export async function testFirestoreConnection(): Promise<{ success: boolean; message: string }> {
  if (!db) {
    return { success: false, message: 'Firebase is not initialized. Please configure API credentials.' };
  }
  try {
    await getDocFromServer(doc(db, 'institutes', 'default'));
    return { success: true, message: 'Connected to Firestore successfully.' };
  } catch (error: any) {
    if (error?.message?.includes('the client is offline')) {
      return { success: false, message: 'Client is offline. Please check internet connection or Firebase config.' };
    }
    // Permissions or doc missing is still proof of server reachability
    return { success: true, message: 'Firestore reachable.' };
  }
}
