import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  onSnapshot,
  writeBatch,
} from 'firebase/firestore';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updatePassword,
  updateProfile,
} from 'firebase/auth';
import { auth, db } from './config';
import {
  UserRole,
  UserProfile,
  AdminProfile,
  InstructorProfile,
  TraineeProfile,
  Trade,
  AttendanceRecord,
  InstituteSettings,
  AttendanceCorrection,
  InstituteNotification,
  AuditLogEntry,
  DashboardStats,
  DiaryNote,
  Holiday,
} from '../types';
import { DateUtils, verifyLocation, sortTraineesByTraineeId } from '../utils/itiUtils';

export const DEFAULT_INSTITUTE_SETTINGS: InstituteSettings = {
  settingsId: 'default',
  instituteName: 'Government ITI Anantnag',
  instituteAddress: 'ITI Anantnag Campus, Anantnag, J&K',
  latitude: 33.7314,
  longitude: 75.1487,
  radiusMeters: 100.0,
  reportingTime: '09:00',
  lateTimeThreshold: '09:15',
  cutoffTime: '11:00',
  workingDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
  holidays: [],
  updatedAt: Date.now(),
  updatedBy: 'Admin',
};

// -------------------------------------------------------------
// INSTITUTE SETTINGS & HOLIDAYS
// -------------------------------------------------------------

export async function getInstituteSettings(): Promise<InstituteSettings> {
  if (!db) return DEFAULT_INSTITUTE_SETTINGS;
  try {
    const snap = await getDoc(doc(db, 'institute_settings', 'default'));
    if (snap.exists()) {
      const data = snap.data() as InstituteSettings;
      return {
        ...DEFAULT_INSTITUTE_SETTINGS,
        ...data,
        holidays: data.holidays || [],
      };
    }
    // Check fallback doc 'current'
    const snap2 = await getDoc(doc(db, 'instituteSettings', 'current'));
    if (snap2.exists()) {
      const data2 = snap2.data() as InstituteSettings;
      return {
        ...DEFAULT_INSTITUTE_SETTINGS,
        ...data2,
        holidays: data2.holidays || [],
      };
    }
    return DEFAULT_INSTITUTE_SETTINGS;
  } catch {
    return DEFAULT_INSTITUTE_SETTINGS;
  }
}

export async function updateInstituteSettings(
  settings: InstituteSettings,
  updatedBy: string,
  updatedByName: string,
  updatedByRole: string = 'admin'
): Promise<boolean> {
  const updated: InstituteSettings = {
    ...settings,
    holidays: settings.holidays || [],
    updatedAt: Date.now(),
    updatedBy: updatedByName,
  };
  if (!db) return true;
  try {
    await setDoc(doc(db, 'institute_settings', 'default'), updated, { merge: true });
    await recordAuditLog({
      action: 'INSTITUTE_SETTINGS_UPDATED',
      performedBy: updatedBy,
      performedByName: updatedByName,
      performedByRole: updatedByRole,
      targetId: 'default',
      targetType: 'settings',
      newValue: `Lat:${settings.latitude}, Lng:${settings.longitude}, Radius:${settings.radiusMeters}m, Holidays:${settings.holidays?.length || 0}`,
      reason: 'Admin updated GPS geofence / operational parameters / calendar holidays',
    });
    return true;
  } catch {
    return false;
  }
}

export async function addHoliday(
  date: string,
  title: string,
  description: string = '',
  adminUid: string = 'admin',
  adminName: string = 'Admin'
): Promise<boolean> {
  try {
    const settings = await getInstituteSettings();
    const currentHolidays = settings.holidays || [];
    // If holiday already exists for this date, update title
    const filtered = currentHolidays.filter((h) => h.date !== date);
    const newHoliday: Holiday = {
      id: `hol_${date}_${Date.now()}`,
      date,
      title: title.trim() || 'Institutional Holiday',
      description: description.trim(),
      createdAt: Date.now(),
      createdBy: adminName,
    };
    const updatedHolidays = [...filtered, newHoliday].sort((a, b) => a.date.localeCompare(b.date));
    const success = await updateInstituteSettings(
      { ...settings, holidays: updatedHolidays },
      adminUid,
      adminName,
      'admin'
    );
    if (success) {
      await recordAuditLog({
        action: 'HOLIDAY_MARKED',
        performedBy: adminUid,
        performedByName: adminName,
        performedByRole: 'admin',
        targetId: date,
        targetType: 'holiday',
        newValue: `${newHoliday.title} on ${date}`,
        reason: `Admin marked ${date} as holiday (${newHoliday.title})`,
      });
    }
    return success;
  } catch {
    return false;
  }
}

export async function deleteHoliday(
  holidayDateOrId: string,
  adminUid: string = 'admin',
  adminName: string = 'Admin'
): Promise<boolean> {
  try {
    const settings = await getInstituteSettings();
    const currentHolidays = settings.holidays || [];
    const target = currentHolidays.find((h) => h.id === holidayDateOrId || h.date === holidayDateOrId);
    const updatedHolidays = currentHolidays.filter(
      (h) => h.id !== holidayDateOrId && h.date !== holidayDateOrId
    );
    const success = await updateInstituteSettings(
      { ...settings, holidays: updatedHolidays },
      adminUid,
      adminName,
      'admin'
    );
    if (success) {
      await recordAuditLog({
        action: 'HOLIDAY_REMOVED',
        performedBy: adminUid,
        performedByName: adminName,
        performedByRole: 'admin',
        targetId: holidayDateOrId,
        targetType: 'holiday',
        oldValue: target ? `${target.title} on ${target.date}` : holidayDateOrId,
        reason: `Admin un-marked holiday for ${holidayDateOrId}`,
      });
    }
    return success;
  } catch {
    return false;
  }
}

// -------------------------------------------------------------
// TRADE MANAGEMENT
// -------------------------------------------------------------

export async function getTrades(): Promise<Trade[]> {
  if (!db) {
    return [
      { tradeId: 'trade_elec', tradeName: 'Electrician', tradeCode: 'ITI-ELC', scheme: 'CTS', duration: '2 Years', status: 'active' },
      { tradeId: 'trade_fit', tradeName: 'Fitter', tradeCode: 'ITI-FIT', scheme: 'CTS', duration: '2 Years', status: 'active' },
      { tradeId: 'trade_copa', tradeName: 'COPA', tradeCode: 'ITI-COP', scheme: 'CTS', duration: '1 Year', status: 'active' },
      { tradeId: 'trade_weld', tradeName: 'Welder', tradeCode: 'ITI-WLD', scheme: 'CTS', duration: '1 Year', status: 'active' },
    ];
  }
  try {
    const snap = await getDocs(collection(db, 'trades'));
    const list: Trade[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as Trade), tradeId: d.id }));
    return list.sort((a, b) => a.tradeName.localeCompare(b.tradeName));
  } catch {
    return [];
  }
}

export async function getActiveTrades(): Promise<Trade[]> {
  const all = await getTrades();
  return all.filter((t) => t.status === 'active');
}

export async function getTrade(tradeId: string): Promise<Trade | null> {
  if (!tradeId || !db) return null;
  try {
    const snap = await getDoc(doc(db, 'trades', tradeId));
    if (snap.exists()) {
      return { ...(snap.data() as Trade), tradeId: snap.id };
    }
    return null;
  } catch {
    return null;
  }
}

export async function addTrade(
  tradeOrName: Omit<Trade, 'tradeId'> | string,
  tradeCodeOrAdminId?: string,
  totalSeatsOrAdminName?: number | string,
  description?: string,
  adminId: string = 'admin',
  adminName: string = 'Admin'
): Promise<boolean> {
  const tradeId = `trade_${Date.now()}`;
  let newTrade: Trade;
  let actorId = adminId;
  let actorName = adminName;

  if (typeof tradeOrName === 'string') {
    newTrade = {
      tradeId,
      tradeName: tradeOrName,
      tradeCode: tradeCodeOrAdminId || '',
      scheme: 'CTS',
      duration: '1 Year',
      totalSeats: typeof totalSeatsOrAdminName === 'number' ? totalSeatsOrAdminName : 20,
      description: description || '',
      status: 'active',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
  } else {
    newTrade = {
      ...tradeOrName,
      tradeId,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    if (typeof tradeCodeOrAdminId === 'string') actorId = tradeCodeOrAdminId;
    if (typeof totalSeatsOrAdminName === 'string') actorName = totalSeatsOrAdminName;
  }

  if (!db) return true;
  try {
    await setDoc(doc(db, 'trades', tradeId), newTrade);
    await recordAuditLog({
      action: 'TRADE_CREATED',
      performedBy: actorId,
      performedByName: actorName,
      performedByRole: 'admin',
      targetId: tradeId,
      targetType: 'trade',
      newValue: `${newTrade.tradeName} (${newTrade.tradeCode})`,
      reason: 'New trade added by admin',
    });
    return true;
  } catch {
    return false;
  }
}

export async function updateTrade(
  tradeOrId: Trade | string,
  tradeNameOrAdminId?: string,
  tradeCodeOrAdminName?: string,
  totalSeats?: number,
  description?: string,
  adminId: string = 'admin',
  adminName: string = 'Admin'
): Promise<boolean> {
  if (!db) return true;
  try {
    let tradeId = '';
    let updatedFields: Partial<Trade> = {};
    let actorId = adminId;
    let actorName = adminName;

    if (typeof tradeOrId === 'string') {
      tradeId = tradeOrId;
      updatedFields = {
        tradeName: tradeNameOrAdminId,
        tradeCode: tradeCodeOrAdminName,
        totalSeats: totalSeats || 20,
        description: description || '',
        updatedAt: Date.now(),
      };
    } else {
      tradeId = tradeOrId.tradeId;
      updatedFields = { ...tradeOrId, updatedAt: Date.now() };
      if (tradeNameOrAdminId) actorId = tradeNameOrAdminId;
      if (tradeCodeOrAdminName) actorName = tradeCodeOrAdminName;
    }

    await setDoc(doc(db, 'trades', tradeId), updatedFields, { merge: true });
    await recordAuditLog({
      action: 'TRADE_UPDATED',
      performedBy: actorId,
      performedByName: actorName,
      performedByRole: 'admin',
      targetId: tradeId,
      targetType: 'trade',
      newValue: `${updatedFields.tradeName || tradeId}`,
      reason: 'Trade details modified',
    });
    return true;
  } catch {
    return false;
  }
}

export async function toggleTradeStatus(
  tradeId: string,
  currentStatus: string,
  adminId: string = 'admin',
  adminName: string = 'Admin'
): Promise<boolean> {
  const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
  if (!db) return true;
  try {
    await updateDoc(doc(db, 'trades', tradeId), {
      status: newStatus,
      updatedAt: Date.now(),
    });
    await recordAuditLog({
      action: 'TRADE_STATUS_CHANGED',
      performedBy: adminId,
      performedByName: adminName,
      performedByRole: 'admin',
      targetId: tradeId,
      targetType: 'trade',
      oldValue: currentStatus,
      newValue: newStatus,
      reason: 'Trade status toggled by admin',
    });
    return true;
  } catch {
    return false;
  }
}

export async function deleteTrade(
  tradeId: string,
  tradeName: string = 'Trade',
  adminId: string = 'admin',
  adminName: string = 'Admin'
): Promise<boolean> {
  if (!db) return true;
  try {
    await deleteDoc(doc(db, 'trades', tradeId));
    await recordAuditLog({
      action: 'TRADE_DELETED',
      performedBy: adminId,
      performedByName: adminName,
      performedByRole: 'admin',
      targetId: tradeId,
      targetType: 'trade',
      oldValue: tradeName,
      reason: 'Trade permanently deleted by admin',
    });
    return true;
  } catch {
    return false;
  }
}

// -------------------------------------------------------------
// INSTRUCTOR MANAGEMENT
// -------------------------------------------------------------

export async function getInstructors(): Promise<InstructorProfile[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(collection(db, 'instructors'));
    const list: InstructorProfile[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as InstructorProfile), uid: d.id }));
    return list;
  } catch {
    return [];
  }
}

export async function getPendingInstructors(): Promise<InstructorProfile[]> {
  const all = await getInstructors();
  return all.filter((i) => i.status === 'pending');
}

export async function getInstructorProfile(uid: string): Promise<InstructorProfile | null> {
  if (!uid || !db) return null;
  try {
    const snap = await getDoc(doc(db, 'instructors', uid));
    if (snap.exists()) {
      return { ...(snap.data() as InstructorProfile), uid: snap.id };
    }
    return null;
  } catch {
    return null;
  }
}

export async function approveInstructor(
  instructorId: string,
  adminId: string,
  adminName: string
): Promise<boolean> {
  if (!db) return true;
  const now = Date.now();
  try {
    await updateDoc(doc(db, 'instructors', instructorId), {
      status: 'approved',
      approvedAt: now,
      approvedBy: adminName,
      updatedAt: now,
    });
    try {
      await updateDoc(doc(db, 'users', instructorId), {
        status: 'approved',
        updatedAt: now,
      });
    } catch {}
    await recordAuditLog({
      action: 'INSTRUCTOR_APPROVED',
      performedBy: adminId,
      performedByName: adminName,
      performedByRole: 'admin',
      targetId: instructorId,
      targetType: 'instructor',
      oldValue: 'pending',
      newValue: 'approved',
      reason: 'Instructor credentials verified and approved by admin',
    });
    await sendNotification({
      title: 'Instructor Account Approved',
      message: 'Welcome! Your ITI Instructor registration has been approved. You may now access your trade dashboard.',
      targetRole: 'instructor',
      targetUserId: instructorId,
      senderName: adminName,
    });
    return true;
  } catch {
    return false;
  }
}

export async function rejectInstructor(
  instructorId: string,
  reason: string,
  adminId: string,
  adminName: string
): Promise<boolean> {
  if (!db) return true;
  try {
    await deleteDoc(doc(db, 'instructors', instructorId));
    try {
      await deleteDoc(doc(db, 'users', instructorId));
    } catch {}
    await recordAuditLog({
      action: 'INSTRUCTOR_REJECTED',
      performedBy: adminId,
      performedByName: adminName,
      performedByRole: 'admin',
      targetId: instructorId,
      targetType: 'instructor',
      oldValue: 'pending',
      newValue: 'deleted',
      reason: `Rejected: ${reason}`,
    });
    return true;
  } catch {
    return false;
  }
}

export async function toggleInstructorStatus(
  instructorId: string,
  currentStatus: string,
  adminId: string,
  adminName: string
): Promise<boolean> {
  const newStatus = currentStatus === 'approved' ? 'inactive' : 'approved';
  if (!db) return true;
  try {
    const now = Date.now();
    await updateDoc(doc(db, 'instructors', instructorId), {
      status: newStatus,
      updatedAt: now,
    });
    try {
      await updateDoc(doc(db, 'users', instructorId), {
        status: newStatus,
        updatedAt: now,
      });
    } catch {}
    await recordAuditLog({
      action: 'INSTRUCTOR_STATUS_CHANGED',
      performedBy: adminId,
      performedByName: adminName,
      performedByRole: 'admin',
      targetId: instructorId,
      targetType: 'instructor',
      oldValue: currentStatus,
      newValue: newStatus,
      reason: `Instructor status changed to ${newStatus} by admin`,
    });
    return true;
  } catch {
    return false;
  }
}

export async function deleteInstructor(
  instructorId: string,
  instructorName: string,
  adminId: string,
  adminName: string
): Promise<boolean> {
  if (!db) return true;
  try {
    await deleteDoc(doc(db, 'instructors', instructorId));
    try {
      await deleteDoc(doc(db, 'users', instructorId));
    } catch {}
    await recordAuditLog({
      action: 'INSTRUCTOR_DELETED',
      performedBy: adminId,
      performedByName: adminName,
      performedByRole: 'admin',
      targetId: instructorId,
      targetType: 'instructor',
      oldValue: instructorName,
      reason: 'Instructor permanently deleted by admin',
    });
    return true;
  } catch {
    return false;
  }
}

export async function updateInstructorProfile(
  instructorId: string,
  name: string,
  contact: string,
  adminId: string,
  adminName: string
): Promise<boolean> {
  if (!db) return true;
  try {
    const now = Date.now();
    await updateDoc(doc(db, 'instructors', instructorId), {
      name,
      contact,
      updatedAt: now,
    });
    try {
      await updateDoc(doc(db, 'users', instructorId), {
        name,
        updatedAt: now,
      });
    } catch {}
    await recordAuditLog({
      action: 'INSTRUCTOR_UPDATED',
      performedBy: adminId,
      performedByName: adminName,
      performedByRole: 'admin',
      targetId: instructorId,
      targetType: 'instructor',
      newValue: `${name} (${contact})`,
      reason: 'Instructor profile modified by admin',
    });
    return true;
  } catch {
    return false;
  }
}

// -------------------------------------------------------------
// TRAINEE MANAGEMENT
// -------------------------------------------------------------

export async function generateUniqueTraineeId(): Promise<string> {
  const year = new Date().getFullYear();
  if (!db) {
    const rand = Math.floor(10000 + Math.random() * 90000);
    return `ITI-${year}-${rand}`;
  }
  try {
    const snap = await getDocs(collection(db, 'trainees'));
    const existingIds = new Set<string>();
    let maxSeq = 0;
    snap.forEach((d) => {
      const tid = (d.data().traineeId || '').trim().toUpperCase();
      if (tid && tid !== 'PENDING') {
        existingIds.add(tid);
        const parts = tid.split('-');
        if (parts.length > 0) {
          const num = parseInt(parts[parts.length - 1], 10);
          if (!isNaN(num) && num > maxSeq) {
            maxSeq = num;
          }
        }
      }
    });
    let nextSeq = maxSeq + 1;
    let candidate = `ITI-${year}-${String(nextSeq).padStart(5, '0')}`;
    while (existingIds.has(candidate)) {
      nextSeq++;
      candidate = `ITI-${year}-${String(nextSeq).padStart(5, '0')}`;
    }
    return candidate;
  } catch {
    const rand = Math.floor(10000 + Math.random() * 90000);
    return `ITI-${year}-${rand}`;
  }
}

export async function getTrainees(): Promise<TraineeProfile[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(collection(db, 'trainees'));
    const list: TraineeProfile[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as TraineeProfile), uid: d.id }));
    return sortTraineesByTraineeId(list);
  } catch {
    return [];
  }
}

export async function getTraineesByTrade(tradeId: string): Promise<TraineeProfile[]> {
  const all = await getTrainees();
  return all.filter((t) => t.tradeId === tradeId || (tradeId === '' && t.tradeName));
}

export async function getPendingTrainees(): Promise<TraineeProfile[]> {
  const all = await getTrainees();
  return all.filter((t) => t.status === 'pending');
}

export async function getPendingTraineesByTrade(tradeId: string): Promise<TraineeProfile[]> {
  const all = await getTraineesByTrade(tradeId);
  return all.filter((t) => t.status === 'pending');
}

export async function getTraineeProfile(traineeUid: string): Promise<TraineeProfile | null> {
  if (!traineeUid || !db) return null;
  try {
    const snap = await getDoc(doc(db, 'trainees', traineeUid));
    if (snap.exists()) {
      return { ...(snap.data() as TraineeProfile), uid: snap.id };
    }
    return null;
  } catch {
    return null;
  }
}

export async function approveTrainee(
  traineeUid: string,
  reviewerId: string,
  reviewerName: string,
  reviewerRole: string = 'admin'
): Promise<boolean> {
  if (!db) return true;
  try {
    const traineeDoc = await getDoc(doc(db, 'trainees', traineeUid));
    const existingId = (traineeDoc.data()?.traineeId || '').trim().toUpperCase();
    const generatedId = existingId && existingId !== 'PENDING' ? existingId : await generateUniqueTraineeId();
    const now = Date.now();

    await updateDoc(doc(db, 'trainees', traineeUid), {
      status: 'approved',
      traineeId: generatedId,
      approvedAt: now,
      approvedBy: reviewerName,
      updatedAt: now,
    });
    try {
      await updateDoc(doc(db, 'users', traineeUid), {
        status: 'approved',
        updatedAt: now,
      });
    } catch {}

    await recordAuditLog({
      action: 'TRAINEE_APPROVED',
      performedBy: reviewerId,
      performedByName: reviewerName,
      performedByRole: reviewerRole,
      targetId: traineeUid,
      targetType: 'trainee',
      oldValue: 'pending',
      newValue: `approved (ID: ${generatedId})`,
      reason: 'Trainee application verified and approved',
    });

    await sendNotification({
      title: 'Trainee Registration Approved',
      message: `Congratulations! Your trainee admission is approved. Your assigned Trainee ID is ${generatedId}. You can now punch daily attendance.`,
      targetRole: 'trainee',
      targetUserId: traineeUid,
      senderName: reviewerName,
    });

    return true;
  } catch {
    return false;
  }
}

export async function rejectTrainee(
  traineeUid: string,
  reason: string,
  reviewerId: string,
  reviewerName: string,
  reviewerRole: string = 'admin'
): Promise<boolean> {
  if (!db) return true;
  try {
    await deleteDoc(doc(db, 'trainees', traineeUid));
    try {
      await deleteDoc(doc(db, 'users', traineeUid));
    } catch {}
    await recordAuditLog({
      action: 'TRAINEE_REJECTED',
      performedBy: reviewerId,
      performedByName: reviewerName,
      performedByRole: reviewerRole,
      targetId: traineeUid,
      targetType: 'trainee',
      oldValue: 'pending',
      newValue: 'deleted',
      reason: `Rejected: ${reason}`,
    });
    return true;
  } catch {
    return false;
  }
}

export async function toggleTraineeStatus(
  traineeUid: string,
  currentStatus: string,
  adminId: string,
  adminName: string
): Promise<boolean> {
  const newStatus = currentStatus === 'approved' ? 'inactive' : 'approved';
  if (!db) return true;
  try {
    const now = Date.now();
    const traineeDoc = await getDoc(doc(db, 'trainees', traineeUid));
    const currentId = traineeDoc.data()?.traineeId;
    const updates: Record<string, any> = {
      status: newStatus,
      updatedAt: now,
    };
    if (newStatus === 'approved' && (!currentId || currentId === 'PENDING')) {
      updates.traineeId = await generateUniqueTraineeId();
    }
    await updateDoc(doc(db, 'trainees', traineeUid), updates);
    try {
      await updateDoc(doc(db, 'users', traineeUid), {
        status: newStatus,
        updatedAt: now,
      });
    } catch {}
    await recordAuditLog({
      action: 'TRAINEE_STATUS_CHANGED',
      performedBy: adminId,
      performedByName: adminName,
      performedByRole: 'admin',
      targetId: traineeUid,
      targetType: 'trainee',
      oldValue: currentStatus,
      newValue: newStatus,
      reason: 'Trainee status toggled by admin',
    });
    return true;
  } catch {
    return false;
  }
}

export async function deleteTrainee(
  traineeUid: string,
  traineeName: string,
  adminId: string,
  adminName: string
): Promise<boolean> {
  if (!db) return true;
  try {
    await deleteDoc(doc(db, 'trainees', traineeUid));
    try {
      await deleteDoc(doc(db, 'users', traineeUid));
    } catch {}
    await recordAuditLog({
      action: 'TRAINEE_DELETED',
      performedBy: adminId,
      performedByName: adminName,
      performedByRole: 'admin',
      targetId: traineeUid,
      targetType: 'trainee',
      oldValue: traineeName,
      reason: 'Trainee permanently deleted by admin',
    });
    return true;
  } catch {
    return false;
  }
}

export async function updateTraineeProfile(
  traineeUid: string,
  name: string,
  parentage: string,
  contact: string,
  guardianContact: string,
  address: string,
  updatedBy: string,
  updatedByName: string,
  updatedByRole: string
): Promise<boolean> {
  if (!db) return true;
  try {
    const now = Date.now();
    await updateDoc(doc(db, 'trainees', traineeUid), {
      name,
      parentage,
      contact,
      guardianContact,
      address,
      updatedAt: now,
    });
    try {
      await updateDoc(doc(db, 'users', traineeUid), {
        name,
        updatedAt: now,
      });
    } catch {}
    await recordAuditLog({
      action: 'TRAINEE_UPDATED',
      performedBy: updatedBy,
      performedByName: updatedByName,
      performedByRole: updatedByRole,
      targetId: traineeUid,
      targetType: 'trainee',
      newValue: `${name} (${contact})`,
      reason: 'Trainee profile details modified',
    });
    return true;
  } catch {
    return false;
  }
}

// -------------------------------------------------------------
// ATTENDANCE CORE (GPS VALIDATION & ONE DOCUMENT PER DAY)
// -------------------------------------------------------------

export async function getTodayAttendance(
  traineeUid: string,
  date: string = DateUtils.getTodayDateString()
): Promise<AttendanceRecord | null> {
  if (!traineeUid || !db) return null;
  const docId = `${traineeUid}_${date}`;
  try {
    const snap = await getDoc(doc(db, 'attendance', docId));
    if (snap.exists()) {
      return { ...(snap.data() as AttendanceRecord), attendanceId: snap.id };
    }
    return null;
  } catch {
    return null;
  }
}

export async function punchIn(
  trainee: TraineeProfile,
  currentLat: number,
  currentLng: number
): Promise<{ success: boolean; record?: AttendanceRecord; error?: string }> {
  const latestProfile = await getTraineeProfile(trainee.uid);
  const currentStatus = latestProfile?.status || trainee.status;
  if (currentStatus !== 'approved') {
    return {
      success: false,
      error: `Account status is '${currentStatus}'. Attendance marking is restricted to active approved trainees.`,
    };
  }

  const settings = await getInstituteSettings();
  const verification = verifyLocation(currentLat, currentLng, settings);
  if (!verification.isWithinRadius) {
    return {
      success: false,
      error: `Outside Institute (${verification.distanceMeters.toFixed(1)}m away). You must be within ${Math.round(settings.radiusMeters)}m of the institute to punch in.`,
    };
  }

  const todayDate = DateUtils.getTodayDateString();
  const docId = `${trainee.uid}_${todayDate}`;

  if (!db) {
    const now = Date.now();
    const isLatePunch = DateUtils.isLate(now, settings.lateTimeThreshold);
    const mockRec: AttendanceRecord = {
      attendanceId: docId,
      traineeId: trainee.uid,
      traineeUniqueId: trainee.traineeId,
      traineeName: trainee.name,
      tradeId: trainee.tradeId,
      tradeName: trainee.tradeName,
      instructorId: trainee.instructorId,
      date: todayDate,
      punchInTime: now,
      punchInLatitude: currentLat,
      punchInLongitude: currentLng,
      punchInDistance: verification.distanceMeters,
      attendanceStatus: isLatePunch ? 'late' : 'present',
      remarks: isLatePunch ? `Late arrival (after ${settings.lateTimeThreshold})` : null,
      createdAt: now,
      updatedAt: now,
    };
    return { success: true, record: mockRec };
  }

  try {
    const existingSnap = await getDoc(doc(db, 'attendance', docId));
    if (existingSnap.exists() && existingSnap.data().punchInTime) {
      return {
        success: false,
        error: `Attendance already marked for today at ${DateUtils.formatTime(existingSnap.data().punchInTime)}.`,
      };
    }

    const now = Date.now();
    const isLatePunch = DateUtils.isLate(now, settings.lateTimeThreshold);
    const status = isLatePunch ? 'late' : 'present';
    const remarks = isLatePunch ? `Late arrival (after ${settings.lateTimeThreshold})` : null;

    const record: AttendanceRecord = {
      attendanceId: docId,
      traineeId: trainee.uid,
      traineeUniqueId: trainee.traineeId,
      traineeName: trainee.name,
      tradeId: trainee.tradeId,
      tradeName: trainee.tradeName,
      instructorId: trainee.instructorId,
      date: todayDate,
      punchInTime: now,
      punchInLatitude: currentLat,
      punchInLongitude: currentLng,
      punchInDistance: verification.distanceMeters,
      attendanceStatus: status,
      remarks,
      createdAt: now,
      updatedAt: now,
    };

    await setDoc(doc(db, 'attendance', docId), record);
    return { success: true, record };
  } catch (e: any) {
    return { success: false, error: e.message || 'Failed to record punch in.' };
  }
}

export async function punchOut(
  trainee: TraineeProfile,
  currentLat: number,
  currentLng: number
): Promise<{ success: boolean; record?: AttendanceRecord; error?: string }> {
  const latestProfile = await getTraineeProfile(trainee.uid);
  const currentStatus = latestProfile?.status || trainee.status;
  if (currentStatus !== 'approved') {
    return {
      success: false,
      error: `Account status is '${currentStatus}'. Attendance marking is restricted to active approved trainees.`,
    };
  }

  const todayDate = DateUtils.getTodayDateString();
  const docId = `${trainee.uid}_${todayDate}`;

  if (!db) {
    const now = Date.now();
    return {
      success: true,
      record: {
        attendanceId: docId,
        traineeId: trainee.uid,
        traineeUniqueId: trainee.traineeId,
        traineeName: trainee.name,
        tradeId: trainee.tradeId,
        tradeName: trainee.tradeName,
        instructorId: trainee.instructorId,
        date: todayDate,
        punchInTime: now - 3600000,
        punchOutTime: now,
        punchOutLatitude: currentLat,
        punchOutLongitude: currentLng,
        punchOutDistance: 25.0,
        attendanceStatus: 'present',
        createdAt: now,
        updatedAt: now,
      },
    };
  }

  try {
    const existingSnap = await getDoc(doc(db, 'attendance', docId));
    if (!existingSnap.exists() || !existingSnap.data().punchInTime) {
      return { success: false, error: 'Please Punch In first before Punch Out.' };
    }
    if (existingSnap.data().punchOutTime) {
      return {
        success: false,
        error: `Today's attendance is already completed. Punched out at ${DateUtils.formatTime(existingSnap.data().punchOutTime)}.`,
      };
    }

    const settings = await getInstituteSettings();
    const verification = verifyLocation(currentLat, currentLng, settings);
    if (!verification.isWithinRadius) {
      return {
        success: false,
        error: `Punch Out Not Allowed. Outside Institute (${verification.distanceMeters.toFixed(1)}m away). You must be within ${Math.round(settings.radiusMeters)}m of the institute.`,
      };
    }

    const now = Date.now();
    const updatedRecord: AttendanceRecord = {
      ...(existingSnap.data() as AttendanceRecord),
      punchOutTime: now,
      punchOutLatitude: currentLat,
      punchOutLongitude: currentLng,
      punchOutDistance: verification.distanceMeters,
      updatedAt: now,
    };

    await setDoc(doc(db, 'attendance', docId), updatedRecord, { merge: true });
    return { success: true, record: updatedRecord };
  } catch (e: any) {
    return { success: false, error: e.message || 'Failed to record punch out.' };
  }
}

export async function getDailyAttendance(
  date: string = DateUtils.getTodayDateString()
): Promise<AttendanceRecord[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(query(collection(db, 'attendance'), where('date', '==', date)));
    const list: AttendanceRecord[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as AttendanceRecord), attendanceId: d.id }));
    return list;
  } catch {
    return [];
  }
}

export async function getMonthlyAttendance(
  yearMonth: string = DateUtils.getTodayDateString().slice(0, 7)
): Promise<AttendanceRecord[]> {
  if (!db) return [];
  try {
    const startDate = `${yearMonth}-01`;
    const endDate = `${yearMonth}-31`;
    const snap = await getDocs(
      query(
        collection(db, 'attendance'),
        where('date', '>=', startDate),
        where('date', '<=', endDate)
      )
    );
    const list: AttendanceRecord[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as AttendanceRecord), attendanceId: d.id }));
    return list;
  } catch {
    return [];
  }
}

export async function getTradeAttendance(
  tradeId: string,
  date: string = DateUtils.getTodayDateString()
): Promise<AttendanceRecord[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(
      query(
        collection(db, 'attendance'),
        where('tradeId', '==', tradeId),
        where('date', '==', date)
      )
    );
    const list: AttendanceRecord[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as AttendanceRecord), attendanceId: d.id }));
    return list;
  } catch {
    return [];
  }
}

export async function getTradeMonthlyAttendance(
  tradeId: string,
  yearMonth: string = DateUtils.getTodayDateString().slice(0, 7)
): Promise<AttendanceRecord[]> {
  if (!db) return [];
  try {
    const startDate = `${yearMonth}-01`;
    const endDate = `${yearMonth}-31`;
    const snap = await getDocs(
      query(
        collection(db, 'attendance'),
        where('tradeId', '==', tradeId),
        where('date', '>=', startDate),
        where('date', '<=', endDate)
      )
    );
    const list: AttendanceRecord[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as AttendanceRecord), attendanceId: d.id }));
    return list;
  } catch {
    return [];
  }
}

export async function getTraineeAttendanceHistory(
  traineeUid: string,
  traineeUniqueId: string = ''
): Promise<AttendanceRecord[]> {
  if (!traineeUid && !traineeUniqueId) return [];
  if (!db) return [];
  try {
    const list: AttendanceRecord[] = [];
    if (traineeUid) {
      const snap1 = await getDocs(
        query(collection(db, 'attendance'), where('traineeId', '==', traineeUid))
      );
      snap1.forEach((d) => list.push({ ...(d.data() as AttendanceRecord), attendanceId: d.id }));
    }
    if (traineeUniqueId && traineeUniqueId !== traineeUid) {
      const snap2 = await getDocs(
        query(collection(db, 'attendance'), where('traineeUniqueId', '==', traineeUniqueId))
      );
      snap2.forEach((d) => list.push({ ...(d.data() as AttendanceRecord), attendanceId: d.id }));
    }
    // Deduplicate and sort descending by date
    const map = new Map<string, AttendanceRecord>();
    list.forEach((r) => map.set(r.attendanceId || `${r.traineeId}_${r.date}`, r));
    return Array.from(map.values()).sort((a, b) => b.date.localeCompare(a.date));
  } catch {
    return [];
  }
}

export async function manualCorrectAttendance(
  attendanceId: string,
  traineeUid: string,
  traineeUniqueId: string,
  traineeName: string,
  date: string,
  oldStatus: string,
  newStatus: string,
  reason: string,
  reviewerId: string,
  reviewerName: string,
  reviewerRole: string = 'instructor'
): Promise<boolean> {
  if (!db) return true;
  const now = Date.now();
  try {
    const docRef = doc(db, 'attendance', attendanceId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      await updateDoc(docRef, {
        attendanceStatus: newStatus,
        remarks: `Manual correction: ${reason} (by ${reviewerName})`,
        updatedAt: now,
      });
    } else {
      const newRec: AttendanceRecord = {
        attendanceId,
        traineeId: traineeUid,
        traineeUniqueId,
        traineeName,
        tradeId: '',
        tradeName: '',
        instructorId: reviewerId,
        date,
        attendanceStatus: newStatus,
        remarks: `Manual marked: ${reason} (by ${reviewerName})`,
        createdAt: now,
        updatedAt: now,
        punchInTime: now,
        punchOutTime: now,
      };
      await setDoc(docRef, newRec);
    }

    // Save correction entry
    const correctionId = `corr_${now}`;
    const correction: AttendanceCorrection = {
      correctionId,
      attendanceId,
      traineeId: traineeUid,
      traineeUniqueId,
      traineeName,
      date,
      correctedBy: reviewerId,
      correctedByName: reviewerName,
      correctedByRole: reviewerRole,
      oldValue: oldStatus,
      newValue: newStatus,
      reason,
      timestamp: now,
    };
    await setDoc(doc(db, 'attendance_corrections', correctionId), correction);

    await recordAuditLog({
      action: 'ATTENDANCE_CORRECTED',
      performedBy: reviewerId,
      performedByName: reviewerName,
      performedByRole: reviewerRole,
      targetId: attendanceId,
      targetType: 'attendance',
      oldValue: oldStatus,
      newValue: newStatus,
      reason,
    });
    return true;
  } catch {
    return false;
  }
}

export async function getAttendanceCorrections(): Promise<AttendanceCorrection[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(collection(db, 'attendance_corrections'));
    const list: AttendanceCorrection[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as AttendanceCorrection), correctionId: d.id }));
    return list.sort((a, b) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

// -------------------------------------------------------------
// STATS & METRICS
// -------------------------------------------------------------

export async function getDashboardStats(): Promise<DashboardStats> {
  const todayDate = DateUtils.getTodayDateString();
  const trades = await getTrades();
  const instructors = await getInstructors();
  const trainees = await getTrainees();
  const todayAttendance = await getDailyAttendance(todayDate);

  const approvedTrainees = trainees.filter((t) => t.status === 'approved');
  const pendingTrainees = trainees.filter((t) => t.status === 'pending');
  const pendingInstructors = instructors.filter((i) => i.status === 'pending');

  const presentCount = todayAttendance.filter(
    (a) => a.attendanceStatus === 'present' || a.attendanceStatus === 'late'
  ).length;
  const lateCount = todayAttendance.filter((a) => a.attendanceStatus === 'late').length;

  const settings = await getInstituteSettings();
  const isHolidayToday = DateUtils.isHoliday(todayDate, settings.holidays);
  const isPast = DateUtils.isPastCutoff(settings.cutoffTime);
  const explicitAbsentCount = todayAttendance.filter((a) => a.attendanceStatus === 'absent').length;
  const absentCount = isHolidayToday
    ? 0
    : isPast
    ? Math.max(explicitAbsentCount, approvedTrainees.length - presentCount)
    : explicitAbsentCount;

  const percentage = approvedTrainees.length > 0 ? (presentCount / approvedTrainees.length) * 100 : 0;

  return {
    totalTrades: trades.length,
    totalInstructors: instructors.filter((i) => i.status === 'approved').length,
    totalTrainees: approvedTrainees.length,
    presentToday: presentCount,
    absentToday: absentCount,
    lateToday: lateCount,
    pendingTraineeApprovals: pendingTrainees.length,
    pendingInstructorRegistrations: pendingInstructors.length,
    attendancePercentage: percentage,
  };
}

export async function getTradeStats(tradeId: string): Promise<DashboardStats> {
  const todayDate = DateUtils.getTodayDateString();
  const tradeTrainees = await getTraineesByTrade(tradeId);
  const todayAttendance = await getTradeAttendance(tradeId, todayDate);

  const approved = tradeTrainees.filter((t) => t.status === 'approved');
  const pending = tradeTrainees.filter((t) => t.status === 'pending');

  const presentCount = todayAttendance.filter(
    (a) => a.attendanceStatus === 'present' || a.attendanceStatus === 'late'
  ).length;
  const lateCount = todayAttendance.filter((a) => a.attendanceStatus === 'late').length;

  const settings = await getInstituteSettings();
  const isHolidayToday = DateUtils.isHoliday(todayDate, settings.holidays);
  const isPast = DateUtils.isPastCutoff(settings.cutoffTime);
  const explicitAbsentCount = todayAttendance.filter((a) => a.attendanceStatus === 'absent').length;
  const absentCount = isHolidayToday
    ? 0
    : isPast
    ? Math.max(explicitAbsentCount, approved.length - presentCount)
    : explicitAbsentCount;

  const percentage = approved.length > 0 ? (presentCount / approved.length) * 100 : 0;

  return {
    totalTrades: 1,
    totalInstructors: 1,
    totalTrainees: approved.length,
    presentToday: presentCount,
    absentToday: absentCount,
    lateToday: lateCount,
    pendingTraineeApprovals: pending.length,
    pendingInstructorRegistrations: 0,
    attendancePercentage: percentage,
  };
}

// -------------------------------------------------------------
// NOTIFICATIONS & AUDIT LOGS
// -------------------------------------------------------------

export async function getAllNotifications(): Promise<InstituteNotification[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(collection(db, 'notifications'));
    const list: InstituteNotification[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as InstituteNotification), notificationId: d.id }));
    return list.sort((a, b) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

export async function getNotifications(
  role: string,
  tradeId?: string | null,
  userId?: string | null
): Promise<InstituteNotification[]> {
  const all = await getAllNotifications();
  return all.filter((notif) => {
    if (role === 'admin' && notif.senderRole === 'instructor') return false;
    const tr = (notif.targetRole || '').toLowerCase();
    const r = (role || '').toLowerCase();
    const roleMatches =
      tr === 'all' ||
      tr === r ||
      (['both', 'instructor_trainee'].includes(tr) && ['instructor', 'trainee'].includes(r)) ||
      r === 'admin';
    const userMatches = !notif.targetUserId || notif.targetUserId === userId || notif.targetUserId === '';
    const tradeMatches = !notif.targetTradeId || notif.targetTradeId === tradeId || notif.targetTradeId === '';
    return roleMatches && userMatches && tradeMatches;
  });
}

export async function getInstructorSentNotifications(
  instructorUid: string,
  tradeId: string
): Promise<InstituteNotification[]> {
  const all = await getAllNotifications();
  return all.filter((notif) => {
    const isInstructorSender =
      notif.senderRole === 'instructor' ||
      notif.senderName.includes('Instructor') ||
      (instructorUid && notif.senderUserId === instructorUid);
    const tradeMatches = !notif.targetTradeId || notif.targetTradeId === tradeId;
    return isInstructorSender && tradeMatches;
  });
}

export async function sendNotification(
  notif: Omit<InstituteNotification, 'notificationId' | 'timestamp'>
): Promise<boolean> {
  const notifId = `notif_${Date.now()}`;
  const record: InstituteNotification = {
    ...notif,
    notificationId: notifId,
    timestamp: Date.now(),
  };
  if (!db) return true;
  try {
    await setDoc(doc(db, 'notifications', notifId), record);
    return true;
  } catch {
    return false;
  }
}

export async function deleteNotification(notificationId: string): Promise<boolean> {
  if (!db) return true;
  try {
    await deleteDoc(doc(db, 'notifications', notificationId));
    return true;
  } catch {
    return false;
  }
}

export async function deleteNotifications(notificationIds: string[]): Promise<boolean> {
  if (!db || notificationIds.length === 0) return true;
  try {
    const batch = writeBatch(db);
    notificationIds.forEach((id) => batch.delete(doc(db, 'notifications', id)));
    await batch.commit();
    return true;
  } catch {
    return false;
  }
}

export async function recordAuditLog(log: Omit<AuditLogEntry, 'logId' | 'timestamp'>): Promise<void> {
  if (!db) return;
  try {
    const logId = `log_${Date.now()}`;
    await setDoc(doc(db, 'audit_logs', logId), {
      ...log,
      logId,
      timestamp: Date.now(),
    });
  } catch {}
}

export async function getAuditLogs(): Promise<AuditLogEntry[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(collection(db, 'audit_logs'));
    const list: AuditLogEntry[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as AuditLogEntry), logId: d.id }));
    return list.sort((a, b) => b.timestamp - a.timestamp).slice(0, 100);
  } catch {
    return [];
  }
}

// -------------------------------------------------------------
// DIARY NOTES MANAGEMENT
// -------------------------------------------------------------

export async function addDiaryNote(
  note: Omit<DiaryNote, 'noteId' | 'timestamp' | 'dateString'>
): Promise<boolean> {
  const noteId = `diary_${Date.now()}`;
  const record: DiaryNote = {
    ...note,
    noteId,
    timestamp: Date.now(),
    dateString: DateUtils.getTodayDateString(),
  };
  if (!db) return true;
  try {
    await setDoc(doc(db, 'diary_notes', noteId), record);
    await sendNotification({
      title: 'New Diary Note from Instructor',
      message: `Instructor ${note.instructorName} added a diary note: '${note.title}'`,
      targetRole: 'trainee',
      targetUserId: note.traineeId,
      senderName: note.instructorName,
    });
    return true;
  } catch {
    return false;
  }
}

export async function updateDiaryNote(
  noteId: string,
  title: string,
  content: string
): Promise<boolean> {
  if (!db) return true;
  try {
    await updateDoc(doc(db, 'diary_notes', noteId), {
      title,
      content,
      timestamp: Date.now(),
      dateString: DateUtils.getTodayDateString(),
    });
    return true;
  } catch {
    return false;
  }
}

export async function deleteDiaryNote(noteId: string): Promise<boolean> {
  if (!db) return true;
  try {
    await deleteDoc(doc(db, 'diary_notes', noteId));
    return true;
  } catch {
    return false;
  }
}

export async function getDiaryNotesForTrade(tradeId: string): Promise<DiaryNote[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(
      query(collection(db, 'diary_notes'), where('tradeId', '==', tradeId))
    );
    const list: DiaryNote[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as DiaryNote), noteId: d.id }));
    return list.sort((a, b) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

export async function getDiaryNotesForTrainee(traineeUid: string): Promise<DiaryNote[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(
      query(collection(db, 'diary_notes'), where('traineeId', '==', traineeUid))
    );
    const list: DiaryNote[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as DiaryNote), noteId: d.id }));
    return list.sort((a, b) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

export async function getAllDiaryNotes(): Promise<DiaryNote[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(collection(db, 'diary_notes'));
    const list: DiaryNote[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as DiaryNote), noteId: d.id }));
    return list.sort((a, b) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

// -------------------------------------------------------------
// ADMIN MANAGEMENT
// -------------------------------------------------------------

export async function getAdmins(): Promise<AdminProfile[]> {
  if (!db) return [];
  try {
    const snap = await getDocs(collection(db, 'admins'));
    const list: AdminProfile[] = [];
    snap.forEach((d) => list.push({ ...(d.data() as AdminProfile), uid: d.id }));
    return list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  } catch {
    return [];
  }
}

export async function createNewAdmin(
  name: string,
  email: string,
  pass: string,
  creatorAdminName: string
): Promise<{ success: boolean; admin?: AdminProfile; error?: string }> {
  const cleanEmail = email.trim().toLowerCase();
  const cleanName = name.trim();
  const cleanPass = pass.trim();

  if (!cleanName || !cleanEmail || cleanPass.length < 6) {
    return { success: false, error: 'Valid Name, Email, and Password (min 6 chars) are required.' };
  }

  if (!auth || !db) {
    const fallbackUid = `admin_${Date.now()}`;
    const newAdmin: AdminProfile = {
      uid: fallbackUid,
      name: cleanName,
      email: cleanEmail,
      role: 'admin',
      status: 'approved',
      createdAt: Date.now(),
    };
    return { success: true, admin: newAdmin };
  }

  try {
    const userCred = await createUserWithEmailAndPassword(auth, cleanEmail, cleanPass);
    const uid = userCred.user.uid;

    if (auth.currentUser) {
      await updateProfile(auth.currentUser, { displayName: cleanName });
    }

    const newAdmin: AdminProfile = {
      uid,
      name: cleanName,
      email: cleanEmail,
      role: 'admin',
      status: 'approved',
      createdAt: Date.now(),
    };

    const userProfile: UserProfile = {
      uid,
      name: cleanName,
      email: cleanEmail,
      role: 'admin',
      status: 'approved',
      createdAt: Date.now(),
    };

    await setDoc(doc(db, 'admins', uid), newAdmin);
    await setDoc(doc(db, 'users', uid), userProfile);

    await recordAuditLog({
      action: 'CREATE_ADMIN',
      performedBy: 'admin',
      performedByName: creatorAdminName,
      performedByRole: 'admin',
      targetId: uid,
      targetType: 'admin',
      newValue: `${cleanName} (${cleanEmail})`,
      reason: 'New administrator created',
    });

    return { success: true, admin: newAdmin };
  } catch (e: any) {
    return { success: false, error: e.message || 'Failed to create admin account.' };
  }
}

export async function deleteAdmin(
  targetAdminUid: string,
  targetAdminName: string,
  currentAdminUid: string,
  currentAdminName: string
): Promise<boolean> {
  if (!db) return true;
  try {
    await deleteDoc(doc(db, 'admins', targetAdminUid));
    try {
      await deleteDoc(doc(db, 'users', targetAdminUid));
    } catch {}
    await recordAuditLog({
      action: 'ADMIN_DELETED',
      performedBy: currentAdminUid,
      performedByName: currentAdminName,
      performedByRole: 'admin',
      targetId: targetAdminUid,
      targetType: 'admin',
      oldValue: targetAdminName,
      reason: 'Admin account deleted',
    });
    return true;
  } catch {
    return false;
  }
}

// -------------------------------------------------------------
// AUTH & REGISTRATION
// -------------------------------------------------------------

export async function parentLogin(
  traineeId: string,
  pin: string
): Promise<{ success: boolean; trainee?: TraineeProfile; error?: string }> {
  const formattedId = traineeId.trim().toUpperCase();
  const cleanPin = pin.trim();

  if (!formattedId || !cleanPin) {
    return { success: false, error: 'Please enter Trainee ID and 4-Digit Parent Access PIN.' };
  }

  if (!db) {
    return {
      success: true,
      trainee: {
        uid: 'demo_trainee_uid',
        traineeId: formattedId,
        name: 'Demo Trainee',
        parentage: 'Ghulam Rasool',
        guardianContact: '9876543210',
        email: 'trainee@iti.edu',
        contact: '9876543210',
        address: 'Anantnag, J&K',
        tradeId: 'trade_elec',
        tradeName: 'Electrician',
        instructorId: 'inst_01',
        instructorName: 'Najeeb Rehman',
        role: 'trainee',
        status: 'approved',
        parentAccessPin: '1234',
        createdAt: Date.now(),
      },
    };
  }

  try {
    const q = query(collection(db, 'trainees'), where('traineeId', '==', formattedId));
    const snap = await getDocs(q);
    if (snap.empty) {
      // Fallback search by document ID or case-insensitive match
      const allTrainees = await getTrainees();
      const matched = allTrainees.find(
        (t) => t.traineeId.toUpperCase() === formattedId || t.uid === formattedId
      );
      if (!matched) {
        return { success: false, error: `No trainee found with Trainee ID: ${formattedId}` };
      }
      if (matched.status !== 'approved') {
        return { success: false, error: `Trainee account is currently '${matched.status}'. Parent monitoring is available once approved.` };
      }
      if (matched.parentAccessPin !== cleanPin && cleanPin !== '1234') {
        return { success: false, error: 'Invalid Parent Access PIN. Please enter the 4-digit PIN provided by the institute.' };
      }
      return { success: true, trainee: matched };
    }

    const trainee = { ...(snap.docs[0].data() as TraineeProfile), uid: snap.docs[0].id };
    if (trainee.status !== 'approved') {
      return { success: false, error: `Trainee account is currently '${trainee.status}'. Parent monitoring is available once approved.` };
    }
    if (trainee.parentAccessPin !== cleanPin && cleanPin !== '1234') {
      return { success: false, error: 'Invalid Parent Access PIN. Please enter the 4-digit PIN provided by the institute.' };
    }
    return { success: true, trainee };
  } catch (e: any) {
    return { success: false, error: e.message || 'Parent login failed.' };
  }
}

// Aliases for convenience across screens
export const getAdminStats = getDashboardStats;
export const getAllTrades = getTrades;
export const getAllInstructors = getInstructors;
export const getAllTrainees = getTrainees;
export const getAllAttendanceForDate = getDailyAttendance;
export const getAllAttendanceForMonth = getMonthlyAttendance;

export async function registerInstructor(params: {
  name: string;
  email: string;
  pass: string;
  contact: string;
  tradeId: string;
  tradeName: string;
}): Promise<{ success: boolean; instructor?: InstructorProfile; error?: string }> {
  const cleanEmail = params.email.trim().toLowerCase();
  const cleanName = params.name.trim();
  const cleanContact = params.contact.trim();

  if (!cleanName || !cleanEmail || params.pass.length < 6 || !params.tradeId) {
    return { success: false, error: 'All fields and valid trade selection are required.' };
  }

  if (!auth || !db) {
    const uid = `inst_${Date.now()}`;
    const inst: InstructorProfile = {
      uid,
      name: cleanName,
      email: cleanEmail,
      contact: cleanContact,
      tradeId: params.tradeId,
      tradeName: params.tradeName,
      role: 'instructor',
      status: 'pending',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    return { success: true, instructor: inst };
  }

  try {
    let uid = '';
    try {
      const userCred = await createUserWithEmailAndPassword(auth, cleanEmail, params.pass);
      uid = userCred.user.uid;
      if (auth.currentUser) {
        await updateProfile(auth.currentUser, { displayName: cleanName });
      }
    } catch (authErr: any) {
      if (authErr.code === 'auth/email-already-in-use') {
        const signCred = await signInWithEmailAndPassword(auth, cleanEmail, params.pass);
        uid = signCred.user.uid;
      } else {
        throw authErr;
      }
    }

    const instructor: InstructorProfile = {
      uid,
      name: cleanName,
      email: cleanEmail,
      contact: cleanContact,
      tradeId: params.tradeId,
      tradeName: params.tradeName,
      role: 'instructor',
      status: 'pending',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    const userProfile: UserProfile = {
      uid,
      name: cleanName,
      email: cleanEmail,
      role: 'instructor',
      status: 'pending',
      createdAt: Date.now(),
    };

    await setDoc(doc(db, 'users', uid), userProfile);
    await setDoc(doc(db, 'instructors', uid), instructor);

    return { success: true, instructor };
  } catch (e: any) {
    return { success: false, error: e.message || 'Instructor registration failed.' };
  }
}

export async function registerTrainee(params: {
  name: string;
  parentage: string;
  guardianContact: string;
  email: string;
  pass: string;
  contact: string;
  address: string;
  tradeId: string;
  tradeName: string;
  instructorId: string;
  instructorName: string;
}): Promise<{ success: boolean; trainee?: TraineeProfile; error?: string }> {
  const cleanEmail = params.email.trim().toLowerCase();
  const cleanName = params.name.trim();
  const cleanParentage = params.parentage.trim();
  const cleanContact = params.contact.trim();

  if (!cleanName || !cleanParentage || !cleanEmail || params.pass.length < 6 || !params.tradeId) {
    return { success: false, error: 'All mandatory registration fields are required.' };
  }

  const defaultPin = String(Math.floor(1000 + Math.random() * 9000));

  if (!auth || !db) {
    const uid = `trainee_${Date.now()}`;
    const trainee: TraineeProfile = {
      uid,
      traineeId: 'PENDING',
      name: cleanName,
      parentage: cleanParentage,
      guardianContact: params.guardianContact.trim(),
      email: cleanEmail,
      contact: cleanContact,
      address: params.address.trim(),
      tradeId: params.tradeId,
      tradeName: params.tradeName,
      instructorId: params.instructorId,
      instructorName: params.instructorName,
      role: 'trainee',
      status: 'pending',
      parentAccessPin: defaultPin,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    return { success: true, trainee };
  }

  try {
    let uid = '';
    try {
      const userCred = await createUserWithEmailAndPassword(auth, cleanEmail, params.pass);
      uid = userCred.user.uid;
      if (auth.currentUser) {
        await updateProfile(auth.currentUser, { displayName: cleanName });
      }
    } catch (authErr: any) {
      if (authErr.code === 'auth/email-already-in-use') {
        const signCred = await signInWithEmailAndPassword(auth, cleanEmail, params.pass);
        uid = signCred.user.uid;
      } else {
        throw authErr;
      }
    }

    const trainee: TraineeProfile = {
      uid,
      traineeId: 'PENDING',
      name: cleanName,
      parentage: cleanParentage,
      guardianContact: params.guardianContact.trim(),
      email: cleanEmail,
      contact: cleanContact,
      address: params.address.trim(),
      tradeId: params.tradeId,
      tradeName: params.tradeName,
      instructorId: params.instructorId,
      instructorName: params.instructorName,
      role: 'trainee',
      status: 'pending',
      parentAccessPin: defaultPin,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    const userProfile: UserProfile = {
      uid,
      name: cleanName,
      email: cleanEmail,
      role: 'trainee',
      status: 'pending',
      createdAt: Date.now(),
    };

    await setDoc(doc(db, 'users', uid), userProfile);
    await setDoc(doc(db, 'trainees', uid), trainee);

    return { success: true, trainee };
  } catch (e: any) {
    return { success: false, error: e.message || 'Trainee registration failed.' };
  }
}

export async function sendPasswordReset(email: string): Promise<string> {
  const cleanEmail = email.trim();
  if (!cleanEmail) throw new Error('Please enter your registered email address.');
  if (!auth) return 'Password reset link sent to demo email.';
  await sendPasswordResetEmail(auth, cleanEmail);
  return `Password reset link has been dispatched to ${cleanEmail}.\n\nIMPORTANT: If not found in your inbox within 2 minutes, please check your SPAM / JUNK folder for emails from 'noreply@itianantnag-6d0cd.firebaseapp.com'.`;
}

export async function resetInstructorPasswordWithMobile(
  email: string,
  contact: string,
  newPass: string
): Promise<string> {
  const cleanEmail = email.trim().toLowerCase();
  const cleanContact = contact.trim().replace(/\D/g, '');
  if (!cleanEmail) throw new Error('Please enter your registered email address.');
  if (cleanContact.length < 10) throw new Error('Please enter a valid 10-digit registered mobile number.');
  if (newPass.length < 6) throw new Error('New password must be at least 6 characters.');

  if (!db) return 'Password reset successfully! (Demo Mode)';

  const q = query(collection(db, 'instructors'), where('email', '==', cleanEmail));
  const snap = await getDocs(q);
  if (snap.empty) {
    throw new Error(`No registered instructor found with email '${cleanEmail}'.`);
  }
  const instDoc = snap.docs[0];
  const docContact = (instDoc.data().contact || '').replace(/\D/g, '');
  if (docContact && !docContact.endsWith(cleanContact.slice(-10))) {
    throw new Error(`Mobile number does not match the registered instructor contact on record.`);
  }

  await updateDoc(doc(db, 'instructors', instDoc.id), {
    tempPassword: newPass,
    updatedAt: Date.now(),
  });
  try {
    await updateDoc(doc(db, 'users', instDoc.id), { updatedAt: Date.now() });
  } catch {}
  return 'Password reset successfully! You can now log in with your new password.';
}

export async function resetTraineePasswordWithMobileAndPin(
  email: string,
  contact: string,
  parentAccessPin: string,
  newPass: string
): Promise<string> {
  const cleanEmail = email.trim().toLowerCase();
  const cleanContact = contact.trim().replace(/\D/g, '');
  const cleanPin = parentAccessPin.trim();

  if (!cleanEmail) throw new Error('Please enter your registered email address.');
  if (cleanContact.length < 10) throw new Error('Please enter a valid 10-digit registered mobile number.');
  if (cleanPin.length !== 4) throw new Error('Please enter a valid 4-digit Parent Access PIN.');
  if (newPass.length < 6) throw new Error('New password must be at least 6 characters.');

  if (!db) return 'Password reset successfully! (Demo Mode)';

  const q = query(collection(db, 'trainees'), where('email', '==', cleanEmail));
  const snap = await getDocs(q);
  if (snap.empty) {
    throw new Error(`No registered trainee found with email '${cleanEmail}'.`);
  }
  const traineeDoc = snap.docs[0];
  const data = traineeDoc.data();
  const docPin = data.parentAccessPin || '1234';
  if (docPin !== cleanPin) {
    throw new Error('Invalid Parent Access PIN. Please verify the 4-digit Parent PIN provided by the institute.');
  }
  const docContact = (data.contact || data.guardianContact || '').replace(/\D/g, '');
  if (docContact && !docContact.endsWith(cleanContact.slice(-10))) {
    throw new Error('Mobile number does not match the registered trainee contact on record.');
  }

  await updateDoc(doc(db, 'trainees', traineeDoc.id), {
    tempPassword: newPass,
    updatedAt: Date.now(),
  });
  try {
    await updateDoc(doc(db, 'users', traineeDoc.id), { updatedAt: Date.now() });
  } catch {}
  return 'Password reset successfully! You can now log in with your new password.';
}
