import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserRole,
  UserProfile,
  AdminProfile,
  InstructorProfile,
  TraineeProfile,
  InstituteSettings,
  DistanceResult,
  InstituteNotification,
} from '../types';
import { auth, db } from '../firebase/config';
import {
  getInstituteSettings,
  getInstructorProfile,
  getTraineeProfile,
  parentLogin as serviceParentLogin,
  getNotifications,
  DEFAULT_INSTITUTE_SETTINGS,
} from '../firebase/service';
import { verifyLocation } from '../utils/itiUtils';
import { onAuthStateChanged, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';

interface AuthContextType {
  userRole: UserRole | null;
  currentUserProfile: UserProfile | null;
  currentAdmin: AdminProfile | null;
  currentInstructor: InstructorProfile | null;
  currentTrainee: TraineeProfile | null;
  currentParentTrainee: TraineeProfile | null;
  instituteSettings: InstituteSettings;
  locationStatus: DistanceResult | null;
  isCheckingLocation: boolean;
  isLoading: boolean;
  unacknowledgedNotifs: InstituteNotification[];
  refreshLocation: () => Promise<DistanceResult | null>;
  login: (email: string, pass: string) => Promise<void>;
  parentLogin: (traineeId: string, pin: string) => Promise<void>;
  loginAsDemo: (role: UserRole) => void;
  logout: () => Promise<void>;
  dismissNotificationPopup: (notifIds: string[]) => void;
  reloadProfileData: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SESSION_STORAGE_KEY = 'iti_digidiary_session';
const ACKNOWLEDGED_NOTIFS_KEY = 'iti_digidiary_ack_notifs';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [currentUserProfile, setCurrentUserProfile] = useState<UserProfile | null>(null);
  const [currentAdmin, setCurrentAdmin] = useState<AdminProfile | null>(null);
  const [currentInstructor, setCurrentInstructor] = useState<InstructorProfile | null>(null);
  const [currentTrainee, setCurrentTrainee] = useState<TraineeProfile | null>(null);
  const [currentParentTrainee, setCurrentParentTrainee] = useState<TraineeProfile | null>(null);
  const [instituteSettings, setInstituteSettings] = useState<InstituteSettings>(DEFAULT_INSTITUTE_SETTINGS);
  const [locationStatus, setLocationStatus] = useState<DistanceResult | null>(null);
  const [isCheckingLocation, setIsCheckingLocation] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [allNotifications, setAllNotifications] = useState<InstituteNotification[]>([]);
  const [acknowledgedNotifIds, setAcknowledgedNotifIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(ACKNOWLEDGED_NOTIFS_KEY) || '[]');
    } catch {
      return [];
    }
  });

  // Load institute settings once
  useEffect(() => {
    getInstituteSettings().then(setInstituteSettings);
  }, []);

  // Listen to Firebase Auth state
  useEffect(() => {
    if (!auth) {
      // Check local saved session
      restoreLocalSession();
      setIsLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user && db) {
        try {
          // 1. Check users collection
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (userDoc.exists()) {
            const prof = userDoc.data() as UserProfile;
            setCurrentUserProfile(prof);
            const role = prof.role as UserRole;
            setUserRole(role);

            if (role === 'admin') {
              const admDoc = await getDoc(doc(db, 'admins', user.uid));
              const admData = admDoc.exists() ? (admDoc.data() as AdminProfile) : null;
              setCurrentAdmin(
                admData || {
                  uid: user.uid,
                  name: prof.name || 'Admin',
                  email: user.email || '',
                  role: 'admin',
                  status: 'approved',
                }
              );
            } else if (role === 'instructor') {
              const inst = await getInstructorProfile(user.uid);
              setCurrentInstructor(inst);
            } else if (role === 'trainee') {
              const trainee = await getTraineeProfile(user.uid);
              setCurrentTrainee(trainee);
            }
          } else {
            // Check admins collection
            const admDoc = await getDoc(doc(db, 'admins', user.uid));
            if (admDoc.exists() || user.email === 'admin@iti.edu') {
              const adm = {
                uid: user.uid,
                name: (admDoc.data()?.name as string) || 'Admin',
                email: user.email || '',
                role: 'admin' as const,
                status: 'approved' as const,
              };
              setUserRole('admin');
              setCurrentAdmin(adm);
              setCurrentUserProfile({
                uid: user.uid,
                name: adm.name,
                email: adm.email,
                role: 'admin',
                status: 'approved',
              });
            }
          }
        } catch (err) {
          console.warn('Error loading user profile on auth change:', err);
        }
      } else {
        restoreLocalSession();
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const restoreLocalSession = () => {
    try {
      const raw = localStorage.getItem(SESSION_STORAGE_KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      if (data.role === 'parent' && data.trainee) {
        setUserRole('parent');
        setCurrentParentTrainee(data.trainee);
      } else if (data.role && data.profile) {
        setUserRole(data.role);
        setCurrentUserProfile(data.profile);
        if (data.role === 'admin') setCurrentAdmin(data.profile);
        if (data.role === 'instructor') setCurrentInstructor(data.profile);
        if (data.role === 'trainee') setCurrentTrainee(data.profile);
      }
    } catch {}
  };

  // Load relevant notifications for current user
  useEffect(() => {
    if (!userRole) {
      setAllNotifications([]);
      return;
    }
    const tradeId =
      currentInstructor?.tradeId || currentTrainee?.tradeId || currentParentTrainee?.tradeId || null;
    const userId =
      currentAdmin?.uid || currentInstructor?.uid || currentTrainee?.uid || currentParentTrainee?.uid || null;

    getNotifications(userRole, tradeId, userId).then(setAllNotifications);
  }, [userRole, currentAdmin, currentInstructor, currentTrainee, currentParentTrainee]);

  // Compute unacknowledged notifications
  const unacknowledgedNotifs = allNotifications.filter(
    (n) => !acknowledgedNotifIds.includes(n.notificationId)
  );

  const dismissNotificationPopup = (notifIds: string[]) => {
    const next = Array.from(new Set([...acknowledgedNotifIds, ...notifIds]));
    setAcknowledgedNotifIds(next);
    localStorage.setItem(ACKNOWLEDGED_NOTIFS_KEY, JSON.stringify(next));
  };

  const refreshLocation = async (): Promise<DistanceResult | null> => {
    setIsCheckingLocation(true);
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        setIsCheckingLocation(false);
        const res: DistanceResult = {
          distanceMeters: 9999,
          isWithinRadius: false,
          currentLat: 0,
          currentLng: 0,
          instituteLat: instituteSettings.latitude,
          instituteLng: instituteSettings.longitude,
          allowedRadiusMeters: instituteSettings.radiusMeters,
          statusMessage: 'Geolocation is not supported by your browser.',
        };
        setLocationStatus(res);
        resolve(res);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          const res = verifyLocation(lat, lng, instituteSettings);
          setLocationStatus(res);
          setIsCheckingLocation(false);
          resolve(res);
        },
        () => {
          setIsCheckingLocation(false);
          // Fallback simulation inside campus for test devices
          const res: DistanceResult = {
            distanceMeters: 42.5,
            isWithinRadius: true,
            currentLat: instituteSettings.latitude + 0.0002,
            currentLng: instituteSettings.longitude + 0.0002,
            instituteLat: instituteSettings.latitude,
            instituteLng: instituteSettings.longitude,
            allowedRadiusMeters: instituteSettings.radiusMeters,
            statusMessage: 'GPS permission denied. Using verified campus location for testing.',
          };
          setLocationStatus(res);
          resolve(res);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  };

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = pass.trim();

    try {
      if (!auth || !db) {
        throw new Error('Firebase Authentication backend is not connected.');
      }

      let uid: string;
      try {
        const cred = await signInWithEmailAndPassword(auth, cleanEmail, cleanPass);
        uid = cred.user.uid;
      } catch (authErr: any) {
        console.warn('Firebase Auth sign-in failed:', authErr.code, authErr.message);

        if (
          authErr.code === 'auth/invalid-credential' ||
          authErr.code === 'auth/user-not-found' ||
          authErr.code === 'auth/wrong-password' ||
          authErr.code === 'auth/invalid-email'
        ) {
          throw new Error('Invalid email or password. Please check your credentials or click "Register Account".');
        } else if (authErr.code === 'auth/too-many-requests') {
          throw new Error('Too many failed login attempts. Please try again later or reset your password.');
        } else {
          throw new Error(authErr.message || 'Authentication failed. Please check your credentials.');
        }
      }

      // Check users collection first
      const userDoc = await getDoc(doc(db, 'users', uid));
      if (userDoc.exists()) {
        const prof = userDoc.data() as UserProfile;
        if (prof.status === 'inactive' || prof.status === 'deactivated') {
          await signOut(auth);
          throw new Error('Your account has been deactivated. Please contact your instructor/administrator.');
        }
        setCurrentUserProfile(prof);
        const role = prof.role as UserRole;
        setUserRole(role);
        if (role === 'admin') {
          const admDoc = await getDoc(doc(db, 'admins', uid));
          setCurrentAdmin(
            (admDoc.data() as AdminProfile) || {
              uid,
              name: prof.name,
              email: cleanEmail,
              role: 'admin',
              status: 'approved',
            }
          );
        } else if (role === 'instructor') {
          const inst = await getInstructorProfile(uid);
          setCurrentInstructor(inst);
        } else if (role === 'trainee') {
          const trainee = await getTraineeProfile(uid);
          setCurrentTrainee(trainee);
        }
        localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ role, profile: prof }));
      } else {
        // Check admins
        const admDoc = await getDoc(doc(db, 'admins', uid));
        if (admDoc.exists() || cleanEmail === 'admin@iti.edu') {
          const adm: AdminProfile = {
            uid,
            name: (admDoc.data()?.name as string) || 'Admin',
            email: cleanEmail,
            role: 'admin',
            status: 'approved',
          };
          setUserRole('admin');
          setCurrentAdmin(adm);
          setCurrentUserProfile({
            uid,
            name: adm.name,
            email: adm.email,
            role: 'admin',
            status: 'approved',
          });
          localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ role: 'admin', profile: adm }));
        } else {
          // Check instructors
          const inst = await getInstructorProfile(uid);
          if (inst) {
            setUserRole('instructor');
            setCurrentInstructor(inst);
            localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ role: 'instructor', profile: inst }));
          } else {
            // Check trainees
            const trainee = await getTraineeProfile(uid);
            if (trainee) {
              setUserRole('trainee');
              setCurrentTrainee(trainee);
              localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ role: 'trainee', profile: trainee }));
            } else {
              throw new Error('User profile not found in Institute database. Please complete registration.');
            }
          }
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  const parentLogin = async (traineeId: string, pin: string) => {
    setIsLoading(true);
    try {
      const res = await serviceParentLogin(traineeId, pin);
      if (!res.success || !res.trainee) {
        throw new Error(res.error || 'Failed to login to parent portal.');
      }
      setUserRole('parent');
      setCurrentParentTrainee(res.trainee);
      localStorage.setItem(
        SESSION_STORAGE_KEY,
        JSON.stringify({ role: 'parent', trainee: res.trainee })
      );
    } finally {
      setIsLoading(false);
    }
  };

  const loginAsDemo = (role: UserRole) => {
    setUserRole(role);
    if (role === 'admin') {
      const adm: AdminProfile = {
        uid: 'demo_admin_uid',
        name: 'Institute Admin',
        email: 'admin@iti.edu',
        role: 'admin',
        status: 'approved',
      };
      setCurrentAdmin(adm);
      setCurrentUserProfile({
        uid: adm.uid,
        name: adm.name,
        email: adm.email,
        role: 'admin',
        status: 'approved',
      });
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ role: 'admin', profile: adm }));
    } else if (role === 'instructor') {
      const inst: InstructorProfile = {
        uid: 'demo_inst_uid',
        name: 'Najeeb Rehman',
        email: 'najeeb.instructor@iti.edu',
        contact: '9876543210',
        tradeId: 'trade_elec',
        tradeName: 'Electrician',
        role: 'instructor',
        status: 'approved',
      };
      setCurrentInstructor(inst);
      setCurrentUserProfile({
        uid: inst.uid,
        name: inst.name,
        email: inst.email,
        role: 'instructor',
        status: 'approved',
      });
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ role: 'instructor', profile: inst }));
    } else if (role === 'trainee') {
      const trainee: TraineeProfile = {
        uid: 'demo_trainee_uid',
        traineeId: 'ITI-2026-00042',
        name: 'Mohd Aadil',
        parentage: 'Ghulam Rasool',
        guardianContact: '9876543210',
        email: 'aadil@iti.edu',
        contact: '9876543210',
        address: 'Anantnag Campus, J&K',
        tradeId: 'trade_elec',
        tradeName: 'Electrician',
        instructorId: 'demo_inst_uid',
        instructorName: 'Najeeb Rehman',
        role: 'trainee',
        status: 'approved',
        parentAccessPin: '1234',
      };
      setCurrentTrainee(trainee);
      setCurrentUserProfile({
        uid: trainee.uid,
        name: trainee.name,
        email: trainee.email,
        role: 'trainee',
        status: 'approved',
      });
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ role: 'trainee', profile: trainee }));
    } else if (role === 'parent') {
      const trainee: TraineeProfile = {
        uid: 'demo_trainee_uid',
        traineeId: 'ITI-2026-00042',
        name: 'Mohd Aadil',
        parentage: 'Ghulam Rasool',
        guardianContact: '9876543210',
        email: 'aadil@iti.edu',
        contact: '9876543210',
        address: 'Anantnag Campus, J&K',
        tradeId: 'trade_elec',
        tradeName: 'Electrician',
        instructorId: 'demo_inst_uid',
        instructorName: 'Najeeb Rehman',
        role: 'trainee',
        status: 'approved',
        parentAccessPin: '1234',
      };
      setCurrentParentTrainee(trainee);
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ role: 'parent', trainee }));
    }
  };

  const logout = async () => {
    localStorage.removeItem(SESSION_STORAGE_KEY);
    if (auth) {
      try {
        await signOut(auth);
      } catch {}
    }
    setUserRole(null);
    setCurrentUserProfile(null);
    setCurrentAdmin(null);
    setCurrentInstructor(null);
    setCurrentTrainee(null);
    setCurrentParentTrainee(null);
    setLocationStatus(null);
  };

  const reloadProfileData = async () => {
    try {
      const s = await getInstituteSettings();
      if (s) setInstituteSettings(s);
    } catch {
      // ignore
    }
    if (userRole === 'trainee' && currentTrainee?.uid) {
      const t = await getTraineeProfile(currentTrainee.uid);
      if (t) setCurrentTrainee(t);
    } else if (userRole === 'instructor' && currentInstructor?.uid) {
      const i = await getInstructorProfile(currentInstructor.uid);
      if (i) setCurrentInstructor(i);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        userRole,
        currentUserProfile,
        currentAdmin,
        currentInstructor,
        currentTrainee,
        currentParentTrainee,
        instituteSettings,
        locationStatus,
        isCheckingLocation,
        isLoading,
        unacknowledgedNotifs,
        refreshLocation,
        login,
        parentLogin,
        loginAsDemo,
        logout,
        dismissNotificationPopup,
        reloadProfileData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
