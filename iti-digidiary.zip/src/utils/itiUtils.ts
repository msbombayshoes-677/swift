import { InstituteSettings, DistanceResult, TraineeProfile, Holiday } from '../types';

export const ITI_DEVELOPER_CREDIT = "Developed By: V/I NAJEEB REHMAN :   Principal: Er. Bila Ahmad Wani";

/**
 * Calculates Haversine distance in meters between two GPS coordinates
 */
export function calculateDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000; // Earth radius in meters
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return rRounded(R * c);
}

function rRounded(val: number): number {
  return Math.round(val * 10) / 10;
}

/**
 * Verifies if coordinates are within the Institute GPS geofence radius
 */
export function verifyLocation(
  currentLat: number,
  currentLng: number,
  settings: InstituteSettings
): DistanceResult {
  const distance = calculateDistanceMeters(
    currentLat,
    currentLng,
    settings.latitude,
    settings.longitude
  );
  const isInside = distance <= settings.radiusMeters;
  const message = isInside
    ? `Inside Institute (${distance.toFixed(1)}m from center). Attendance Allowed.`
    : `Outside Institute (${distance.toFixed(1)}m away). You must be within ${Math.round(settings.radiusMeters)}m of the institute to mark attendance.`;

  return {
    distanceMeters: distance,
    isWithinRadius: isInside,
    currentLat,
    currentLng,
    instituteLat: settings.latitude,
    instituteLng: settings.longitude,
    allowedRadiusMeters: settings.radiusMeters,
    statusMessage: message,
  };
}

/**
 * Date and Time utilities matching Android DateUtils.kt
 */
export const DateUtils = {
  getTodayDateString(): string {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  },

  getYesterdayDateString(): string {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  },

  getPreviousDate(dateStr: string): string {
    try {
      const parts = dateStr.split('-');
      const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      d.setDate(d.getDate() - 1);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      return `${yyyy}-${mm}-${dd}`;
    } catch {
      return dateStr;
    }
  },

  getNextDate(dateStr: string): string {
    try {
      const parts = dateStr.split('-');
      const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      d.setDate(d.getDate() + 1);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      return `${yyyy}-${mm}-${dd}`;
    } catch {
      return dateStr;
    }
  },

  formatDateForDisplay(dateStr: string): string {
    if (!dateStr) return '';
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
        return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
      }
      return dateStr;
    } catch {
      return dateStr;
    }
  },

  formatTime(timestamp?: number | null): string {
    if (!timestamp || timestamp === 0) return '--:--';
    const d = new Date(timestamp);
    return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
  },

  formatDateTime(timestamp?: number | null): string {
    if (!timestamp || timestamp === 0) return '--';
    const d = new Date(timestamp);
    const dateStr = d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const timeStr = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    return `${dateStr}, ${timeStr}`;
  },

  getCurrentMonthYear(): string {
    const d = new Date();
    return d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  },

  formatYearMonthForDisplay(yearMonth: string): string {
    if (!yearMonth) return '';
    try {
      const parts = yearMonth.split('-');
      const d = new Date(Number(parts[0]), Number(parts[1]) - 1, 1);
      return d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    } catch {
      return yearMonth;
    }
  },

  getDayOfWeek(): string {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[new Date().getDay()];
  },

  getDayNameForDate(dateStr: string): string {
    if (!dateStr) return '';
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return days[d.getDay()];
      }
      return '';
    } catch {
      return '';
    }
  },

  isHoliday(dateStr: string, holidays?: Holiday[]): boolean {
    if (!dateStr || !holidays || holidays.length === 0) return false;
    return holidays.some((h) => h.date === dateStr);
  },

  getHolidayForDate(dateStr: string, holidays?: Holiday[]): Holiday | undefined {
    if (!dateStr || !holidays) return undefined;
    return holidays.find((h) => h.date === dateStr);
  },

  isWorkingDay(
    dateStr: string,
    workingDaysOfWeek: string[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    holidays?: Holiday[]
  ): boolean {
    if (!dateStr) return false;
    // Check if it's marked as a holiday
    if (this.isHoliday(dateStr, holidays)) {
      return false;
    }
    // Check if day of week is configured as a working day
    const dayName = this.getDayNameForDate(dateStr);
    return workingDaysOfWeek.includes(dayName);
  },

  getWorkingDaysInMonth(
    yearMonth: string,
    workingDaysOfWeek: string[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    holidays: Holiday[] = [],
    upToDate?: string
  ): { totalWorkingDays: number; workingDates: string[]; holidaysInMonth: Holiday[] } {
    if (!yearMonth) return { totalWorkingDays: 0, workingDates: [], holidaysInMonth: [] };
    try {
      const [yearStr, monthStr] = yearMonth.split('-');
      const year = Number(yearStr);
      const month = Number(monthStr); // 1-12
      const daysInMonth = new Date(year, month, 0).getDate();

      const workingDates: string[] = [];
      const holidaysInMonth: Holiday[] = [];
      const holidayMap = new Map<string, Holiday>();
      holidays.forEach((h) => {
        if (h.date && h.date.startsWith(yearMonth)) {
          holidayMap.set(h.date, h);
          holidaysInMonth.push(h);
        }
      });

      for (let day = 1; day <= daysInMonth; day++) {
        const dd = String(day).padStart(2, '0');
        const dateStr = `${yearStr}-${String(month).padStart(2, '0')}-${dd}`;

        if (upToDate && dateStr > upToDate) {
          continue;
        }

        // If it's a holiday, it's not a working day
        if (holidayMap.has(dateStr)) {
          continue;
        }

        // Check day of week
        const d = new Date(year, month - 1, day);
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const dayOfWeek = days[d.getDay()];

        if (workingDaysOfWeek.includes(dayOfWeek)) {
          workingDates.push(dateStr);
        }
      }

      return {
        totalWorkingDays: workingDates.length,
        workingDates,
        holidaysInMonth,
      };
    } catch {
      return { totalWorkingDays: 0, workingDates: [], holidaysInMonth: [] };
    }
  },

  isLate(punchInTimestamp: number, lateThreshold: string): boolean {
    try {
      const d = new Date(punchInTimestamp);
      const [lateH, lateM] = lateThreshold.split(':').map(Number);
      const punchH = d.getHours();
      const punchM = d.getMinutes();
      if (punchH > lateH) return true;
      if (punchH === lateH && punchM > lateM) return true;
      return false;
    } catch {
      return false;
    }
  },

  isPastCutoff(cutoffTimeStr?: string): boolean {
    if (!cutoffTimeStr) return false;
    try {
      const [cutoffH, cutoffM] = cutoffTimeStr.split(':').map(Number);
      const d = new Date();
      const currentH = d.getHours();
      const currentM = d.getMinutes();
      if (currentH > cutoffH) return true;
      if (currentH === cutoffH && currentM >= cutoffM) return true;
      return false;
    } catch {
      return false;
    }
  },
};

/**
 * Resolves the actual attendance status of a trainee, taking into account cutoff time and holidays.
 */
export function resolveAttendanceStatus(
  status: string | undefined | null,
  date: string,
  cutoffTime?: string,
  holidays?: Holiday[]
): string {
  const normalized = status || 'not_marked';
  if (normalized !== 'not_marked') {
    return normalized;
  }

  // If the day is a marked holiday, it should be displayed as a holiday
  if (DateUtils.isHoliday(date, holidays)) {
    return 'holiday';
  }
  
  const today = DateUtils.getTodayDateString();
  if (date === today) {
    if (DateUtils.isPastCutoff(cutoffTime)) {
      return 'absent';
    }
    return 'not_marked';
  } else if (date < today) {
    return 'absent';
  }
  return 'not_marked';
}

/**
 * Trainee ID natural alphanumeric sorting matching Kotlin compareTraineeIds
 */
export function compareTraineeIds(id1Raw: string, id2Raw: string): number {
  const id1 = (id1Raw || '').trim().toUpperCase();
  const id2 = (id2Raw || '').trim().toUpperCase();
  if (id1 === id2) return 0;
  if (!id1) return 1;
  if (!id2) return -1;
  if (id1 === 'PENDING' && id2 !== 'PENDING') return 1;
  if (id2 === 'PENDING' && id1 !== 'PENDING') return -1;

  const regex = /(\D+|\d+)/g;
  const tokens1 = id1.match(regex) || [];
  const tokens2 = id2.match(regex) || [];
  const minLen = Math.min(tokens1.length, tokens2.length);

  for (let i = 0; i < minLen; i++) {
    const tok1 = tokens1[i];
    const tok2 = tokens2[i];
    const num1 = Number(tok1);
    const num2 = Number(tok2);
    if (!isNaN(num1) && !isNaN(num2)) {
      if (num1 !== num2) return num1 - num2;
    } else {
      if (tok1 !== tok2) return tok1.localeCompare(tok2);
    }
  }
  return tokens1.length - tokens2.length;
}

export function sortTraineesByTraineeId(trainees: TraineeProfile[]): TraineeProfile[] {
  return [...trainees].sort((a, b) => compareTraineeIds(a.traineeId, b.traineeId));
}

/**
 * Downloads CSV content in browser
 */
export function downloadCsv(filename: string, csvContent: string): void {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
