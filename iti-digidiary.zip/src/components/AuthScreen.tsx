import React, { useState, useEffect } from 'react';
import {
  Building2,
  BadgeCheck,
  School,
  Users,
  Lock,
  Mail,
  Phone,
  User,
  MapPin,
  Eye,
  EyeOff,
  Key,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  HelpCircle,
  RefreshCw,
  Home,
  Check,
} from 'lucide-react';
import { UserRole, Trade } from '../types';
import { useAuth } from '../context/AuthContext';
import {
  getActiveTrades,
  registerInstructor,
  registerTrainee,
  sendPasswordReset,
  resetInstructorPasswordWithMobile,
  resetTraineePasswordWithMobileAndPin,
} from '../firebase/service';
import { ITI_DEVELOPER_CREDIT } from '../utils/itiUtils';

export const AuthScreen: React.FC = () => {
  const { login, parentLogin, loginAsDemo, isLoading } = useAuth();

  const [selectedRole, setSelectedRole] = useState<UserRole>('admin');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [showForgotModal, setShowForgotModal] = useState(false);

  // Form Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [parentage, setParentage] = useState('');
  const [guardianContact, setGuardianContact] = useState('');
  const [contact, setContact] = useState('');
  const [address, setAddress] = useState('');
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [traineeIdInput, setTraineeIdInput] = useState('');
  const [parentPinInput, setParentPinInput] = useState('');

  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);
  const [availableTrades, setAvailableTrades] = useState<Trade[]>([]);

  const [formError, setFormError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [pendingSuccessModal, setPendingSuccessModal] = useState(false);

  // Forgot password states
  const [resetMethod, setResetMethod] = useState<0 | 1>(0); // 0: Phone, 1: Email
  const [resetEmail, setResetEmail] = useState('');
  const [resetContact, setResetContact] = useState('');
  const [parentPinResetInput, setParentPinResetInput] = useState('');
  const [newResetPassword, setNewResetPassword] = useState('');
  const [confirmResetPassword, setConfirmResetPassword] = useState('');
  const [resetPassVisible, setResetPassVisible] = useState(false);
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSuccessNotice, setResetSuccessNotice] = useState<string | null>(null);

  useEffect(() => {
    getActiveTrades().then((trades) => {
      setAvailableTrades(trades);
    });
  }, []);

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setIsRegisterMode(false);
    setSelectedTrade(null);
    setFormError(null);
    setSuccessMessage(null);
    setPassword('');
    setConfirmPassword('');
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setFormError('Please enter both institute email and password.');
      return;
    }
    setFormError(null);
    try {
      await login(email, password);
    } catch (err: any) {
      setFormError(err.message || 'Invalid institute login credentials.');
    }
  };

  const handleInstructorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (isRegisterMode) {
      if (!name.trim()) return setFormError('Please enter your full name.');
      if (!email.trim() || !email.includes('@')) return setFormError('Please enter a valid email address.');
      if (password.length < 6) return setFormError('Password must be at least 6 characters.');
      if (password !== confirmPassword) return setFormError('Passwords do not match.');
      if (!contact.trim()) return setFormError('Please enter contact number.');
      if (!selectedTrade) return setFormError('Please select an ITI trade.');

      const res = await registerInstructor({
        name: name.trim(),
        email: email.trim(),
        pass: password,
        contact: contact.trim(),
        tradeId: selectedTrade.tradeId,
        tradeName: selectedTrade.tradeName,
      });

      if (!res.success) {
        setFormError(res.error || 'Instructor registration failed.');
      } else {
        setPendingSuccessModal(true);
      }
    } else {
      if (!email || !password) return setFormError('Please enter email and password.');
      try {
        await login(email, password);
      } catch (err: any) {
        setFormError(err.message || 'Instructor sign in failed.');
      }
    }
  };

  const handleTraineeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (isRegisterMode) {
      if (!name.trim()) return setFormError('Please enter trainee full name.');
      if (!parentage.trim()) return setFormError('Please enter father / guardian name (Parentage).');
      if (!email.trim() || !email.includes('@')) return setFormError('Please enter a valid email address.');
      if (password.length < 6) return setFormError('Password must be at least 6 characters.');
      if (password !== confirmPassword) return setFormError('Passwords do not match.');
      if (!contact.trim()) return setFormError('Please enter contact number.');
      if (!address.trim()) return setFormError('Please enter residential address.');
      if (!selectedTrade) return setFormError('Please select a trade.');

      const res = await registerTrainee({
        name: name.trim(),
        parentage: parentage.trim(),
        guardianContact: guardianContact.trim(),
        email: email.trim(),
        pass: password,
        contact: contact.trim(),
        address: address.trim(),
        tradeId: selectedTrade.tradeId,
        tradeName: selectedTrade.tradeName,
        instructorId: '',
        instructorName: '',
      });

      if (!res.success) {
        setFormError(res.error || 'Trainee registration failed.');
      } else {
        setPendingSuccessModal(true);
      }
    } else {
      if (!email || !password) return setFormError('Please enter email and password.');
      try {
        await login(email, password);
      } catch (err: any) {
        setFormError(err.message || 'Trainee sign in failed.');
      }
    }
  };

  const handleParentLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!traineeIdInput.trim() || !parentPinInput.trim()) {
      setFormError('Please enter Trainee ID (e.g. ITI-2026-00001) and 4-Digit Parent PIN.');
      return;
    }
    setFormError(null);
    try {
      await parentLogin(traineeIdInput.trim(), parentPinInput.trim());
    } catch (err: any) {
      setFormError(err.message || 'Parent monitoring sign in failed.');
    }
  };

  const handleResetPassword = async () => {
    setResetError(null);
    if (resetMethod === 0) {
      // Phone Reset
      if (!resetEmail.trim()) return setResetError('Please enter registered email address.');
      if (resetContact.replace(/\D/g, '').length < 10) return setResetError('Please enter valid 10-digit mobile number.');
      if (newResetPassword.length < 6) return setResetError('Password must be at least 6 characters.');
      if (newResetPassword !== confirmResetPassword) return setResetError('Passwords do not match.');

      try {
        if (selectedRole === 'trainee') {
          if (parentPinResetInput.length !== 4) return setResetError('Please enter 4-digit Parent PIN.');
          const msg = await resetTraineePasswordWithMobileAndPin(
            resetEmail,
            resetContact,
            parentPinResetInput,
            newResetPassword
          );
          setResetSuccessNotice(msg);
          setEmail(resetEmail);
          setPassword(newResetPassword);
        } else {
          const msg = await resetInstructorPasswordWithMobile(
            resetEmail,
            resetContact,
            newResetPassword
          );
          setResetSuccessNotice(msg);
          setEmail(resetEmail);
          setPassword(newResetPassword);
        }
      } catch (err: any) {
        setResetError(err.message || 'Password reset failed.');
      }
    } else {
      // Email Reset
      if (!resetEmail.trim()) return setResetError('Please enter your registered email address.');
      try {
        const msg = await sendPasswordReset(resetEmail);
        setResetSuccessNotice(msg);
      } catch (err: any) {
        setResetError(err.message || 'Failed to send reset email.');
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#E4EDE4] flex flex-col justify-between selection:bg-[#386B39] selection:text-white">
      <div className="w-full">
        {/* Hero Header matching Android AuthScreen.kt */}
        <div className="bg-[#386B39] text-white py-7 px-4 shadow-md text-center">
          <div className="max-w-md mx-auto flex flex-col items-center">
            {/* Row 1: Jammu & Kashmir */}
            <span className="text-sm font-bold tracking-wide text-white/95 uppercase">
              Jammu &amp; Kashmir
            </span>
            {/* Row 2: Government */}
            <span className="text-xs font-semibold tracking-widest text-white/80 uppercase mt-0.5">
              Government
            </span>

            {/* Emblem Circle */}
            <div className="w-18 h-18 rounded-full bg-white/15 border border-white/20 flex items-center justify-center my-3 shadow-inner">
              <Building2 className="w-10 h-10 text-white" />
            </div>

            {/* Row 4: Industrial Training Institute */}
            <span className="text-sm sm:text-base font-bold text-white tracking-wide">
              Industrial Training Institute
            </span>
            {/* Row 5: ITI ANANTNAG */}
            <span className="text-xl sm:text-2xl font-black text-black tracking-wider bg-white/90 px-4 py-1 rounded-xl shadow-xs my-1">
              ITI ANANTNAG
            </span>
            {/* Subtitle */}
            <p className="text-xs font-medium text-white/85 mt-1">
              Real-time GPS Trainee Attendance System
            </p>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="max-w-md mx-auto px-4 py-5 space-y-4">
          {/* Role Selection Tabs */}
          <div className="bg-[#D8E7D8]/80 p-1.5 rounded-2xl flex items-center justify-between gap-1 shadow-inner border border-[#386B39]/20 overflow-x-auto">
            {(
              [
                { role: 'admin', label: 'Institute', icon: Building2 },
                { role: 'instructor', label: 'Instructor', icon: BadgeCheck },
                { role: 'trainee', label: 'Trainee', icon: School },
                { role: 'parent', label: 'Parent', icon: Users },
              ] as const
            ).map((item) => {
              const Icon = item.icon;
              const isSelected = selectedRole === item.role;
              return (
                <button
                  key={item.role}
                  type="button"
                  onClick={() => handleRoleSelect(item.role)}
                  className={`flex-1 py-2 px-2 rounded-xl font-bold text-xs flex flex-col items-center justify-center space-y-1 transition-all active:scale-95 cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? 'bg-white text-[#386B39] shadow-sm'
                      : 'text-slate-700 hover:text-slate-900 hover:bg-white/40'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-[#386B39]' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Auth Form Card */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-sm border border-slate-200/80">
            <div className="mb-4">
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                {selectedRole === 'admin'
                  ? 'Institute Portal Login'
                  : selectedRole === 'instructor'
                  ? isRegisterMode
                    ? 'Instructor Registration'
                    : 'Instructor Login'
                  : selectedRole === 'trainee'
                  ? isRegisterMode
                    ? 'Trainee Admission / Registration'
                    : 'Trainee Login'
                  : 'Parent Monitoring Login'}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {selectedRole === 'admin'
                  ? 'Enter authorized institute administrator credentials'
                  : selectedRole === 'instructor'
                  ? isRegisterMode
                    ? 'Register under an active ITI trade (requires Admin approval)'
                    : 'Sign in to manage trade attendance & trainees'
                  : selectedRole === 'trainee'
                  ? isRegisterMode
                    ? 'Register for daily GPS attendance (requires approval)'
                    : 'Sign in to mark daily GPS attendance'
                  : 'Enter Trainee ID & 4-Digit Parent Access PIN'}
              </p>
            </div>

            {/* Error Message */}
            {formError && (
              <div className="mb-4 p-3 rounded-2xl bg-red-50 border border-red-200 text-xs font-semibold text-red-700 flex items-start space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
                <span>{formError}</span>
              </div>
            )}

            {/* Forms based on Role */}
            {selectedRole === 'admin' && (
              <form onSubmit={handleAdminLogin} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Institute Email</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="admin@iti.edu"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] focus:border-transparent outline-hidden bg-slate-50/50"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                    <input
                      type={passwordVisible ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] focus:border-transparent outline-hidden bg-slate-50/50"
                    />
                    <button
                      type="button"
                      onClick={() => setPasswordVisible(!passwordVisible)}
                      className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                    >
                      {passwordVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 rounded-2xl bg-[#386B39] hover:bg-[#2e592f] text-white font-extrabold text-xs shadow-md shadow-[#386B39]/20 active:scale-98 transition-all cursor-pointer disabled:opacity-50 mt-2"
                >
                  {isLoading ? 'Signing In...' : 'Login as Institute'}
                </button>

                <div className="pt-2 flex flex-col items-center space-y-2 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      setResetEmail(email);
                      setShowForgotModal(true);
                    }}
                    className="text-[#386B39] font-bold hover:underline"
                  >
                    Forgot Institute Password?
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setEmail('admin@iti.edu');
                      setPassword('password123');
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] flex items-center justify-center space-x-1.5 transition-all cursor-pointer"
                  >
                    <Key className="w-3.5 h-3.5 text-[#386B39]" />
                    <span>Autofill Demo Institute (admin@iti.edu)</span>
                  </button>
                </div>
              </form>
            )}

            {selectedRole === 'instructor' && (
              <form onSubmit={handleInstructorSubmit} className="space-y-3">
                {isRegisterMode ? (
                  <>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Full Name *</label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Rajesh Kumar"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Email Address *</label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="instructor@iti.edu"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Password *</label>
                        <input
                          type={passwordVisible ? 'text' : 'password'}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Min 6 chars"
                          className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Confirm *</label>
                        <input
                          type={passwordVisible ? 'text' : 'password'}
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="Confirm password"
                          className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Contact Number *</label>
                      <input
                        type="tel"
                        value={contact}
                        onChange={(e) => setContact(e.target.value)}
                        placeholder="e.g. 9876543210"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Assigned ITI Trade *</label>
                      <select
                        value={selectedTrade?.tradeId || ''}
                        onChange={(e) => {
                          const tr = availableTrades.find((t) => t.tradeId === e.target.value);
                          setSelectedTrade(tr || null);
                        }}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50 font-bold text-slate-800"
                      >
                        <option value="">Select Trade</option>
                        {availableTrades.map((t) => (
                          <option key={t.tradeId} value={t.tradeId}>
                            {t.tradeName} ({t.tradeCode}) - {t.scheme}
                          </option>
                        ))}
                      </select>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-3 rounded-2xl bg-[#386B39] hover:bg-[#2e592f] text-white font-extrabold text-xs shadow-md shadow-[#386B39]/20 active:scale-98 transition-all cursor-pointer disabled:opacity-50 mt-2"
                    >
                      {isLoading ? 'Submitting...' : 'Submit Instructor Registration'}
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsRegisterMode(false)}
                      className="w-full text-center text-xs text-[#386B39] font-bold hover:underline pt-1"
                    >
                      Already registered? Login here
                    </button>
                  </>
                ) : (
                  <>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Instructor Email</label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="instructor@iti.edu"
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                        <input
                          type={passwordVisible ? 'text' : 'password'}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                        />
                        <button
                          type="button"
                          onClick={() => setPasswordVisible(!passwordVisible)}
                          className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                        >
                          {passwordVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-3 rounded-2xl bg-[#386B39] hover:bg-[#2e592f] text-white font-extrabold text-xs shadow-md shadow-[#386B39]/20 active:scale-98 transition-all cursor-pointer disabled:opacity-50 mt-2"
                    >
                      {isLoading ? 'Signing In...' : 'Login as Instructor'}
                    </button>

                    <div className="flex items-center justify-between text-xs pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setResetEmail(email);
                          setShowForgotModal(true);
                        }}
                        className="text-slate-600 font-bold hover:underline"
                      >
                        Forgot Password?
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIsRegisterMode(true);
                          setSelectedTrade(null);
                          setFormError(null);
                        }}
                        className="text-[#386B39] font-bold hover:underline"
                      >
                        New Instructor? Register
                      </button>
                    </div>
                  </>
                )}
              </form>
            )}

            {selectedRole === 'trainee' && (
              <form onSubmit={handleTraineeSubmit} className="space-y-3">
                {isRegisterMode ? (
                  <>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Trainee Full Name *</label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Mohd Aadil"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Parentage (Father / Guardian Name) *
                      </label>
                      <input
                        type="text"
                        value={parentage}
                        onChange={(e) => setParentage(e.target.value)}
                        placeholder="e.g. Ghulam Rasool"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Father / Guardian Contact No.
                      </label>
                      <input
                        type="tel"
                        value={guardianContact}
                        onChange={(e) => setGuardianContact(e.target.value)}
                        placeholder="e.g. 9876543210"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Email Address *</label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="trainee@iti.edu"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Password *</label>
                        <input
                          type={passwordVisible ? 'text' : 'password'}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Min 6 chars"
                          className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Confirm *</label>
                        <input
                          type={passwordVisible ? 'text' : 'password'}
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="Confirm"
                          className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Trainee Phone *</label>
                        <input
                          type="tel"
                          value={contact}
                          onChange={(e) => setContact(e.target.value)}
                          placeholder="Mobile number"
                          className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Enrolled Trade *</label>
                        <select
                          value={selectedTrade?.tradeId || ''}
                          onChange={(e) => {
                            const tr = availableTrades.find((t) => t.tradeId === e.target.value);
                            setSelectedTrade(tr || null);
                          }}
                          className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50 font-bold text-slate-800"
                        >
                          <option value="">Select Trade</option>
                          {availableTrades.map((t) => (
                            <option key={t.tradeId} value={t.tradeId}>
                              {t.tradeName}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Residential Address *</label>
                      <input
                        type="text"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="e.g. Village/Town, Anantnag"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-3 rounded-2xl bg-[#386B39] hover:bg-[#2e592f] text-white font-extrabold text-xs shadow-md shadow-[#386B39]/20 active:scale-98 transition-all cursor-pointer disabled:opacity-50 mt-2"
                    >
                      {isLoading ? 'Submitting...' : 'Submit Trainee Admission'}
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsRegisterMode(false)}
                      className="w-full text-center text-xs text-[#386B39] font-bold hover:underline pt-1"
                    >
                      Already registered? Login here
                    </button>
                  </>
                ) : (
                  <>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Trainee Email</label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="trainee@iti.edu"
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                        <input
                          type={passwordVisible ? 'text' : 'password'}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                        />
                        <button
                          type="button"
                          onClick={() => setPasswordVisible(!passwordVisible)}
                          className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                        >
                          {passwordVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-3 rounded-2xl bg-[#386B39] hover:bg-[#2e592f] text-white font-extrabold text-xs shadow-md shadow-[#386B39]/20 active:scale-98 transition-all cursor-pointer disabled:opacity-50 mt-2"
                    >
                      {isLoading ? 'Signing In...' : 'Login as Trainee'}
                    </button>

                    <div className="flex items-center justify-between text-xs pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setResetEmail(email);
                          setShowForgotModal(true);
                        }}
                        className="text-slate-600 font-bold hover:underline"
                      >
                        Forgot Password?
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIsRegisterMode(true);
                          setSelectedTrade(null);
                          setFormError(null);
                        }}
                        className="text-[#386B39] font-bold hover:underline"
                      >
                        New Trainee? Register
                      </button>
                    </div>
                  </>
                )}
              </form>
            )}

            {selectedRole === 'parent' && (
              <form onSubmit={handleParentLogin} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Trainee ID (e.g. ITI-2026-00001)
                  </label>
                  <input
                    type="text"
                    value={traineeIdInput}
                    onChange={(e) => setTraineeIdInput(e.target.value.toUpperCase())}
                    placeholder="ITI-2026-00001"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs uppercase font-mono font-bold tracking-wider focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    4-Digit Parent Access PIN
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    value={parentPinInput}
                    onChange={(e) => setParentPinInput(e.target.value.replace(/\D/g, ''))}
                    placeholder="••••"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-mono font-bold tracking-widest text-center focus:ring-2 focus:ring-[#386B39] outline-hidden bg-slate-50/50"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 rounded-2xl bg-[#386B39] hover:bg-[#2e592f] text-white font-extrabold text-xs shadow-md shadow-[#386B39]/20 active:scale-98 transition-all cursor-pointer disabled:opacity-50 mt-2"
                >
                  {isLoading ? 'Verifying...' : 'Monitor Trainee Attendance'}
                </button>

                <p className="text-[11px] text-slate-500 text-center pt-1 leading-relaxed">
                  Note: The 4-digit Parent PIN is provided upon trainee admission approval.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Developer Credit Footer */}
      <div className="py-4 px-4 text-center">
        <p className="text-[11px] font-semibold text-slate-600/90 tracking-wide">
          {ITI_DEVELOPER_CREDIT}
        </p>
      </div>

      {/* Registration Pending Modal */}
      {pendingSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl border border-slate-200">
            <div className="w-16 h-16 rounded-full bg-[#D8E7D8] text-[#386B39] flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-base font-black text-slate-900">Registration Successful!</h3>
            <div className="p-3.5 rounded-2xl bg-[#D8E7D8]/50 text-slate-800 text-xs font-medium text-left space-y-1">
              <span className="font-bold block text-[#386B39]">Awaiting Institute Approval:</span>
              <p>
                Your registration has been submitted for administration review. Daily attendance
                marking will unlock upon approval.
              </p>
            </div>
            <button
              onClick={() => {
                setPendingSuccessModal(false);
                setIsRegisterMode(false);
              }}
              type="button"
              className="w-full py-2.5 rounded-xl bg-[#386B39] text-white font-bold text-xs shadow-md cursor-pointer"
            >
              OK, Got It
            </button>
          </div>
        </div>
      )}

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center space-x-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#D8E7D8] text-[#386B39] flex items-center justify-center">
                <Key className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900">Recover / Reset Password</h3>
                <p className="text-[11px] text-slate-500">Reset your login credentials</p>
              </div>
            </div>

            {/* Trainee method switch tabs */}
            {selectedRole === 'trainee' && (
              <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setResetMethod(0);
                    setResetError(null);
                  }}
                  className={`flex-1 py-1.5 rounded-lg font-bold text-xs ${
                    resetMethod === 0 ? 'bg-white text-[#386B39] shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Instant Phone Reset
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setResetMethod(1);
                    setResetError(null);
                  }}
                  className={`flex-1 py-1.5 rounded-lg font-bold text-xs ${
                    resetMethod === 1 ? 'bg-white text-[#386B39] shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Email Reset Link
                </button>
              </div>
            )}

            {resetError && (
              <div className="p-2.5 rounded-xl bg-red-50 text-red-700 font-semibold border border-red-200">
                {resetError}
              </div>
            )}

            {resetSuccessNotice && (
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-800 font-semibold border border-emerald-200">
                {resetSuccessNotice}
              </div>
            )}

            {resetMethod === 0 && selectedRole === 'trainee' ? (
              <div className="space-y-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">
                    Registered Email
                  </label>
                  <input
                    type="email"
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">
                    Registered Mobile Number (10 Digits)
                  </label>
                  <input
                    type="tel"
                    value={resetContact}
                    onChange={(e) => setResetContact(e.target.value)}
                    placeholder="9876543210"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">
                    4-Digit Parent Access PIN
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    value={parentPinResetInput}
                    onChange={(e) => setParentPinResetInput(e.target.value)}
                    placeholder="1234"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 font-mono tracking-widest text-center"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">
                    New Password
                  </label>
                  <input
                    type="password"
                    value={newResetPassword}
                    onChange={(e) => setNewResetPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    value={confirmResetPassword}
                    onChange={(e) => setConfirmResetPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50"
                  />
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Registered Email Address
                </label>
                <input
                  type="email"
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  placeholder="name@iti.edu"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50/50"
                />
              </div>
            )}

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowForgotModal(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleResetPassword}
                className="px-5 py-2 rounded-xl bg-[#386B39] text-white font-bold hover:bg-[#2e592f] shadow-sm cursor-pointer"
              >
                {resetMethod === 0 && selectedRole === 'trainee'
                  ? 'Reset Password Now'
                  : 'Send Reset Link'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
