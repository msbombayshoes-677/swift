import React, { useState, useEffect } from 'react';
import {
  Users,
  Calendar,
  Clock,
  MapPin,
  BookOpen,
  History,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  TrendingUp,
} from 'lucide-react';
import { TraineeProfile, AttendanceRecord, DiaryNote, InstituteNotification } from '../types';
import {
  ItiTopAppBar,
  StatusBadge,
  EmptyStateView,
  DeveloperCreditFooter,
} from './CommonComponents';
import {
  getTodayAttendance,
  getTraineeAttendanceHistory,
  getDiaryNotesForTrainee,
  getNotifications,
} from '../firebase/service';
import { useAuth } from '../context/AuthContext';
import { DateUtils, resolveAttendanceStatus } from '../utils/itiUtils';

interface ParentScreenProps {
  trainee: TraineeProfile;
  onLogout: () => void;
}

export const ParentScreen: React.FC<ParentScreenProps> = ({ trainee, onLogout }) => {
  const { instituteSettings } = useAuth();
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord | null>(null);
  const [attendanceHistory, setAttendanceHistory] = useState<AttendanceRecord[]>([]);
  const [diaryNotes, setDiaryNotes] = useState<DiaryNote[]>([]);
  const [notifications, setNotifications] = useState<InstituteNotification[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const today = await getTodayAttendance(trainee.uid);
      setTodayAttendance(today);
      const hist = await getTraineeAttendanceHistory(trainee.uid, trainee.traineeId);
      setAttendanceHistory(hist);
      const notes = await getDiaryNotesForTrainee(trainee.uid);
      setDiaryNotes(notes);
      const notifs = await getNotifications('parent', trainee.tradeId, trainee.uid);
      setNotifications(notifs);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [trainee.uid]);

  const presentDays = attendanceHistory.filter(
    (h) => h.attendanceStatus === 'present' || h.attendanceStatus === 'late'
  ).length;
  const lateDays = attendanceHistory.filter((h) => h.attendanceStatus === 'late').length;
  const absentDays = attendanceHistory.filter((h) => h.attendanceStatus === 'absent').length;
  const totalDays = attendanceHistory.length;
  const attendancePercentage = totalDays > 0 ? (presentDays / totalDays) * 100 : 0;

  return (
    <div className="min-h-screen bg-[#FBFDF8] flex flex-col justify-between selection:bg-[#386B39] selection:text-white">
      <div>
        {/* Top App Bar */}
        <ItiTopAppBar
          title="Parent Portal"
          subtitle={`Monitoring: ${trainee.name}`}
          roleLabel="Parent"
          notificationCount={notifications.length}
          onRefresh={loadData}
          onLogout={onLogout}
        />

        <main className="max-w-3xl mx-auto p-4 sm:p-5 space-y-4">
          {/* Trainee Overview Card */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">
                  TRAINEE PROFILE
                </span>
                <h2 className="text-lg font-black text-slate-900 mt-0.5">{trainee.name}</h2>
                <p className="text-xs text-slate-500 font-medium">Parentage: {trainee.parentage}</p>
              </div>
              <span className="px-3 py-1 rounded-full bg-slate-100 border border-slate-200 font-mono font-bold text-xs text-slate-800">
                {trainee.traineeId}
              </span>
            </div>

            <div className="pt-1 text-xs space-y-1">
              <p className="font-bold text-[#386B39]">Enrolled Trade: {trainee.tradeName}</p>
              {trainee.instructorName && (
                <p className="text-slate-500 font-medium">Trade Instructor: {trainee.instructorName}</p>
              )}
            </div>
          </div>

          {/* Today's Live Attendance Status */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">
                  TODAY'S STATUS
                </span>
                <h3 className="text-sm font-extrabold text-slate-800">
                  {DateUtils.formatDateForDisplay(DateUtils.getTodayDateString())}
                </h3>
              </div>
              <StatusBadge status={resolveAttendanceStatus(todayAttendance?.attendanceStatus, DateUtils.getTodayDateString(), instituteSettings.cutoffTime)} />
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-center justify-around">
              <div className="text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">Punch In Time</span>
                <span className="text-sm font-black text-slate-800">
                  {DateUtils.formatTime(todayAttendance?.punchInTime)}
                </span>
              </div>
              <div className="h-7 w-[1px] bg-slate-200" />
              <div className="text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">Punch Out Time</span>
                <span className="text-sm font-black text-slate-800">
                  {DateUtils.formatTime(todayAttendance?.punchOutTime)}
                </span>
              </div>
            </div>

            {todayAttendance?.punchInDistance != null && (
              <p className="text-xs font-semibold text-[#386B39] text-center">
                ✓ Verified within institute boundary ({todayAttendance.punchInDistance.toFixed(1)}m)
              </p>
            )}
          </div>

          {/* Overall Attendance Metrics Card */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">
              ATTENDANCE PERFORMANCE
            </span>

            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700">Cumulative Attendance</span>
              <span
                className={`font-extrabold text-sm ${
                  attendancePercentage >= 75 ? 'text-[#386B39]' : 'text-[#9C6800]'
                }`}
              >
                {attendancePercentage.toFixed(1)}%
              </span>
            </div>

            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
              <div
                className={`h-full transition-all ${
                  attendancePercentage >= 75 ? 'bg-[#386B39]' : 'bg-[#9C6800]'
                }`}
                style={{ width: `${Math.min(100, Math.max(0, attendancePercentage))}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs font-medium pt-1 text-slate-500">
              <span>Total Days: {totalDays}</span>
              <span className="text-[#386B39] font-bold">Present: {presentDays}</span>
              <span className="text-[#9C6800] font-bold">Late: {lateDays}</span>
              <span className="text-[#BA1A1A] font-bold">Absent: {absentDays}</span>
            </div>
          </div>

          {/* Instructor Diary Notes */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-slate-900">Instructor Diary Notes</h3>
              {diaryNotes.length > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-[#D8E7D8] text-[#111F11] text-xs font-bold">
                  {diaryNotes.length}
                </span>
              )}
            </div>

            {diaryNotes.length === 0 ? (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-center text-xs text-slate-500">
                No instructor diary notes for trainee.
              </div>
            ) : (
              <div className="space-y-2.5">
                {diaryNotes.map((note) => (
                  <div key={note.noteId} className="bg-white p-4 rounded-2xl border border-slate-200/80 space-y-2 shadow-xs">
                    <div className="flex items-start justify-between">
                      <h4 className="text-xs sm:text-sm font-black text-slate-900">{note.title}</h4>
                      <span className="text-[10px] font-semibold text-slate-400">
                        {DateUtils.formatDateForDisplay(note.dateString || DateUtils.getTodayDateString())}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 font-medium leading-relaxed">{note.content}</p>
                    <span className="text-[10px] font-bold text-[#386B39] block">
                      By Trade Instructor: {note.instructorName}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Attendance History Log */}
          <div className="space-y-2.5">
            <h3 className="text-sm font-extrabold text-slate-900">Attendance History Log</h3>
            {attendanceHistory.length === 0 ? (
              <EmptyStateView
                icon={<History className="w-8 h-8" />}
                title="No Past Records"
                subtitle="Attendance logs will appear here as daily punches occur."
              />
            ) : (
              <div className="space-y-2">
                {attendanceHistory.map((rec) => (
                  <div
                    key={rec.attendanceId || `${rec.traineeId}_${rec.date}`}
                    className="bg-white p-3.5 rounded-2xl border border-slate-200/80 flex items-center justify-between shadow-xs text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900 block">
                        {DateUtils.formatDateForDisplay(rec.date)}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        In: {DateUtils.formatTime(rec.punchInTime)} | Out: {DateUtils.formatTime(rec.punchOutTime)}
                      </span>
                    </div>
                    <StatusBadge status={rec.attendanceStatus} />
                  </div>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>

      <DeveloperCreditFooter />
    </div>
  );
};
