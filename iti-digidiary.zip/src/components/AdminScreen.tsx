import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Calendar,
  CalendarDays,
  FileSpreadsheet,
  Layers,
  Users2,
  GraduationCap,
  BarChart3,
  MapPin,
  Megaphone,
  ShieldCheck,
  Search,
  Plus,
  Edit2,
  Trash2,
  Download,
  CheckCircle,
  XCircle,
  Check,
  ChevronLeft,
  ChevronRight,
  History,
  Lock,
  BadgeAlert,
  Clock,
  X,
  Send,
  User,
  Sliders,
  AlertTriangle,
  FileText,
  UserCheck,
  Building,
  Settings,
} from 'lucide-react';
import {
  AdminProfile,
  Trade,
  InstructorProfile,
  TraineeProfile,
  AttendanceRecord,
  InstituteSettings,
  InstituteNotification,
  AuditLogEntry,
  DashboardStats,
  Holiday,
} from '../types';
import { useAuth } from '../context/AuthContext';
import {
  ItiTopAppBar,
  StatusBadge,
  EmptyStateView,
  DeveloperCreditFooter,
} from './CommonComponents';
import {
  getAdminStats,
  getAllTrades,
  getAllInstructors,
  getAllTrainees,
  getAllAttendanceForDate,
  getAllAttendanceForMonth,
  getAllNotifications,
  getAuditLogs,
  getInstituteSettings,
  updateInstituteSettings,
  addHoliday,
  deleteHoliday,
  addTrade,
  updateTrade,
  deleteTrade,
  approveInstructor,
  rejectInstructor,
  toggleInstructorStatus,
  approveTrainee,
  rejectTrainee,
  toggleTraineeStatus,
  updateTraineeProfile,
  manualCorrectAttendance,
  sendNotification,
  deleteNotification,
  getTraineeAttendanceHistory,
} from '../firebase/service';
import { DateUtils, downloadCsv } from '../utils/itiUtils';

interface AdminScreenProps {
  admin: AdminProfile;
  onLogout: () => void;
}

export const AdminScreen: React.FC<AdminScreenProps> = ({ admin, onLogout }) => {
  const { instituteSettings, refreshLocation, locationStatus } = useAuth();

  const [selectedTab, setSelectedTab] = useState<
    | 'dashboard'
    | 'daily'
    | 'monthly'
    | 'summary'
    | 'trades'
    | 'staff'
    | 'trainees'
    | 'reports'
    | 'geofence'
    | 'notices'
    | 'audit'
  >('dashboard');

  const [stats, setStats] = useState<DashboardStats>({
    totalTrades: 0,
    totalInstructors: 0,
    totalTrainees: 0,
    presentToday: 0,
    absentToday: 0,
    lateToday: 0,
    pendingTraineeApprovals: 0,
    pendingInstructorRegistrations: 0,
    attendancePercentage: 0,
  });

  const [trades, setTrades] = useState<Trade[]>([]);
  const [instructors, setInstructors] = useState<InstructorProfile[]>([]);
  const [trainees, setTrainees] = useState<TraineeProfile[]>([]);
  const [dailyAttendance, setDailyAttendance] = useState<AttendanceRecord[]>([]);
  const [monthlyAttendance, setMonthlyAttendance] = useState<AttendanceRecord[]>([]);
  const [notifications, setNotifications] = useState<InstituteNotification[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);

  const [selectedDate, setSelectedDate] = useState(DateUtils.getTodayDateString());
  const [selectedTradeFilter, setSelectedTradeFilter] = useState<string>('all');
  const [traineeSearch, setTraineeSearch] = useState('');
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  // Settings State
  const [settingsForm, setSettingsForm] = useState<InstituteSettings>(instituteSettings);

  // Holiday Management State
  const [holidayDate, setHolidayDate] = useState<string>('');
  const [holidayTitle, setHolidayTitle] = useState<string>('');
  const [holidayDescription, setHolidayDescription] = useState<string>('');
  const [isSavingHoliday, setIsSavingHoliday] = useState<boolean>(false);

  // Modals
  const [showAddTradeModal, setShowAddTradeModal] = useState(false);
  const [editingTrade, setEditingTrade] = useState<Trade | null>(null);
  const [tradeName, setTradeName] = useState('');
  const [tradeCode, setTradeCode] = useState('');
  const [tradeSeats, setTradeSeats] = useState(20);
  const [tradeDescription, setTradeDescription] = useState('');

  const [showNoticeModal, setShowNoticeModal] = useState(false);
  const [noticeTitle, setNoticeTitle] = useState('');
  const [noticeMessage, setNoticeMessage] = useState('');
  const [noticeTargetRole, setNoticeTargetRole] = useState<'all' | 'instructor' | 'trainee' | 'parent'>('all');
  const [noticeTargetTradeId, setNoticeTargetTradeId] = useState<string | null>(null);

  const [historyModalTrainee, setHistoryModalTrainee] = useState<TraineeProfile | null>(null);
  const [historyRecords, setHistoryRecords] = useState<AttendanceRecord[]>([]);

  const [correctingRecord, setCorrectingRecord] = useState<AttendanceRecord | null>(null);
  const [correctionStatus, setCorrectionStatus] = useState('present');
  const [correctionReason, setCorrectionReason] = useState('');

  const [rejectingTraineeUid, setRejectingTraineeUid] = useState<string | null>(null);
  const [traineeRejectionReason, setTraineeRejectionReason] = useState('');

  const [modifyingTrainee, setModifyingTrainee] = useState<TraineeProfile | null>(null);
  const [editName, setEditName] = useState('');
  const [editParentage, setEditParentage] = useState('');
  const [editContact, setEditContact] = useState('');
  const [editGuardianContact, setEditGuardianContact] = useState('');
  const [editAddress, setEditAddress] = useState('');

  const loadData = async () => {
    try {
      const st = await getAdminStats();
      setStats(st);
      const tr = await getAllTrades();
      setTrades(tr);
      const inst = await getAllInstructors();
      setInstructors(inst);
      const tra = await getAllTrainees();
      setTrainees(tra);
      const dAtt = await getAllAttendanceForDate(selectedDate);
      setDailyAttendance(dAtt);
      const mAtt = await getAllAttendanceForMonth();
      setMonthlyAttendance(mAtt);
      const notifs = await getAllNotifications();
      setNotifications(notifs);
      const logs = await getAuditLogs();
      setAuditLogs(logs);
      const cfg = await getInstituteSettings();
      setSettingsForm(cfg);
    } catch {}
  };

  useEffect(() => {
    loadData();
  }, [selectedDate]);

  // Handle Approvals
  const handleApproveTrainee = async (traineeUid: string) => {
    const success = await approveTrainee(traineeUid, admin.uid, admin.name, 'admin');
    if (success) {
      setActionNotice('Trainee admission approved and ID generated.');
      loadData();
    }
  };

  const handleRejectTrainee = async () => {
    if (!rejectingTraineeUid) return;
    const success = await rejectTrainee(
      rejectingTraineeUid,
      traineeRejectionReason || 'Rejected by Admin',
      admin.uid,
      admin.name,
      'admin'
    );
    setRejectingTraineeUid(null);
    setTraineeRejectionReason('');
    if (success) {
      setActionNotice('Trainee application rejected.');
      loadData();
    }
  };

  const handleApproveInstructor = async (instructorUid: string) => {
    const success = await approveInstructor(instructorUid, admin.uid, admin.name);
    if (success) {
      setActionNotice('Instructor account approved.');
      loadData();
    }
  };

  const handleRejectInstructor = async (instructorUid: string) => {
    const success = await rejectInstructor(instructorUid, 'Application rejected by Administration', admin.uid, admin.name);
    if (success) {
      setActionNotice('Instructor account rejected.');
      loadData();
    }
  };

  const handleToggleInstructorStatus = async (instructor: InstructorProfile) => {
    const success = await toggleInstructorStatus(instructor.uid, instructor.status, admin.uid, admin.name);
    if (success) {
      setActionNotice(`Instructor ${instructor.status === 'approved' ? 'deactivated' : 'activated'} successfully.`);
      loadData();
    }
  };

  const handleToggleTraineeStatus = async (trainee: TraineeProfile) => {
    const success = await toggleTraineeStatus(trainee.uid, trainee.status, admin.uid, admin.name);
    if (success) {
      setActionNotice(`Trainee ${trainee.status === 'approved' ? 'deactivated' : 'activated'} successfully.`);
      loadData();
    }
  };

  const handleSaveTraineeModify = async () => {
    if (!modifyingTrainee || !editName.trim()) return;
    const success = await updateTraineeProfile(
      modifyingTrainee.uid,
      editName.trim(),
      editParentage.trim(),
      editContact.trim(),
      editGuardianContact.trim(),
      editAddress.trim(),
      admin.uid,
      admin.name,
      'admin'
    );
    setModifyingTrainee(null);
    if (success) {
      setActionNotice('Trainee profile updated.');
      loadData();
    }
  };

  const handleSaveCorrection = async () => {
    if (!correctingRecord || !correctionReason.trim()) return;
    const success = await manualCorrectAttendance(
      correctingRecord.attendanceId,
      correctingRecord.traineeId,
      correctingRecord.traineeUniqueId,
      correctingRecord.traineeName,
      correctingRecord.date,
      correctingRecord.attendanceStatus,
      correctionStatus,
      correctionReason.trim(),
      admin.uid,
      admin.name,
      'admin'
    );
    setCorrectingRecord(null);
    setCorrectionReason('');
    if (success) {
      setActionNotice('Manual attendance correction saved.');
      loadData();
    }
  };

  const handleSaveTrade = async () => {
    if (!tradeName.trim() || !tradeCode.trim()) return;
    if (editingTrade) {
      await updateTrade(editingTrade.tradeId, tradeName.trim(), tradeCode.trim(), tradeSeats, tradeDescription.trim());
      setEditingTrade(null);
    } else {
      await addTrade(tradeName.trim(), tradeCode.trim(), tradeSeats, tradeDescription.trim());
    }
    setShowAddTradeModal(false);
    setTradeName('');
    setTradeCode('');
    setTradeSeats(20);
    setTradeDescription('');
    setActionNotice('Trade catalog updated.');
    loadData();
  };

  const handleDeleteTrade = async (tradeId: string, name: string) => {
    if (confirm(`Are you sure you want to delete trade '${name}'?`)) {
      await deleteTrade(tradeId);
      setActionNotice(`Trade '${name}' removed.`);
      loadData();
    }
  };

  const handleSaveSettings = async () => {
    const success = await updateInstituteSettings(settingsForm, admin.uid, admin.name);
    if (success) {
      setActionNotice('Geofence & Institute Settings updated.');
      loadData();
    }
  };

  const handleAddHoliday = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!holidayDate) {
      setActionNotice('Please select a date for the holiday.');
      return;
    }
    if (!holidayTitle.trim()) {
      setActionNotice('Please enter a title or reason for the holiday.');
      return;
    }
    setIsSavingHoliday(true);
    try {
      const success = await addHoliday(
        holidayDate,
        holidayTitle,
        holidayDescription,
        admin.uid,
        admin.name
      );
      if (success) {
        setActionNotice(`✓ Holiday "${holidayTitle.trim()}" marked on ${DateUtils.formatDateForDisplay(holidayDate)}.`);
        setHolidayDate('');
        setHolidayTitle('');
        setHolidayDescription('');
        await loadData();
      } else {
        setActionNotice('Failed to mark holiday. Please try again.');
      }
    } finally {
      setIsSavingHoliday(false);
    }
  };

  const handleDeleteHoliday = async (holidayIdOrDate: string, title: string) => {
    if (confirm(`Remove "${title}" from marked institutional holidays?`)) {
      const success = await deleteHoliday(holidayIdOrDate, admin.uid, admin.name);
      if (success) {
        setActionNotice(`✓ Holiday "${title}" removed.`);
        await loadData();
      } else {
        setActionNotice('Failed to remove holiday.');
      }
    }
  };

  const handleUseCurrentLocation = async () => {
    const loc = await refreshLocation();
    if (loc) {
      setSettingsForm((prev) => ({
        ...prev,
        latitude: loc.currentLat,
        longitude: loc.currentLng,
      }));
      setActionNotice('Updated coordinates with current device GPS.');
    }
  };

  const handleSendNotice = async () => {
    if (!noticeTitle.trim() || !noticeMessage.trim()) return;
    await sendNotification({
      title: noticeTitle.trim(),
      message: noticeMessage.trim(),
      targetRole: noticeTargetRole,
      targetTradeId: noticeTargetTradeId,
      senderName: `Principal / Admin Office`,
      senderRole: 'admin',
      senderUserId: admin.uid,
    });
    setShowNoticeModal(false);
    setNoticeTitle('');
    setNoticeMessage('');
    setNoticeTargetTradeId(null);
    setActionNotice('Institute notice broadcasted successfully.');
    loadData();
  };

  const handleExportCsv = (mode: 'day' | 'month') => {
    const list = mode === 'day' ? dailyAttendance : monthlyAttendance;
    const dateLabel = mode === 'day' ? selectedDate : DateUtils.getCurrentMonthYear();
    let csv = 'Date,Trainee ID,Trainee Name,Trade,Status,Punch In,Punch Out,Remarks\n';
    list.forEach((r) => {
      csv += `${r.date},${r.traineeUniqueId},${r.traineeName},${r.tradeName},${r.attendanceStatus},${DateUtils.formatTime(r.punchInTime)},${DateUtils.formatTime(r.punchOutTime)},${r.remarks || ''}\n`;
    });
    downloadCsv(`iti_attendance_${dateLabel.replace(/\s+/g, '_')}.csv`, csv);
  };

  const pendingTrainees = trainees.filter((t) => t.status === 'pending');
  const pendingInstructors = instructors.filter((i) => i.status === 'pending');

  const filteredTrainees = trainees.filter((t) => {
    if (selectedTradeFilter !== 'all' && t.tradeId !== selectedTradeFilter) return false;
    if (!traineeSearch.trim()) return true;
    const q = traineeSearch.toLowerCase();
    return t.name.toLowerCase().includes(q) || t.traineeId.toLowerCase().includes(q);
  });

  return (
    <div className="min-h-screen bg-[#FBFDF8] flex flex-col justify-between selection:bg-[#386B39] selection:text-white">
      <div>
        {/* Top App Bar */}
        <ItiTopAppBar
          title="Admin Console"
          subtitle="Principal / Admin Portal"
          roleLabel="Admin"
          notificationCount={notifications.length}
          onBroadcast={() => setShowNoticeModal(true)}
          onNotificationClick={() => setSelectedTab('notices')}
          onRefresh={loadData}
          onLogout={onLogout}
        />

        {/* Scrollable Tab Row matching Android ScrollableTabRow */}
        <div className="bg-white border-b border-slate-200/80 shadow-xs sticky top-[57px] z-30 overflow-x-auto">
          <div className="max-w-6xl mx-auto flex items-center justify-start min-w-max px-2">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'daily', label: 'Attendance', icon: Calendar },
              { id: 'trades', label: 'Trades', icon: Layers },
              { id: 'staff', label: pendingInstructors.length > 0 ? `Instructors (${pendingInstructors.length})` : 'Instructors', icon: Users2 },
              { id: 'trainees', label: pendingTrainees.length > 0 ? `Trainee (${pendingTrainees.length})` : 'Trainee', icon: GraduationCap },
              { id: 'monthly', label: 'Monthly', icon: CalendarDays },
              { id: 'summary', label: 'Summary', icon: FileSpreadsheet },
              { id: 'reports', label: 'Reports', icon: BarChart3 },
              { id: 'geofence', label: 'Settings', icon: Settings },
              { id: 'notices', label: 'Notices', icon: Megaphone },
              { id: 'audit', label: 'Audit', icon: ShieldCheck },
            ].map((tab) => {
              const Icon = tab.icon;
              const isSelected = selectedTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id as any)}
                  type="button"
                  className={`py-3 px-3 flex items-center space-x-1.5 text-xs font-bold transition-all border-b-2 cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? 'border-[#386B39] text-[#386B39]'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-[#386B39]' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Notice Alert */}
        {actionNotice && (
          <div className="max-w-6xl mx-auto px-4 pt-3">
            <div className="p-3 rounded-2xl bg-[#386B39]/15 border border-[#386B39]/30 text-xs font-semibold text-[#386B39] flex items-center justify-between">
              <span>{actionNotice}</span>
              <button onClick={() => setActionNotice(null)} className="p-1 hover:bg-[#386B39]/20 rounded-lg">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Main Body */}
        <main className="max-w-6xl mx-auto p-4 sm:p-5 space-y-4">
          {/* TAB 1: DASHBOARD */}
          {selectedTab === 'dashboard' && (
            <div className="space-y-4">
              {/* Header card */}
              <div className="p-5 rounded-3xl bg-[#D8E7D8]/60 border border-[#386B39]/30 space-y-1">
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#386B39] block">
                  INSTITUTE MANAGEMENT SYSTEM
                </span>
                <h3 className="text-base font-black text-[#111F11]">ITI Anantnag Administration</h3>
                <p className="text-xs text-slate-600">
                  Real-time GPS attendance monitoring, staff &amp; trainee governance
                </p>
              </div>

              {/* Quick Action Navigation Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <button
                  onClick={() => setSelectedTab('trades')}
                  className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-[#386B39] text-left cursor-pointer transition-all space-y-1"
                >
                  <Layers className="w-5 h-5 text-[#386B39]" />
                  <span className="text-xs font-black text-slate-900 block">Trades &amp; Staff</span>
                  <span className="text-[10px] text-slate-500 block">Manage departments</span>
                </button>

                <button
                  onClick={() => setSelectedTab('trainees')}
                  className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-[#386B39] text-left cursor-pointer transition-all space-y-1"
                >
                  <GraduationCap className="w-5 h-5 text-[#2E627B]" />
                  <span className="text-xs font-black text-slate-900 block">Trainee Roster</span>
                  <span className="text-[10px] text-slate-500 block">
                    {pendingTrainees.length} pending approvals
                  </span>
                </button>

                <button
                  onClick={() => setSelectedTab('reports')}
                  className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-[#386B39] text-left cursor-pointer transition-all space-y-1"
                >
                  <BarChart3 className="w-5 h-5 text-[#9C6800]" />
                  <span className="text-xs font-black text-slate-900 block">Reports &amp; Export</span>
                  <span className="text-[10px] text-slate-500 block">Download CSV data</span>
                </button>

                <button
                  onClick={() => setSelectedTab('geofence')}
                  className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-[#386B39] text-left cursor-pointer transition-all space-y-1"
                >
                  <MapPin className="w-5 h-5 text-[#BA1A1A]" />
                  <span className="text-xs font-black text-slate-900 block">Geofence Setup</span>
                  <span className="text-[10px] text-slate-500 block">
                    Radius: {Math.round(instituteSettings.radiusMeters)}m
                  </span>
                </button>
              </div>

              {/* System Metric Cards (4 Grid) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Active Trades</span>
                  <span className="text-2xl font-black text-slate-900 block mt-1">{stats.totalTrades}</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Enrolled Trainees</span>
                  <span className="text-2xl font-black text-[#386B39] block mt-1">{stats.totalTrainees}</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Trade Instructors</span>
                  <span className="text-2xl font-black text-[#2E627B] block mt-1">{stats.totalInstructors}</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Pending Approvals</span>
                  <span className="text-2xl font-black text-[#9C6800] block mt-1">
                    {stats.pendingTraineeApprovals + stats.pendingInstructorRegistrations}
                  </span>
                </div>
              </div>

              {/* Today's Institute Attendance Card */}
              <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">
                      CAMPUS ATTENDANCE
                    </span>
                    <h4 className="text-sm font-black text-slate-900">
                      Today: {DateUtils.formatDateForDisplay(DateUtils.getTodayDateString())}
                    </h4>
                  </div>
                  <span className="text-xl sm:text-2xl font-black text-[#386B39]">
                    {stats.attendancePercentage.toFixed(1)}%
                  </span>
                </div>

                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-[#386B39] h-full transition-all"
                    style={{ width: `${Math.min(100, Math.max(0, stats.attendancePercentage))}%` }}
                  />
                </div>

                <div className="grid grid-cols-3 gap-2 pt-1 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Present</span>
                    <span className="text-base font-black text-[#386B39]">{stats.presentToday}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Late</span>
                    <span className="text-base font-black text-[#9C6800]">{stats.lateToday}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Absent</span>
                    <span className="text-base font-black text-[#BA1A1A]">{stats.absentToday}</span>
                  </div>
                </div>
              </div>

              {/* Pending Approvals Banners */}
              {pendingInstructors.length > 0 && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-black text-amber-900">Pending Instructor Registrations</h4>
                    <p className="text-[11px] text-amber-700 font-medium">
                      {pendingInstructors.length} instructors awaiting admin clearance
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedTab('staff')}
                    className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs cursor-pointer shadow-xs"
                  >
                    Verify Instructors
                  </button>
                </div>
              )}

              {pendingTrainees.length > 0 && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-black text-emerald-900">Pending Trainee Admissions</h4>
                    <p className="text-[11px] text-emerald-700 font-medium">
                      {pendingTrainees.length} trainee applications to review
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedTab('trainees')}
                    className="px-3.5 py-1.5 rounded-xl bg-[#386B39] hover:bg-[#2e592f] text-white font-bold text-xs cursor-pointer shadow-xs"
                  >
                    Review Trainees
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: DAILY LOG */}
          {selectedTab === 'daily' && (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-2">
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => e.target.value && setSelectedDate(e.target.value)}
                    className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 bg-white cursor-pointer"
                  />
                  {selectedDate !== DateUtils.getTodayDateString() && (
                    <button
                      onClick={() => setSelectedDate(DateUtils.getTodayDateString())}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-bold text-slate-700 cursor-pointer"
                    >
                      Today
                    </button>
                  )}
                </div>

                <select
                  value={selectedTradeFilter}
                  onChange={(e) => setSelectedTradeFilter(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 bg-white"
                >
                  <option value="all">All Trades</option>
                  {trades.map((t) => (
                    <option key={t.tradeId} value={t.tradeId}>
                      {t.tradeName}
                    </option>
                  ))}
                </select>
              </div>

              {/* Holiday Notice if selected date is marked holiday */}
              {DateUtils.isHoliday(selectedDate, settingsForm.holidays) && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center space-x-3 text-xs">
                  <div className="p-2 rounded-xl bg-amber-100 text-amber-800 shrink-0">
                    <CalendarDays className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-black text-amber-900">
                      Official Institutional Holiday: {settingsForm.holidays?.find((h) => h.date === selectedDate)?.title || 'Holiday'}
                    </h4>
                    <p className="text-amber-700 text-[11px] mt-0.5">
                      This date is declared as a holiday and excluded from working days. Trainees are not marked absent on marked holidays.
                    </p>
                  </div>
                </div>
              )}

              {/* Records List */}
              <div className="space-y-2.5">
                {dailyAttendance.length === 0 ? (
                  <EmptyStateView
                    icon={<Calendar className="w-8 h-8" />}
                    title="No Punches Recorded"
                    subtitle={`No attendance entries logged for ${DateUtils.formatDateForDisplay(selectedDate)}.`}
                  />
                ) : (
                  dailyAttendance
                    .filter((r) => selectedTradeFilter === 'all' || r.tradeId === selectedTradeFilter)
                    .map((rec) => (
                      <div
                        key={rec.attendanceId}
                        className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                      >
                        <div>
                          <div className="flex items-center space-x-2">
                            <h4 className="text-sm font-black text-slate-900">{rec.traineeName}</h4>
                            <span className="font-mono font-bold text-[11px] text-[#386B39]">
                              {rec.traineeUniqueId}
                            </span>
                            <span className="text-slate-400">• {rec.tradeName}</span>
                          </div>
                          <div className="text-[11px] text-slate-500 mt-1 flex flex-wrap gap-x-3">
                            <span>In: {DateUtils.formatTime(rec.punchInTime)}</span>
                            <span>Out: {DateUtils.formatTime(rec.punchOutTime)}</span>
                            {rec.punchInDistance != null && (
                              <span>Dist: {rec.punchInDistance.toFixed(1)}m</span>
                            )}
                          </div>
                          {rec.remarks && (
                            <p className="text-[10px] text-[#9C6800] mt-1 font-medium">{rec.remarks}</p>
                          )}
                        </div>

                        <div className="flex items-center space-x-2 shrink-0">
                          <StatusBadge status={rec.attendanceStatus} />
                          <button
                            onClick={() => {
                              setCorrectingRecord(rec);
                              setCorrectionStatus(rec.attendanceStatus);
                            }}
                            className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs cursor-pointer flex items-center space-x-1"
                          >
                            <Edit2 className="w-3.5 h-3.5 text-[#386B39]" />
                            <span>Correct</span>
                          </button>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>
          )}

          {/* TAB 3: MONTHLY */}
          {selectedTab === 'monthly' && (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-slate-900">Monthly Attendance Aggregation</h3>
                  <p className="text-xs text-slate-500">{DateUtils.getCurrentMonthYear()}</p>
                </div>
                <button
                  onClick={() => handleExportCsv('month')}
                  className="px-3.5 py-1.5 rounded-xl bg-[#386B39] text-white font-bold text-xs flex items-center space-x-1.5 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Month CSV</span>
                </button>
              </div>

              <div className="space-y-3">
                {trades.map((trade) => {
                  const tradeRecords = monthlyAttendance.filter((m) => m.tradeId === trade.tradeId);
                  const tradeTrainees = trainees.filter((t) => t.tradeId === trade.tradeId && t.status === 'approved');
                  const present = tradeRecords.filter((r) => r.attendanceStatus === 'present' || r.attendanceStatus === 'late').length;
                  const total = tradeRecords.length;
                  const rate = total > 0 ? (present / total) * 100 : 0;

                  return (
                    <div key={trade.tradeId} className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-sm font-black text-slate-900">{trade.tradeName}</h4>
                          <span className="text-xs text-slate-500 font-medium">
                            {tradeTrainees.length} Active Trainees • {trade.tradeCode}
                          </span>
                        </div>
                        <span className="text-lg font-black text-[#386B39]">{rate.toFixed(1)}%</span>
                      </div>

                      <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                        <div className="bg-[#386B39] h-full transition-all" style={{ width: `${rate}%` }} />
                      </div>

                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Total Punches: {total}</span>
                        <span className="text-[#386B39] font-bold">Present: {present}</span>
                        <span className="text-[#BA1A1A] font-bold">Absent: {total - present}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: SUMMARY */}
          {selectedTab === 'summary' && (
            <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs p-5 space-y-4">
              <div>
                <h3 className="text-sm font-black text-slate-900">Institute Cumulative Trade Performance</h3>
                <p className="text-xs text-slate-500">Overview of all active departments and attendance ratios</p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="py-2.5 px-3">Trade Name</th>
                      <th className="py-2.5 px-3">Code</th>
                      <th className="py-2.5 px-3">Trainees</th>
                      <th className="py-2.5 px-3">Monthly Punches</th>
                      <th className="py-2.5 px-3 text-right">Attendance Rate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {trades.map((trade) => {
                      const tCount = trainees.filter((t) => t.tradeId === trade.tradeId && t.status === 'approved').length;
                      const mRecords = monthlyAttendance.filter((m) => m.tradeId === trade.tradeId);
                      const pres = mRecords.filter((r) => r.attendanceStatus === 'present' || r.attendanceStatus === 'late').length;
                      const rate = mRecords.length > 0 ? (pres / mRecords.length) * 100 : 0;

                      return (
                        <tr key={trade.tradeId} className="hover:bg-slate-50 font-medium text-slate-800">
                          <td className="py-3 px-3 font-bold text-slate-900">{trade.tradeName}</td>
                          <td className="py-3 px-3 font-mono text-slate-500">{trade.tradeCode}</td>
                          <td className="py-3 px-3">{tCount} / {trade.totalSeats || 20}</td>
                          <td className="py-3 px-3">{mRecords.length}</td>
                          <td className="py-3 px-3 text-right font-black text-[#386B39]">{rate.toFixed(1)}%</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: TRADES */}
          {selectedTab === 'trades' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-black text-slate-900">Trade Departments ({trades.length})</h2>
                  <p className="text-xs text-slate-500">Configure courses, codes, and seat quotas</p>
                </div>
                <button
                  onClick={() => {
                    setEditingTrade(null);
                    setTradeName('');
                    setTradeCode('');
                    setTradeSeats(20);
                    setTradeDescription('');
                    setShowAddTradeModal(true);
                  }}
                  className="px-4 py-2.5 rounded-2xl bg-[#386B39] hover:bg-[#2e592f] text-white font-bold text-xs shadow-md shadow-[#386B39]/20 flex items-center space-x-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Trade</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {trades.map((trade) => {
                  const tradeTraineeCount = trainees.filter((t) => t.tradeId === trade.tradeId).length;
                  const tradeInstructors = instructors.filter((i) => i.tradeId === trade.tradeId);

                  return (
                    <div key={trade.tradeId} className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 font-mono text-[10px] font-bold text-slate-700">
                            {trade.tradeCode}
                          </span>
                          <h4 className="text-sm font-black text-slate-900 mt-1">{trade.tradeName}</h4>
                        </div>
                        <div className="flex items-center space-x-1">
                          <button
                            onClick={() => {
                              setEditingTrade(trade);
                              setTradeName(trade.tradeName);
                              setTradeCode(trade.tradeCode);
                              setTradeSeats(trade.totalSeats || 20);
                              setTradeDescription(trade.description || '');
                              setShowAddTradeModal(true);
                            }}
                            className="p-1.5 text-slate-500 hover:text-[#386B39] rounded-lg cursor-pointer"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteTrade(trade.tradeId, trade.tradeName)}
                            className="p-1.5 text-slate-500 hover:text-red-600 rounded-lg cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {trade.description && (
                        <p className="text-xs text-slate-600 font-medium leading-relaxed">{trade.description}</p>
                      )}

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-600">
                        <span>Enrolled: {tradeTraineeCount} Trainees</span>
                        <span>Staff: {tradeInstructors.length} Instructors</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: INSTRUCTORS */}
          {selectedTab === 'staff' && (
            <div className="space-y-4">
              <div>
                <h2 className="text-base font-black text-slate-900">
                  Instructors ({instructors.length})
                </h2>
                <p className="text-xs text-slate-500">
                  Manage trade instructors, approve registrations and access permissions
                </p>
              </div>

              {/* Pending Instructors Section */}
              {pendingInstructors.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-xs font-black uppercase tracking-wider text-amber-800">
                    Pending Instructor Approvals ({pendingInstructors.length})
                  </h3>
                  <div className="space-y-2.5">
                    {pendingInstructors.map((inst) => (
                      <div key={inst.uid} className="bg-amber-50/50 p-4 rounded-2xl border border-amber-200 shadow-xs space-y-2">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="text-sm font-black text-slate-900">{inst.name}</h4>
                            <p className="text-xs text-slate-600">
                              Trade: {inst.tradeName} | Email: {inst.email}
                            </p>
                            <p className="text-xs text-slate-500">Contact: {inst.contact}</p>
                          </div>
                          <StatusBadge status="pending" />
                        </div>
                        <div className="flex justify-end space-x-2 pt-1">
                          <button
                            onClick={() => handleRejectInstructor(inst.uid)}
                            className="px-3.5 py-1.5 rounded-xl border border-red-200 text-red-700 font-bold text-xs hover:bg-red-50 cursor-pointer"
                          >
                            Reject
                          </button>
                          <button
                            onClick={() => handleApproveInstructor(inst.uid)}
                            className="px-4 py-1.5 rounded-xl bg-[#386B39] text-white font-bold text-xs hover:bg-[#2e592f] shadow-xs cursor-pointer"
                          >
                            Approve Staff
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Approved Instructors */}
              <div className="space-y-3">
                {instructors.map((inst) => (
                  <div key={inst.uid} className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center space-x-2">
                        <h4 className="text-sm font-black text-slate-900">{inst.name}</h4>
                        <span className="px-2 py-0.5 rounded-md bg-[#D8E7D8] text-[#111F11] font-bold text-[11px]">
                          {inst.tradeName}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1 space-x-3">
                        <span>Email: {inst.email}</span>
                        <span>Phone: {inst.contact}</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 shrink-0">
                      <StatusBadge status={inst.status} />
                      <button
                        onClick={() => handleToggleInstructorStatus(inst)}
                        className={`px-3 py-1.5 rounded-xl font-bold text-xs border cursor-pointer ${
                          inst.status === 'approved'
                            ? 'border-red-200 text-red-700 hover:bg-red-50'
                            : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
                        }`}
                      >
                        {inst.status === 'approved' ? 'Deactivate' : 'Activate'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: TRAINEES */}
          {selectedTab === 'trainees' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-base font-black text-slate-900">
                    Trainee Directory ({filteredTrainees.length})
                  </h2>
                  <p className="text-xs text-slate-500">
                    Approvals, Trainee IDs, Parent PINs &amp; Roster Management
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <select
                    value={selectedTradeFilter}
                    onChange={(e) => setSelectedTradeFilter(e.target.value)}
                    className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-800 bg-white"
                  >
                    <option value="all">All Trades</option>
                    {trades.map((t) => (
                      <option key={t.tradeId} value={t.tradeId}>
                        {t.tradeName}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={traineeSearch}
                  onChange={(e) => setTraineeSearch(e.target.value)}
                  placeholder="Search by trainee name or ID..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 text-xs bg-white focus:ring-2 focus:ring-[#386B39] outline-hidden shadow-xs"
                />
              </div>

              {/* Trainee Cards */}
              <div className="space-y-3">
                {filteredTrainees.length === 0 ? (
                  <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center text-xs text-slate-500 font-medium shadow-xs">
                    No trainees found matching your active filter or search query.
                  </div>
                ) : (
                  filteredTrainees.map((trainee) => (
                  <div key={trainee.uid} className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="text-sm font-black text-slate-900">{trainee.name}</h4>
                          <span className="text-xs font-bold text-[#386B39]">{trainee.tradeName}</span>
                        </div>
                        <p className="text-xs text-slate-500 font-medium">Father: {trainee.parentage}</p>
                      </div>
                      <StatusBadge status={trainee.status} />
                    </div>

                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase block">TRAINEE ID</span>
                        <span className="font-mono font-bold text-[#386B39]">{trainee.traineeId}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] font-bold text-slate-400 uppercase block">PARENT PIN</span>
                        <span className="font-mono font-bold text-[#9C6800]">{trainee.parentAccessPin || '1234'}</span>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-500">
                      <span>Phone: {trainee.contact} | Email: {trainee.email}</span>
                      {trainee.guardianContact && <span className="block">Guardian: {trainee.guardianContact}</span>}
                    </div>

                    <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
                      {trainee.status === 'pending' ? (
                        <>
                          <button
                            onClick={() => setRejectingTraineeUid(trainee.uid)}
                            className="px-3.5 py-1.5 rounded-xl border border-red-200 text-red-700 font-bold text-xs hover:bg-red-50 cursor-pointer"
                          >
                            Reject
                          </button>
                          <button
                            onClick={() => handleApproveTrainee(trainee.uid)}
                            className="px-4 py-1.5 rounded-xl bg-[#386B39] hover:bg-[#2e592f] text-white font-bold text-xs shadow-xs cursor-pointer"
                          >
                            Approve &amp; Generate ID
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            onClick={async () => {
                              setHistoryModalTrainee(trainee);
                              const h = await getTraineeAttendanceHistory(trainee.uid, trainee.traineeId);
                              setHistoryRecords(h);
                            }}
                            className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 font-bold text-xs text-slate-700 cursor-pointer"
                          >
                            History
                          </button>
                          <button
                            onClick={() => handleToggleTraineeStatus(trainee)}
                            className={`px-3 py-1.5 rounded-xl font-bold text-xs border cursor-pointer ${
                              trainee.status === 'approved'
                                ? 'border-red-200 text-red-700 hover:bg-red-50'
                                : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
                            }`}
                          >
                            {trainee.status === 'approved' ? 'Deactivate' : 'Activate'}
                          </button>
                          <button
                            onClick={() => {
                              setModifyingTrainee(trainee);
                              setEditName(trainee.name);
                              setEditParentage(trainee.parentage);
                              setEditContact(trainee.contact);
                              setEditGuardianContact(trainee.guardianContact || '');
                              setEditAddress(trainee.address || '');
                            }}
                            className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 font-bold text-xs text-slate-700 cursor-pointer"
                          >
                            Modify
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                )))}
              </div>
            </div>
          )}

          {/* TAB 8: REPORTS */}
          {selectedTab === 'reports' && (
            <div className="space-y-4">
              <div>
                <h2 className="text-base font-black text-slate-900">Institute Reports &amp; Exports</h2>
                <p className="text-xs text-slate-500">Download formatted CSV reports for official auditing</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
                  <h4 className="text-sm font-black text-slate-900">Day-Wise Attendance Export</h4>
                  <p className="text-xs text-slate-500">
                    Export attendance record for date: {DateUtils.formatDateForDisplay(selectedDate)}
                  </p>
                  <button
                    onClick={() => handleExportCsv('day')}
                    className="w-full py-2.5 rounded-xl bg-[#386B39] text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-sm cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Day CSV ({dailyAttendance.length} records)</span>
                  </button>
                </div>

                <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
                  <h4 className="text-sm font-black text-slate-900">Monthly Attendance Export</h4>
                  <p className="text-xs text-slate-500">
                    Export cumulative monthly records for {DateUtils.getCurrentMonthYear()}
                  </p>
                  <button
                    onClick={() => handleExportCsv('month')}
                    className="w-full py-2.5 rounded-xl bg-[#2E627B] text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-sm cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Month CSV ({monthlyAttendance.length} records)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 9: SETTINGS */}
          {selectedTab === 'geofence' && (
            <div className="space-y-5">
              <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-5">
                <div>
                  <h2 className="text-base font-black text-slate-900">Campus Settings &amp; Shifts</h2>
                  <p className="text-xs text-slate-500">
                    Configure GPS boundary and working hours for automatic attendance validation
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Campus Latitude</label>
                    <input
                      type="number"
                      step="0.000001"
                      value={settingsForm.latitude}
                      onChange={(e) =>
                        setSettingsForm({ ...settingsForm, latitude: parseFloat(e.target.value) || 0 })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Campus Longitude</label>
                    <input
                      type="number"
                      step="0.000001"
                      value={settingsForm.longitude}
                      onChange={(e) =>
                        setSettingsForm({ ...settingsForm, longitude: parseFloat(e.target.value) || 0 })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Allowed Geofence Radius (Meters): {Math.round(settingsForm.radiusMeters)}m
                    </label>
                    <input
                      type="range"
                      min="50"
                      max="1000"
                      step="10"
                      value={settingsForm.radiusMeters}
                      onChange={(e) =>
                        setSettingsForm({ ...settingsForm, radiusMeters: parseInt(e.target.value) || 100 })
                      }
                      className="w-full accent-[#386B39]"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Grace Period (Minutes)</label>
                    <input
                      type="number"
                      value={settingsForm.gracePeriodMinutes}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          gracePeriodMinutes: parseInt(e.target.value) || 15,
                        })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Shift 1 Timing</label>
                    <input
                      type="text"
                      value={settingsForm.shift1Timing}
                      onChange={(e) =>
                        setSettingsForm({ ...settingsForm, shift1Timing: e.target.value })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Shift 2 Timing</label>
                    <input
                      type="text"
                      value={settingsForm.shift2Timing}
                      onChange={(e) =>
                        setSettingsForm({ ...settingsForm, shift2Timing: e.target.value })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">CutOff Time (e.g. 11:00)</label>
                    <input
                      type="text"
                      value={settingsForm.cutoffTime || ''}
                      placeholder="e.g. 11:00"
                      onChange={(e) =>
                        setSettingsForm({ ...settingsForm, cutoffTime: e.target.value })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
                  <button
                    onClick={handleUseCurrentLocation}
                    type="button"
                    className="px-4 py-2 rounded-xl border border-[#386B39] text-[#386B39] font-bold text-xs hover:bg-[#D8E7D8]/30 flex items-center space-x-1.5 cursor-pointer"
                  >
                    <MapPin className="w-4 h-4" />
                    <span>Use Device Current GPS</span>
                  </button>

                  <button
                    onClick={handleSaveSettings}
                    type="button"
                    className="px-6 py-2.5 rounded-xl bg-[#386B39] hover:bg-[#2e592f] text-white font-bold text-xs shadow-md shadow-[#386B39]/20 cursor-pointer"
                  >
                    Save Settings
                  </button>
                </div>
              </div>

              {/* MARK HOLIDAYS SECTION */}
              <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h2 className="text-base font-black text-slate-900">Mark Holidays</h2>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-[#D8E7D8] text-[#386B39]">
                        {settingsForm.holidays?.length || 0} Declared
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Select a date to mark it as an official holiday. Marked holidays are automatically excluded from working days in attendance reports and trainee calculations.
                    </p>
                  </div>
                </div>

                {/* Form to mark holiday */}
                <form onSubmit={handleAddHoliday} className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                  <div className="flex items-center space-x-2 text-xs font-bold text-slate-800">
                    <CalendarDays className="w-4 h-4 text-[#386B39]" />
                    <span>Declare New Holiday</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        Select Date <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="date"
                        required
                        value={holidayDate}
                        onChange={(e) => setHolidayDate(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium text-slate-800 cursor-pointer"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        Holiday Name / Occasion <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Eid-ul-Fitr / Diwali / National Holiday"
                        value={holidayTitle}
                        onChange={(e) => setHolidayTitle(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Description / Order No. (Optional)</label>
                      <input
                        type="text"
                        placeholder="e.g. Govt Holiday Order / Campus Maintenance"
                        value={holidayDescription}
                        onChange={(e) => setHolidayDescription(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-1">
                    <button
                      type="submit"
                      disabled={isSavingHoliday || !holidayDate || !holidayTitle.trim()}
                      className="px-5 py-2.5 rounded-xl bg-[#386B39] hover:bg-[#2e592f] disabled:opacity-50 text-white font-bold text-xs shadow-sm flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{isSavingHoliday ? 'Marking Holiday...' : 'Mark Holiday'}</span>
                    </button>
                  </div>
                </form>

                {/* List of Marked Holidays */}
                <div className="space-y-2">
                  <h3 className="text-xs font-bold text-slate-700">Official Marked Holidays</h3>

                  {(!settingsForm.holidays || settingsForm.holidays.length === 0) ? (
                    <div className="p-6 rounded-2xl border border-dashed border-slate-200 text-center text-xs text-slate-400">
                      No holidays marked yet. Pick a date above to mark it as an official holiday.
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden">
                      {settingsForm.holidays.map((h) => {
                        const dayName = new Date(h.date + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'long' });
                        const displayDate = DateUtils.formatDateForDisplay(h.date);
                        return (
                          <div
                            key={h.id || h.date}
                            className="p-3.5 bg-white hover:bg-slate-50 flex items-center justify-between gap-3 text-xs"
                          >
                            <div className="flex items-center space-x-3 min-w-0">
                              <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 shrink-0">
                                <CalendarDays className="w-4 h-4" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center space-x-2">
                                  <span className="font-black text-slate-900 truncate">{h.title}</span>
                                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-600">
                                    {dayName}
                                  </span>
                                </div>
                                <div className="text-[11px] text-slate-500 mt-0.5 flex flex-wrap items-center gap-x-2">
                                  <span className="font-bold text-[#386B39]">{displayDate}</span>
                                  {h.description && <span>• {h.description}</span>}
                                  <span className="text-slate-400">• Added by {h.createdBy || 'Admin'}</span>
                                </div>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => handleDeleteHoliday(h.id || h.date, h.title)}
                              className="px-3 py-1.5 rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-600 font-bold text-xs shrink-0 cursor-pointer flex items-center space-x-1"
                              title="Delete this holiday"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline text-[11px]">Remove</span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 10: NOTICES */}
          {selectedTab === 'notices' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-black text-slate-900">Institute Announcements</h2>
                  <p className="text-xs text-slate-500">Official broadcasts sent to staff, trainees &amp; parents</p>
                </div>
                <button
                  onClick={() => setShowNoticeModal(true)}
                  className="px-4 py-2.5 rounded-2xl bg-[#386B39] text-white font-bold text-xs flex items-center space-x-1.5 shadow-sm cursor-pointer"
                >
                  <Megaphone className="w-4 h-4" />
                  <span>Create Notice</span>
                </button>
              </div>

              <div className="space-y-3">
                {notifications.map((n) => (
                  <div key={n.notificationId} className="bg-white p-4 rounded-2xl border border-slate-200/80 space-y-2 shadow-xs">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="text-xs sm:text-sm font-black text-slate-900">{n.title}</h4>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {n.senderName} • {DateUtils.formatDateTime(n.timestamp)}
                        </span>
                      </div>
                      <button
                        onClick={async () => {
                          await deleteNotification(n.notificationId);
                          loadData();
                        }}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 font-medium leading-relaxed">
                      {n.message}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 11: AUDIT */}
          {selectedTab === 'audit' && (
            <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs p-5 space-y-3 text-xs">
              <div>
                <h3 className="text-sm font-black text-slate-900">System Security &amp; Audit Trail</h3>
                <p className="text-xs text-slate-500">
                  Immutable log of administrative approvals, corrections, and modifications
                </p>
              </div>

              <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1">
                {auditLogs.length === 0 ? (
                  <p className="text-center py-6 text-slate-400">No audit log entries recorded yet.</p>
                ) : (
                  auditLogs.map((log) => (
                    <div
                      key={log.logId}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1"
                    >
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-extrabold text-[#386B39] uppercase">{log.actionType}</span>
                        <span className="text-slate-400">{DateUtils.formatDateTime(log.timestamp)}</span>
                      </div>
                      <p className="font-semibold text-slate-800">{log.description}</p>
                      <p className="text-[10px] text-slate-500">
                        Performed by: {log.performedByName} ({log.performedByRole.toUpperCase()})
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </main>
      </div>

      <DeveloperCreditFooter />

      {/* Add / Edit Trade Modal */}
      {showAddTradeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs">
            <h3 className="text-sm font-black text-slate-900">
              {editingTrade ? 'Edit Trade Department' : 'Add New Trade'}
            </h3>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Trade Name *</label>
              <input
                type="text"
                value={tradeName}
                onChange={(e) => setTradeName(e.target.value)}
                placeholder="e.g. Electrician, COPA, Plumber"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Trade Code *</label>
              <input
                type="text"
                value={tradeCode}
                onChange={(e) => setTradeCode(e.target.value.toUpperCase())}
                placeholder="e.g. ELEC, COPA, PLUM"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Total Allocated Seats</label>
              <input
                type="number"
                value={tradeSeats}
                onChange={(e) => setTradeSeats(parseInt(e.target.value) || 20)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Description / Remarks</label>
              <textarea
                rows={2}
                value={tradeDescription}
                onChange={(e) => setTradeDescription(e.target.value)}
                placeholder="Course duration, syllabus details..."
                className="w-full p-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowAddTradeModal(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveTrade}
                disabled={!tradeName.trim() || !tradeCode.trim()}
                className="px-5 py-2 rounded-xl bg-[#386B39] text-white font-bold hover:bg-[#2e592f] shadow-sm disabled:opacity-40 cursor-pointer"
              >
                Save Trade
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Broadcast Modal */}
      {showNoticeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs">
            <h3 className="text-sm font-black text-slate-900">Institute Official Announcement</h3>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Target Audience *</label>
              <select
                value={noticeTargetRole}
                onChange={(e) => setNoticeTargetRole(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-800"
              >
                <option value="all">Everyone (Staff, Trainees, Parents)</option>
                <option value="instructor">All Trade Instructors</option>
                <option value="trainee">All Trainees</option>
                <option value="parent">All Parents</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Filter by Trade (Optional)</label>
              <select
                value={noticeTargetTradeId || ''}
                onChange={(e) => setNoticeTargetTradeId(e.target.value || null)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-800"
              >
                <option value="">All Trades (Global Broadcast)</option>
                {trades.map((t) => (
                  <option key={t.tradeId} value={t.tradeId}>
                    {t.tradeName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Notice Title *</label>
              <input
                type="text"
                value={noticeTitle}
                onChange={(e) => setNoticeTitle(e.target.value)}
                placeholder="e.g. Holiday Notice, Practical Exam Schedule"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Notice Message *</label>
              <textarea
                rows={4}
                value={noticeMessage}
                onChange={(e) => setNoticeMessage(e.target.value)}
                placeholder="Enter detailed notice content..."
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowNoticeModal(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSendNotice}
                disabled={!noticeTitle.trim() || !noticeMessage.trim()}
                className="px-5 py-2 rounded-xl bg-[#386B39] text-white font-bold hover:bg-[#2e592f] shadow-sm disabled:opacity-40 cursor-pointer"
              >
                Broadcast Notice
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Attendance Correction Dialog */}
      {correctingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs">
            <h3 className="text-sm font-black text-slate-900">Admin Attendance Override</h3>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <p className="font-bold text-slate-900">
                Trainee: {correctingRecord.traineeName} ({correctingRecord.traineeUniqueId})
              </p>
              <p className="text-slate-500">Date: {DateUtils.formatDateForDisplay(correctingRecord.date)}</p>
              <p className="text-slate-500">Current Status: {correctingRecord.attendanceStatus.toUpperCase()}</p>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Select Corrected Status:</label>
              <div className="flex flex-wrap gap-1.5">
                {['present', 'late', 'absent', 'half_day', 'leave'].map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setCorrectionStatus(st)}
                    className={`px-3 py-1.5 rounded-xl font-bold capitalize transition-all cursor-pointer ${
                      correctionStatus === st
                        ? 'bg-[#386B39] text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {st.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Reason for Admin Correction (Mandatory):</label>
              <textarea
                rows={2}
                value={correctionReason}
                onChange={(e) => setCorrectionReason(e.target.value)}
                placeholder="e.g. Official Duty / Verified Attendance discrepancy"
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 outline-hidden focus:ring-2 focus:ring-[#386B39]"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setCorrectingRecord(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCorrection}
                disabled={!correctionReason.trim()}
                className="px-5 py-2 rounded-xl bg-[#386B39] text-white font-bold hover:bg-[#2e592f] shadow-sm disabled:opacity-40 cursor-pointer"
              >
                Save Correction
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Trainee Rejection Dialog */}
      {rejectingTraineeUid && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs">
            <h3 className="text-sm font-black text-slate-900">Reject Trainee Admission</h3>
            <p className="text-slate-500">Provide official reason for rejection:</p>
            <textarea
              rows={3}
              value={traineeRejectionReason}
              onChange={(e) => setTraineeRejectionReason(e.target.value)}
              placeholder="e.g. Ineligible as per ITI admission criteria"
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50"
            />
            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setRejectingTraineeUid(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleRejectTrainee}
                className="px-5 py-2 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 shadow-sm cursor-pointer"
              >
                Reject Application
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Trainee Modify Modal */}
      {modifyingTrainee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs max-h-[90vh] overflow-y-auto">
            <h3 className="text-sm font-black text-slate-900">Admin Modify Trainee Details</h3>
            <p className="text-slate-500 font-mono text-[11px]">ID: {modifyingTrainee.traineeId}</p>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Full Name *</label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Father / Parentage</label>
              <input
                type="text"
                value={editParentage}
                onChange={(e) => setEditParentage(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Trainee Contact No.</label>
              <input
                type="tel"
                value={editContact}
                onChange={(e) => setEditContact(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Guardian Contact No.</label>
              <input
                type="tel"
                value={editGuardianContact}
                onChange={(e) => setEditGuardianContact(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Address</label>
              <input
                type="text"
                value={editAddress}
                onChange={(e) => setEditAddress(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setModifyingTrainee(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveTraineeModify}
                disabled={!editName.trim()}
                className="px-5 py-2 rounded-xl bg-[#386B39] text-white font-bold hover:bg-[#2e592f] shadow-sm disabled:opacity-40 cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Trainee History Modal */}
      {historyModalTrainee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs max-h-[85vh] flex flex-col">
            <h3 className="text-sm font-black text-slate-900">
              Attendance History: {historyModalTrainee.name}
            </h3>
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-0.5 text-[11px]">
              <p className="font-bold text-[#386B39]">ID: {historyModalTrainee.traineeId}</p>
              <p className="text-slate-500">Parent PIN: {historyModalTrainee.parentAccessPin}</p>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {historyRecords.length === 0 ? (
                <p className="text-center py-6 text-slate-400">No past attendance records found.</p>
              ) : (
                historyRecords.map((r) => (
                  <div
                    key={r.attendanceId || `${r.traineeId}_${r.date}`}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-slate-800 block">{DateUtils.formatDateForDisplay(r.date)}</span>
                      <span className="text-[10px] text-slate-500">
                        In: {DateUtils.formatTime(r.punchInTime)} | Out: {DateUtils.formatTime(r.punchOutTime)}
                      </span>
                    </div>
                    <StatusBadge status={r.attendanceStatus} />
                  </div>
                ))
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setHistoryModalTrainee(null)}
                className="px-4 py-2 rounded-xl bg-[#386B39] text-white font-bold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
