import React, { useState } from 'react';
import {
  ArrowLeft,
  RefreshCw,
  LogOut,
  Bell,
  Megaphone,
  User,
  MapPin,
  CheckCircle,
  Clock,
  AlertCircle,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Building,
  School,
  Users,
} from 'lucide-react';
import { InstituteNotification } from '../types';
import { DateUtils, ITI_DEVELOPER_CREDIT } from '../utils/itiUtils';

interface ItiTopAppBarProps {
  title: string;
  subtitle?: string | null;
  roleLabel?: string | null;
  notificationCount?: number;
  onBack?: () => void;
  onRefresh?: () => void;
  onLogout?: () => void;
  onNotificationClick?: () => void;
  onBroadcast?: () => void;
}

export const ItiTopAppBar: React.FC<ItiTopAppBarProps> = ({
  title,
  subtitle,
  roleLabel,
  notificationCount = 0,
  onBack,
  onRefresh,
  onLogout,
  onNotificationClick,
  onBroadcast,
}) => {
  return (
    <header className="bg-[#386B39] text-white shadow-md sticky top-0 z-40 transition-colors">
      <div className="max-w-5xl mx-auto px-4 py-2.5">
        {/* Top Row */}
        <div className="flex items-center justify-between gap-2">
          {/* Left: Back (optional) + Title */}
          <div className="flex items-center space-x-2.5 min-w-0 flex-1">
            {onBack && (
              <button
                onClick={onBack}
                type="button"
                className="p-1.5 rounded-xl hover:bg-white/15 active:scale-95 transition-all text-white shrink-0"
                title="Back"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-white truncate">
                {title}
              </h1>
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center space-x-1 shrink-0">
            {onBroadcast && (
              <button
                onClick={onBroadcast}
                type="button"
                className="p-2 rounded-xl hover:bg-white/15 active:scale-95 transition-all text-white relative"
                title="Broadcast Announcement"
              >
                <Megaphone className="w-5 h-5" />
              </button>
            )}

            {onNotificationClick && (
              <button
                onClick={onNotificationClick}
                type="button"
                className="p-2 rounded-xl hover:bg-white/15 active:scale-95 transition-all text-white relative"
                title="Announcements"
              >
                <Bell className="w-5 h-5" />
                {notificationCount > 0 && (
                  <span className="absolute top-1 right-1 bg-[#9C6800] text-white font-bold text-[10px] min-w-4 h-4 px-1 rounded-full flex items-center justify-center border border-white">
                    {notificationCount > 9 ? '9+' : notificationCount}
                  </span>
                )}
              </button>
            )}

            {onRefresh && (
              <button
                onClick={onRefresh}
                type="button"
                className="p-2 rounded-xl hover:bg-white/15 active:scale-95 transition-all text-white"
                title="Refresh Data"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            )}

            {onLogout && (
              <button
                onClick={onLogout}
                type="button"
                className="p-2 rounded-xl hover:bg-red-500/30 active:scale-95 transition-all text-white"
                title="Sign Out"
              >
                <LogOut className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Sub-row: Subtitle / Role Badge */}
        {(subtitle || roleLabel) && (
          <div className="mt-1 flex items-center justify-end">
            <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-[#D8E7D8] text-[#111F11] text-[11px] font-bold shadow-xs">
              <User className="w-3 h-3 text-[#386B39]" />
              <span>{subtitle || (roleLabel || '').toUpperCase()}</span>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export const StatusBadge: React.FC<{ status: string; className?: string }> = ({
  status,
  className = '',
}) => {
  const normalized = (status || '').toLowerCase();

  let bg = 'bg-slate-100 text-slate-700';
  let label = status ? status.charAt(0).toUpperCase() + status.slice(1) : 'Not Marked';

  if (normalized === 'present' || normalized === 'approved' || normalized === 'active') {
    bg = 'bg-[#386B39]/15 text-[#386B39] border border-[#386B39]/30';
    label = normalized === 'present' ? 'Present' : normalized === 'approved' ? 'Approved' : 'Active';
  } else if (normalized === 'late') {
    bg = 'bg-[#9C6800]/15 text-[#9C6800] border border-[#9C6800]/30';
    label = 'Late';
  } else if (normalized === 'absent' || normalized === 'rejected') {
    bg = 'bg-[#BA1A1A]/15 text-[#BA1A1A] border border-[#BA1A1A]/30';
    label = normalized === 'absent' ? 'Absent' : 'Rejected';
  } else if (normalized === 'half_day' || normalized === 'half-day') {
    bg = 'bg-[#2E627B]/15 text-[#2E627B] border border-[#2E627B]/30';
    label = 'Half Day';
  } else if (normalized === 'leave') {
    bg = 'bg-[#2E627B]/15 text-[#2E627B] border border-[#2E627B]/30';
    label = 'Leave';
  } else if (normalized === 'pending') {
    bg = 'bg-[#8B6612]/15 text-[#8B6612] border border-[#8B6612]/30';
    label = 'Pending';
  } else if (normalized === 'inactive' || normalized === 'deactivated') {
    bg = 'bg-gray-200 text-gray-700 border border-gray-300';
    label = 'Inactive';
  } else if (normalized === 'not_marked' || normalized === 'unmarked') {
    bg = 'bg-slate-100 text-slate-600 border border-slate-200';
    label = 'Not Marked';
  }

  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-extrabold tracking-wide ${bg} ${className}`}
    >
      {label}
    </span>
  );
};

export const GeofenceDistanceCard: React.FC<{
  distanceMeters?: number | null;
  isWithinRadius?: boolean | null;
  radiusMeters?: number;
  isChecking?: boolean;
  onCheckGps: () => void;
}> = ({
  distanceMeters,
  isWithinRadius,
  radiusMeters = 100.0,
  isChecking = false,
  onCheckGps,
}) => {
  const isInside = isWithinRadius === true;

  return (
    <div
      className={`rounded-3xl p-5 sm:p-6 transition-all border shadow-sm text-center ${
        isInside
          ? 'bg-[#D8E7D8]/50 border-[#386B39]/40'
          : 'bg-white border-slate-200/80'
      }`}
    >
      {/* Circle Icon */}
      <div className="w-16 h-16 rounded-full bg-white shadow-xs mx-auto flex items-center justify-center mb-3">
        <MapPin
          className={`w-8 h-8 ${isInside ? 'text-[#386B39]' : isWithinRadius === false ? 'text-[#BA1A1A]' : 'text-slate-400'}`}
        />
      </div>

      <h3
        className={`text-base sm:text-lg font-extrabold ${
          isInside
            ? 'text-[#386B39]'
            : isWithinRadius === false
            ? 'text-[#BA1A1A]'
            : 'text-slate-800'
        }`}
      >
        {isWithinRadius === true
          ? 'Inside Institute Boundary'
          : isWithinRadius === false
          ? 'Outside Institute Boundary'
          : 'Verify Institute GPS Location'}
      </h3>

      <p className="text-xs text-slate-600 mt-1 max-w-sm mx-auto">
        {distanceMeters != null
          ? `Distance: ${distanceMeters.toFixed(1)} meters from institute center (Allowed: ≤ ${Math.round(radiusMeters)}m)`
          : `Allowed attendance radius: within ${Math.round(radiusMeters)} meters`}
      </p>

      {/* Pulse Status Pill */}
      <div className="mt-3.5 inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-slate-100/90 border border-slate-200 text-xs font-bold">
        <span
          className={`w-2.5 h-2.5 rounded-full ${
            isInside
              ? 'bg-[#386B39] animate-pulse'
              : isWithinRadius === false
              ? 'bg-[#BA1A1A]'
              : 'bg-amber-500'
          }`}
        />
        <span
          className={
            isInside
              ? 'text-[#386B39]'
              : isWithinRadius === false
              ? 'text-[#BA1A1A]'
              : 'text-amber-700'
          }
        >
          {isWithinRadius === true
            ? 'GPS Geofence: Active & Verified'
            : isWithinRadius === false
            ? 'Location: Out of Permitted Range'
            : 'GPS Signal: Waiting Verification'}
        </span>
      </div>

      {/* Re-verify GPS Button */}
      <div className="mt-4">
        <button
          onClick={onCheckGps}
          disabled={isChecking}
          type="button"
          className="w-full sm:w-auto px-6 py-2.5 rounded-2xl bg-[#D8E7D8] hover:bg-[#c9ddc9] text-[#111F11] font-bold text-xs inline-flex items-center justify-center space-x-2 border border-[#386B39]/30 active:scale-98 transition-all disabled:opacity-50 cursor-pointer"
        >
          <RefreshCw className={`w-4 h-4 text-[#386B39] ${isChecking ? 'animate-spin' : ''}`} />
          <span>{isChecking ? 'Checking High-Accuracy GPS...' : 'Refresh GPS Location'}</span>
        </button>
      </div>
    </div>
  );
};

export const EmptyStateView: React.FC<{
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  action?: React.ReactNode;
}> = ({ icon, title, subtitle, action }) => {
  return (
    <div className="p-8 text-center flex flex-col items-center justify-center max-w-md mx-auto">
      <div className="w-16 h-16 rounded-full bg-[#D8E7D8]/60 text-[#386B39] flex items-center justify-center mb-3">
        {icon}
      </div>
      <h4 className="text-sm font-bold text-slate-800">{title}</h4>
      <p className="text-xs text-slate-500 mt-1">{subtitle}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
};

export const DeveloperCreditFooter: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <footer className={`py-4 px-4 text-center ${className}`}>
      <p className="text-[11px] font-semibold text-slate-500/90 tracking-wide">
        {ITI_DEVELOPER_CREDIT}
      </p>
    </footer>
  );
};

export const InstituteNotificationPopupDialog: React.FC<{
  notifications: InstituteNotification[];
  onDismiss: (ids: string[]) => void;
}> = ({ notifications, onDismiss }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  if (notifications.length === 0) return null;

  const current = notifications[currentIndex] || notifications[0];

  const getAudience = (role: string) => {
    const r = (role || '').toLowerCase();
    if (r === 'both' || r === 'instructor_trainee') return { label: 'Both (Instructors & Trainees)', color: 'text-[#386B39] bg-[#386B39]/10' };
    if (r === 'instructor') return { label: 'Instructors Only', color: 'text-[#2E627B] bg-[#2E627B]/10' };
    if (r === 'trainee') return { label: 'Trainees Only', color: 'text-[#386B39] bg-[#386B39]/10' };
    if (r === 'parent') return { label: 'Parents Only', color: 'text-purple-700 bg-purple-100' };
    if (r === 'admin') return { label: 'Institute Administration', color: 'text-orange-700 bg-orange-100' };
    return { label: 'All (Institute-Wide)', color: 'text-[#386B39] bg-[#386B39]/10' };
  };

  const aud = getAudience(current.targetRole);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 text-center bg-[#FBFDF8] border-b border-slate-100 flex flex-col items-center">
          <div className="w-14 h-14 rounded-full bg-[#D8E7D8] text-[#386B39] flex items-center justify-center mb-2 shadow-xs">
            <Megaphone className="w-7 h-7" />
          </div>
          <span className="inline-block px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-[#9C6800]/15 text-[#9C6800] border border-[#9C6800]/30 mb-1">
            INSTITUTE ANNOUNCEMENT
          </span>
          <h2 className="text-base sm:text-lg font-black text-slate-900 mt-1">
            {current.title || 'Important Notice'}
          </h2>
          {notifications.length > 1 && (
            <span className="text-[11px] font-semibold text-slate-400 mt-0.5">
              Notice {currentIndex + 1} of {notifications.length}
            </span>
          )}
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1 text-xs">
          {/* Metadata Strip */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1.5">
            <div className={`inline-flex items-center px-2 py-0.5 rounded-lg text-[10px] font-bold ${aud.color}`}>
              <span>Addressed to: {aud.label}</span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium pt-1">
              <span>From: {current.senderName || 'Institute Administration'}</span>
              <span>{DateUtils.formatDateTime(current.timestamp)}</span>
            </div>
          </div>

          {/* Message Content */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 text-slate-800 leading-relaxed font-medium">
            <p className="whitespace-pre-wrap">{current.message}</p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2">
          {notifications.length > 1 ? (
            <div className="flex items-center space-x-1.5">
              <button
                disabled={currentIndex === 0}
                onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
                className="p-2 rounded-xl border border-slate-300 bg-white text-slate-700 disabled:opacity-30 cursor-pointer"
                title="Previous"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                disabled={currentIndex === notifications.length - 1}
                onClick={() => setCurrentIndex((prev) => Math.min(notifications.length - 1, prev + 1))}
                className="p-2 rounded-xl border border-slate-300 bg-white text-slate-700 disabled:opacity-30 cursor-pointer"
                title="Next"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div />
          )}

          <button
            onClick={() => onDismiss(notifications.map((n) => n.notificationId))}
            type="button"
            className="px-5 py-2.5 rounded-xl bg-[#386B39] hover:bg-[#2e592f] text-white font-bold text-xs shadow-md shadow-[#386B39]/20 active:scale-98 transition-all cursor-pointer"
          >
            Understood &amp; Close
          </button>
        </div>
      </div>
    </div>
  );
};
