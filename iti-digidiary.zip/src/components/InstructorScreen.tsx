import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Calendar,
  BookOpen,
  Users,
  UserCheck,
  Megaphone,
  BarChart3,
  Search,
  Plus,
  Edit2,
  Trash2,
  Download,
  CheckCircle,
  XCircle,
  Filter,
  Check,
  ChevronLeft,
  ChevronRight,
  History,
  Lock,
  BadgeAlert,
  ThumbsUp,
  ThumbsDown,
  Clock,
  MapPin,
  X,
  Send,
  User,
} from 'lucide-react';
import {
  InstructorProfile,
  TraineeProfile,
  AttendanceRecord,
  DiaryNote,
  InstituteNotification,
  DashboardStats,
  Trade,
} from '../types';
import {
  ItiTopAppBar,
  StatusBadge,
  EmptyStateView,
  DeveloperCreditFooter,
} from './CommonComponents';
import {
  getTrade,
  getTradeStats,
  getTraineesByTrade,
  getPendingTraineesByTrade,
  getTradeAttendance,
  getTradeMonthlyAttendance,
  getInstructorSentNotifications,
  getAllNotifications,
  getDiaryNotesForTrade,
  approveTrainee,
  rejectTrainee,
  toggleTraineeStatus,
  updateTraineeProfile,
  manualCorrectAttendance,
  addDiaryNote,
  updateDiaryNote,
  deleteDiaryNote,
  sendNotification,
  deleteNotification,
  deleteNotifications,
  getTraineeAttendanceHistory,
} from '../firebase/service';
import { useAuth } from '../context/AuthContext';
import { DateUtils, downloadCsv, sortTraineesByTraineeId, resolveAttendanceStatus } from '../utils/itiUtils';

interface InstructorScreenProps {
  instructor: InstructorProfile;
  onLogout: () => void;
}

export const InstructorScreen: React.FC<InstructorScreenProps> = ({ instructor, onLogout }) => {
  const { instituteSettings } = useAuth();
  const [selectedTab, setSelectedTab] = useState<
    'dashboard' | 'attendance' | 'diary' | 'trainees' | 'approvals' | 'notifications' | 'reports'
  >('dashboard');

  const [currentTrade, setCurrentTrade] = useState<Trade | null>(null);
  const [stats, setStats] = useState<DashboardStats>({
    totalTrades: 1,
    totalInstructors: 1,
    totalTrainees: 0,
    presentToday: 0,
    absentToday: 0,
    lateToday: 0,
    pendingTraineeApprovals: 0,
    pendingInstructorRegistrations: 0,
    attendancePercentage: 0,
  });

  const [myTrainees, setMyTrainees] = useState<TraineeProfile[]>([]);
  const [pendingTrainees, setPendingTrainees] = useState<TraineeProfile[]>([]);
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord[]>([]);
  const [monthlyAttendance, setMonthlyAttendance] = useState<AttendanceRecord[]>([]);
  const [diaryNotes, setDiaryNotes] = useState<DiaryNote[]>([]);
  const [sentNotifications, setSentNotifications] = useState<InstituteNotification[]>([]);
  const [adminNotifications, setAdminNotifications] = useState<InstituteNotification[]>([]);

  const [selectedDate, setSelectedDate] = useState(DateUtils.getTodayDateString());
  const [isLoading, setIsLoading] = useState(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  // Dialog States
  const [correctingRecord, setCorrectingRecord] = useState<AttendanceRecord | null>(null);
  const [correctionStatus, setCorrectionStatus] = useState('present');
  const [correctionReason, setCorrectionReason] = useState('');

  const [rejectingTraineeUid, setRejectingTraineeUid] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  const [showAddDiaryModal, setShowAddDiaryModal] = useState(false);
  const [editingDiaryNote, setEditingDiaryNote] = useState<DiaryNote | null>(null);
  const [targetTraineeForDiary, setTargetTraineeForDiary] = useState<TraineeProfile | null>(null);
  const [diaryTitle, setDiaryTitle] = useState('');
  const [diaryContent, setDiaryContent] = useState('');

  const [showBroadcastModal, setShowBroadcastModal] = useState(false);
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [broadcastTargetTraineeId, setBroadcastTargetTraineeId] = useState<string | null>(null);

  const [historyModalTrainee, setHistoryModalTrainee] = useState<TraineeProfile | null>(null);
  const [historyRecords, setHistoryRecords] = useState<AttendanceRecord[]>([]);

  const [modifyingTrainee, setModifyingTrainee] = useState<TraineeProfile | null>(null);
  const [editName, setEditName] = useState('');
  const [editParentage, setEditParentage] = useState('');
  const [editContact, setEditContact] = useState('');
  const [editGuardianContact, setEditGuardianContact] = useState('');
  const [editAddress, setEditAddress] = useState('');

  // Trainee search
  const [traineeSearch, setTraineeSearch] = useState('');
  const [attendanceFilter, setAttendanceFilter] = useState('all');

  const loadData = async () => {
    if (!instructor.tradeId) return;
    setIsLoading(true);
    try {
      const tr = await getTrade(instructor.tradeId);
      setCurrentTrade(tr);
      const st = await getTradeStats(instructor.tradeId);
      setStats(st);
      const trainees = await getTraineesByTrade(instructor.tradeId);
      setMyTrainees(trainees);
      const pending = await getPendingTraineesByTrade(instructor.tradeId);
      setPendingTrainees(pending);
      const att = await getTradeAttendance(instructor.tradeId, selectedDate);
      setTodayAttendance(att);
      const mAtt = await getTradeMonthlyAttendance(instructor.tradeId);
      setMonthlyAttendance(mAtt);
      const notes = await getDiaryNotesForTrade(instructor.tradeId);
      setDiaryNotes(notes);
      const sent = await getInstructorSentNotifications(instructor.uid, instructor.tradeId);
      setSentNotifications(sent);
      const allNotifs = await getAllNotifications();
      setAdminNotifications(allNotifs.filter((n) => n.senderRole === 'admin'));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [instructor.tradeId, selectedDate]);

  const approvedTrainees = myTrainees.filter((t) => t.status === 'approved');

  // Compute good/poor counts
  const distinctDays = Array.from(new Set(monthlyAttendance.map((a) => a.date)));
  let goodCount = 0;
  let poorCount = 0;
  if (approvedTrainees.length > 0 && distinctDays.length > 0) {
    approvedTrainees.forEach((t) => {
      const records = monthlyAttendance.filter((m) => m.traineeId === t.uid);
      const present = records.filter((r) => r.attendanceStatus === 'present' || r.attendanceStatus === 'late').length;
      const rate = (present / distinctDays.length) * 100;
      if (rate >= 80) goodCount++;
      if (rate <= 60) poorCount++;
    });
  }

  const handleDateChange = (newDate: string) => {
    setSelectedDate(newDate);
  };

  const handleApproveTrainee = async (traineeUid: string) => {
    const success = await approveTrainee(traineeUid, instructor.uid, instructor.name, 'instructor');
    if (success) {
      setActionNotice('Trainee approved and unique Trainee ID generated.');
      loadData();
    }
  };

  const handleRejectTrainee = async () => {
    if (!rejectingTraineeUid) return;
    const success = await rejectTrainee(
      rejectingTraineeUid,
      rejectionReason || 'Rejected by Instructor',
      instructor.uid,
      instructor.name,
      'instructor'
    );
    setRejectingTraineeUid(null);
    setRejectionReason('');
    if (success) {
      setActionNotice('Trainee application rejected.');
      loadData();
    }
  };

  const handleSaveCorrection = async () => {
    if (!correctingRecord || !correctionReason.trim()) return;
    const success = await manualCorrectAttendance(
      correctingRecord.attendanceId,
      correctingRecord.traineeId,
      correctingRecord.traineeUniqueId,
      correctingRecord.traineeName,
      correctingRecord.date,
      correctingRecord.attendanceStatus,
      correctionStatus,
      correctionReason.trim(),
      instructor.uid,
      instructor.name,
      'instructor'
    );
    setCorrectingRecord(null);
    setCorrectionReason('');
    if (success) {
      setActionNotice('Attendance corrected and logged.');
      loadData();
    }
  };

  const handleToggleStatus = async (trainee: TraineeProfile) => {
    const success = await toggleTraineeStatus(trainee.uid, trainee.status, instructor.uid, instructor.name);
    if (success) {
      setActionNotice(`Trainee ${trainee.status === 'approved' ? 'deactivated' : 'activated'} successfully.`);
      loadData();
    }
  };

  const handleSaveTraineeModify = async () => {
    if (!modifyingTrainee || !editName.trim()) return;
    const success = await updateTraineeProfile(
      modifyingTrainee.uid,
      editName.trim(),
      editParentage.trim(),
      editContact.trim(),
      editGuardianContact.trim(),
      editAddress.trim(),
      instructor.uid,
      instructor.name,
      'instructor'
    );
    setModifyingTrainee(null);
    if (success) {
      setActionNotice('Trainee details updated successfully.');
      loadData();
    }
  };

  const handleSaveDiaryNote = async () => {
    if (!diaryTitle.trim() || !diaryContent.trim()) return;
    if (editingDiaryNote) {
      await updateDiaryNote(editingDiaryNote.noteId, diaryTitle.trim(), diaryContent.trim());
      setEditingDiaryNote(null);
    } else if (targetTraineeForDiary) {
      await addDiaryNote({
        traineeId: targetTraineeForDiary.uid,
        traineeName: targetTraineeForDiary.name,
        tradeId: instructor.tradeId,
        tradeName: currentTrade?.tradeName || instructor.tradeName,
        instructorId: instructor.uid,
        instructorName: instructor.name,
        title: diaryTitle.trim(),
        content: diaryContent.trim(),
      });
      setShowAddDiaryModal(false);
    }
    setDiaryTitle('');
    setDiaryContent('');
    loadData();
  };

  const handleSendBroadcast = async () => {
    if (!broadcastTitle.trim() || !broadcastMessage.trim()) return;
    await sendNotification({
      title: broadcastTitle.trim(),
      message: broadcastMessage.trim(),
      targetRole: 'trainee',
      targetTradeId: instructor.tradeId,
      targetUserId: broadcastTargetTraineeId,
      senderName: `Instructor ${instructor.name} (${currentTrade?.tradeName || instructor.tradeName})`,
      senderRole: 'instructor',
      senderUserId: instructor.uid,
    });
    setShowBroadcastModal(false);
    setBroadcastTitle('');
    setBroadcastMessage('');
    setBroadcastTargetTraineeId(null);
    setActionNotice('Broadcast announcement sent successfully.');
    loadData();
  };

  const handleExportCsv = (mode: 'day' | 'month') => {
    const list = mode === 'day' ? todayAttendance : monthlyAttendance;
    const dateLabel = mode === 'day' ? selectedDate : DateUtils.getCurrentMonthYear();
    let csv = 'Date,Trainee ID,Trainee Name,Trade,Status,Punch In,Punch Out,Remarks\n';
    list.forEach((r) => {
      csv += `${r.date},${r.traineeUniqueId},${r.traineeName},${r.tradeName},${r.attendanceStatus},${DateUtils.formatTime(r.punchInTime)},${DateUtils.formatTime(r.punchOutTime)},${r.remarks || ''}\n`;
    });
    downloadCsv(`trade_attendance_${currentTrade?.tradeCode || 'trade'}_${dateLabel.replace(/\s+/g, '_')}.csv`, csv);
  };

  const filteredTrainees = myTrainees.filter((t) => {
    if (!traineeSearch.trim()) return true;
    const q = traineeSearch.toLowerCase();
    return t.name.toLowerCase().includes(q) || t.traineeId.toLowerCase().includes(q);
  });

  return (
    <div className="min-h-screen bg-[#FBFDF8] flex flex-col justify-between selection:bg-[#386B39] selection:text-white">
      <div>
        {/* Top App Bar */}
        <ItiTopAppBar
          title={currentTrade?.tradeName || instructor.tradeName || 'Trade Dashboard'}
          subtitle={`Instructor: ${instructor.name}`}
          roleLabel="Instructor"
          notificationCount={adminNotifications.length}
          onBroadcast={() => setShowBroadcastModal(true)}
          onNotificationClick={() => setSelectedTab('notifications')}
          onRefresh={loadData}
          onLogout={onLogout}
        />

        {/* Scrollable Tab Row matching Android ScrollableTabRow */}
        <div className="bg-white border-b border-slate-200/80 shadow-xs sticky top-[57px] z-30 overflow-x-auto">
          <div className="max-w-5xl mx-auto flex items-center justify-start min-w-max px-2">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'attendance', label: 'Attendance', icon: Calendar },
              { id: 'diary', label: 'Diary', icon: BookOpen },
              { id: 'trainees', label: 'My Trainee', icon: Users },
              { id: 'approvals', label: `Approvals (${pendingTrainees.length})`, icon: UserCheck },
              { id: 'notifications', label: 'Notifications', icon: Megaphone },
              { id: 'reports', label: 'Reports', icon: BarChart3 },
            ].map((tab) => {
              const Icon = tab.icon;
              const isSelected = selectedTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id as any)}
                  type="button"
                  className={`py-3 px-3.5 flex items-center space-x-1.5 text-xs font-bold transition-all border-b-2 cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? 'border-[#386B39] text-[#386B39]'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-[#386B39]' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Notice Alert */}
        {actionNotice && (
          <div className="max-w-5xl mx-auto px-4 pt-3">
            <div className="p-3 rounded-2xl bg-[#386B39]/15 border border-[#386B39]/30 text-xs font-semibold text-[#386B39] flex items-center justify-between">
              <span>{actionNotice}</span>
              <button onClick={() => setActionNotice(null)} className="p-1 hover:bg-[#386B39]/20 rounded-lg">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Main Body */}
        <main className="max-w-5xl mx-auto p-4 sm:p-5 space-y-4">
          {/* TAB 1: DASHBOARD */}
          {selectedTab === 'dashboard' && (
            <div className="space-y-4">
              {/* Header card */}
              <div className="p-5 rounded-3xl bg-[#D8E7D8]/60 border border-[#386B39]/30 space-y-1">
                <h3 className="text-base font-extrabold text-[#111F11]">
                  Assigned Trade: {currentTrade?.tradeName || instructor.tradeName}
                </h3>
                <p className="text-xs text-slate-600">
                  Today: {DateUtils.formatDateForDisplay(DateUtils.getTodayDateString())} ({DateUtils.getDayOfWeek()})
                </p>
              </div>

              {/* Monthly Trade Attendance Card */}
              <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5 text-[#386B39]" />
                    <div>
                      <h4 className="text-sm font-extrabold text-slate-900">Trade Monthly Attendance</h4>
                      <p className="text-xs text-slate-500">All trainees of {currentTrade?.tradeName}</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-[#D8E7D8] text-[#111F11] font-bold text-xs">
                    {DateUtils.getCurrentMonthYear()}
                  </span>
                </div>

                <div className="flex items-end justify-between pt-1">
                  <div>
                    <span className="text-2xl sm:text-3xl font-black text-[#386B39]">
                      {stats.attendancePercentage.toFixed(1)}%
                    </span>
                    <span className="text-[11px] text-slate-500 block">Trade Attendance Rate</span>
                  </div>
                  <div className="text-right text-xs font-semibold text-slate-700">
                    <span>{approvedTrainees.length} Active Trainees</span>
                    <span className="text-slate-400 block text-[11px]">{distinctDays.length} Recorded Days</span>
                  </div>
                </div>

                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-[#386B39] h-full transition-all"
                    style={{ width: `${Math.min(100, Math.max(0, stats.attendancePercentage))}%` }}
                  />
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[11px] font-bold text-slate-500 block">My Trainees</span>
                  <span className="text-xl font-black text-[#111F11] block mt-1">{approvedTrainees.length}</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[11px] font-bold text-slate-500 block">Present Today</span>
                  <span className="text-xl font-black text-[#386B39] block mt-1">{stats.presentToday}</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[11px] font-bold text-slate-500 block">Absent Today</span>
                  <span className="text-xl font-black text-[#BA1A1A] block mt-1">{stats.absentToday}</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[11px] font-bold text-slate-500 block">Good (≥80%)</span>
                  <span className="text-xl font-black text-[#386B39] block mt-1">{goodCount}</span>
                  <span className="text-[10px] text-slate-400">This month</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[11px] font-bold text-slate-500 block">Poor (≤60%)</span>
                  <span className="text-xl font-black text-[#BA1A1A] block mt-1">{poorCount}</span>
                  <span className="text-[10px] text-slate-400">This month</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
                  <span className="text-[11px] font-bold text-slate-500 block">Late Arrivals</span>
                  <span className="text-xl font-black text-[#9C6800] block mt-1">{stats.lateToday}</span>
                  <span className="text-[10px] text-slate-400">Today</span>
                </div>
              </div>

              {/* Pending approvals alert */}
              {pendingTrainees.length > 0 && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-black text-amber-900">Pending Trainee Approvals</h4>
                    <p className="text-[11px] text-amber-700 font-medium">
                      {pendingTrainees.length} trainees awaiting your verification
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedTab('approvals')}
                    className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs cursor-pointer"
                  >
                    Review
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ATTENDANCE */}
          {selectedTab === 'attendance' && (
            <div className="space-y-4">
              {/* Date selection bar */}
              <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    {selectedDate === DateUtils.getTodayDateString() ? "Today's Punches" : 'Attendance Punches'}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    {DateUtils.formatDateForDisplay(selectedDate)} ({selectedDate})
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  {selectedDate !== DateUtils.getTodayDateString() && (
                    <button
                      onClick={() => setSelectedDate(DateUtils.getTodayDateString())}
                      className="px-3 py-1.5 rounded-xl border border-slate-300 bg-slate-50 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
                    >
                      Today
                    </button>
                  )}
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => e.target.value && setSelectedDate(e.target.value)}
                    className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 bg-white focus:ring-2 focus:ring-[#386B39] outline-hidden cursor-pointer"
                  />
                </div>
              </div>

              {/* Filter chips */}
              <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs">
                {['all', 'present', 'late', 'absent', 'not_marked'].map((filterKey) => {
                  const label = filterKey === 'all' ? 'All' : filterKey === 'not_marked' ? 'Not Marked' : filterKey.charAt(0).toUpperCase() + filterKey.slice(1);
                  const isSelected = attendanceFilter === filterKey;
                  return (
                    <button
                      key={filterKey}
                      onClick={() => setAttendanceFilter(filterKey)}
                      className={`px-3.5 py-1.5 rounded-full font-bold transition-all cursor-pointer whitespace-nowrap ${
                        isSelected
                          ? 'bg-[#386B39] text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>

              {/* Trainees attendance list */}
              <div className="space-y-2.5">
                {approvedTrainees.map((trainee) => {
                  const record = todayAttendance.find((a) => a.traineeId === trainee.uid || a.traineeUniqueId === trainee.traineeId);
                  const status = resolveAttendanceStatus(record?.attendanceStatus, selectedDate, instituteSettings.cutoffTime);

                  if (attendanceFilter !== 'all' && status !== attendanceFilter) return null;

                  return (
                    <div
                      key={trainee.uid}
                      className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="text-sm font-black text-slate-900">{trainee.name}</h4>
                          <span className="font-mono font-bold text-[11px] text-[#386B39]">
                            {trainee.traineeId}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-1 flex flex-wrap gap-x-3">
                          <span>In: {DateUtils.formatTime(record?.punchInTime)}</span>
                          <span>Out: {DateUtils.formatTime(record?.punchOutTime)}</span>
                          {record?.punchInDistance != null && (
                            <span>Dist: {record.punchInDistance.toFixed(1)}m</span>
                          )}
                        </div>
                        {record?.remarks && (
                          <p className="text-[10px] text-[#9C6800] mt-1 font-medium">{record.remarks}</p>
                        )}
                      </div>

                      <div className="flex items-center space-x-2 shrink-0">
                        <StatusBadge status={status} />
                        <button
                          onClick={() => {
                            setCorrectingRecord(
                              record || {
                                attendanceId: `${trainee.uid}_${selectedDate}`,
                                traineeId: trainee.uid,
                                traineeUniqueId: trainee.traineeId,
                                traineeName: trainee.name,
                                tradeId: trainee.tradeId,
                                tradeName: trainee.tradeName,
                                instructorId: instructor.uid,
                                date: selectedDate,
                                attendanceStatus: 'not_marked',
                              }
                            );
                            setCorrectionStatus(status !== 'not_marked' ? status : 'present');
                          }}
                          className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs cursor-pointer flex items-center space-x-1"
                        >
                          <Edit2 className="w-3.5 h-3.5 text-[#386B39]" />
                          <span>{record ? 'Correct' : 'Mark'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: DIARY */}
          {selectedTab === 'diary' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-black text-slate-900">Trainee Diary Notes</h2>
                  <p className="text-xs text-slate-500">
                    Add &amp; manage remarks visible to trainees and parents
                  </p>
                </div>
                <button
                  onClick={() => {
                    setTargetTraineeForDiary(approvedTrainees[0] || null);
                    setEditingDiaryNote(null);
                    setDiaryTitle('');
                    setDiaryContent('');
                    setShowAddDiaryModal(true);
                  }}
                  type="button"
                  className="px-4 py-2.5 rounded-2xl bg-[#386B39] hover:bg-[#2e592f] text-white font-bold text-xs shadow-md shadow-[#386B39]/20 flex items-center space-x-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Note</span>
                </button>
              </div>

              {diaryNotes.length === 0 ? (
                <EmptyStateView
                  icon={<BookOpen className="w-8 h-8" />}
                  title="No Diary Notes Found"
                  subtitle="Click 'Add Note' to create remarks/notes for trainees in your trade."
                />
              ) : (
                <div className="space-y-3">
                  {diaryNotes.map((note) => (
                    <div key={note.noteId} className="bg-white p-4 rounded-2xl border border-slate-200/80 space-y-2.5 shadow-xs">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="px-2.5 py-1 rounded-lg bg-[#D8E7D8] text-[#111F11] font-bold text-xs">
                            {note.traineeName}
                          </span>
                          <span className="text-[11px] text-slate-400 font-medium">
                            {DateUtils.formatDateForDisplay(note.dateString || DateUtils.getTodayDateString())}
                          </span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <button
                            onClick={() => {
                              setEditingDiaryNote(note);
                              setDiaryTitle(note.title);
                              setDiaryContent(note.content);
                              setShowAddDiaryModal(true);
                            }}
                            className="p-1.5 text-slate-600 hover:text-[#386B39] hover:bg-slate-100 rounded-lg cursor-pointer"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={async () => {
                              if (confirm(`Delete diary note '${note.title}'?`)) {
                                await deleteDiaryNote(note.noteId);
                                loadData();
                              }
                            }}
                            className="p-1.5 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <h4 className="text-xs sm:text-sm font-black text-slate-900">{note.title}</h4>
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 font-medium leading-relaxed">
                        {note.content}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: MY TRAINEE */}
          {selectedTab === 'trainees' && (
            <div className="space-y-4">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={traineeSearch}
                  onChange={(e) => setTraineeSearch(e.target.value)}
                  placeholder="Search trainee by name / ID..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 text-xs bg-white focus:ring-2 focus:ring-[#386B39] outline-hidden shadow-xs"
                />
              </div>

              {filteredTrainees.length === 0 ? (
                <EmptyStateView
                  icon={<Users className="w-8 h-8" />}
                  title="No Trainees Found"
                  subtitle="Approved trainees for your trade will appear here."
                />
              ) : (
                <div className="space-y-3">
                  {filteredTrainees.map((trainee) => (
                    <div key={trainee.uid} className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="text-sm font-black text-slate-900">{trainee.name}</h4>
                          <p className="text-xs text-slate-500 font-medium">Father: {trainee.parentage}</p>
                        </div>
                        <StatusBadge status={trainee.status} />
                      </div>

                      {/* Highlighted Credentials Box */}
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                        <div>
                          <span className="text-[10px] font-bold text-slate-400 uppercase block">TRAINEE ID</span>
                          <span className="font-mono font-bold text-[#386B39]">{trainee.traineeId}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] font-bold text-slate-400 uppercase block">PARENT PIN</span>
                          <span className="font-mono font-bold text-[#9C6800]">
                            {trainee.parentAccessPin || '1234'}
                          </span>
                        </div>
                      </div>

                      <div className="text-[11px] text-slate-500 space-y-0.5">
                        <p>Contact: {trainee.contact} | Email: {trainee.email}</p>
                        {trainee.guardianContact && <p>Guardian Contact: {trainee.guardianContact}</p>}
                        {trainee.address && <p>Address: {trainee.address}</p>}
                      </div>

                      <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
                        <button
                          onClick={async () => {
                            setHistoryModalTrainee(trainee);
                            const h = await getTraineeAttendanceHistory(trainee.uid, trainee.traineeId);
                            setHistoryRecords(h);
                          }}
                          className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 font-bold text-xs text-slate-700 flex items-center space-x-1 cursor-pointer"
                        >
                          <History className="w-3.5 h-3.5" />
                          <span>History</span>
                        </button>

                        <button
                          onClick={() => handleToggleStatus(trainee)}
                          className={`px-3 py-1.5 rounded-xl font-bold text-xs border flex items-center space-x-1 cursor-pointer ${
                            trainee.status === 'approved'
                              ? 'border-red-200 text-red-700 hover:bg-red-50'
                              : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
                          }`}
                        >
                          {trainee.status === 'approved' ? (
                            <>
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Deactivate</span>
                            </>
                          ) : (
                            <>
                              <CheckCircle className="w-3.5 h-3.5" />
                              <span>Activate</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => {
                            setModifyingTrainee(trainee);
                            setEditName(trainee.name);
                            setEditParentage(trainee.parentage);
                            setEditContact(trainee.contact);
                            setEditGuardianContact(trainee.guardianContact || '');
                            setEditAddress(trainee.address || '');
                          }}
                          className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 font-bold text-xs text-slate-700 flex items-center space-x-1 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5 text-[#386B39]" />
                          <span>Modify</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: APPROVALS */}
          {selectedTab === 'approvals' && (
            <div className="space-y-4">
              <div>
                <h2 className="text-base font-black text-slate-900">
                  Pending Trainee Admissions ({pendingTrainees.length})
                </h2>
                <p className="text-xs text-slate-500">
                  Verify candidate details and grant admission for GPS attendance
                </p>
              </div>

              {pendingTrainees.length === 0 ? (
                <EmptyStateView
                  icon={<CheckCircle className="w-8 h-8" />}
                  title="All Caught Up!"
                  subtitle="No pending trainee applications for your trade."
                />
              ) : (
                <div className="space-y-3">
                  {pendingTrainees.map((trainee) => (
                    <div key={trainee.uid} className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="text-sm font-black text-slate-900">{trainee.name}</h4>
                          <p className="text-xs text-slate-500 font-medium">Father: {trainee.parentage}</p>
                        </div>
                        <StatusBadge status="pending" />
                      </div>

                      <div className="text-xs text-slate-600 space-y-0.5">
                        <p>Email: {trainee.email} | Contact: {trainee.contact}</p>
                        {trainee.guardianContact && <p>Guardian Contact: {trainee.guardianContact}</p>}
                        {trainee.address && <p>Address: {trainee.address}</p>}
                      </div>

                      <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
                        <button
                          onClick={() => setRejectingTraineeUid(trainee.uid)}
                          className="px-4 py-2 rounded-xl border border-red-200 text-red-700 font-bold text-xs hover:bg-red-50 cursor-pointer"
                        >
                          Reject
                        </button>
                        <button
                          onClick={() => handleApproveTrainee(trainee.uid)}
                          className="px-4 py-2 rounded-xl bg-[#386B39] hover:bg-[#2e592f] text-white font-bold text-xs shadow-sm cursor-pointer"
                        >
                          Approve &amp; Generate ID
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: NOTIFICATIONS */}
          {selectedTab === 'notifications' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-black text-slate-900">Trade Announcements</h2>
                  <p className="text-xs text-slate-500">Broadcasting and alerts sent to trainees</p>
                </div>
                <button
                  onClick={() => setShowBroadcastModal(true)}
                  className="px-4 py-2 rounded-2xl bg-[#386B39] text-white font-bold text-xs flex items-center space-x-1.5 shadow-sm cursor-pointer"
                >
                  <Megaphone className="w-4 h-4" />
                  <span>New Announcement</span>
                </button>
              </div>

              {sentNotifications.length === 0 ? (
                <EmptyStateView
                  icon={<Megaphone className="w-8 h-8" />}
                  title="No Sent Announcements"
                  subtitle="Click 'New Announcement' to broadcast notices to your trade."
                />
              ) : (
                <div className="space-y-3">
                  {sentNotifications.map((n) => (
                    <div key={n.notificationId} className="bg-white p-4 rounded-2xl border border-slate-200/80 space-y-2 shadow-xs">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="text-xs sm:text-sm font-black text-slate-900">{n.title}</h4>
                          <span className="text-[10px] text-slate-400 font-medium">
                            {DateUtils.formatDateTime(n.timestamp)}
                          </span>
                        </div>
                        <button
                          onClick={async () => {
                            await deleteNotification(n.notificationId);
                            loadData();
                          }}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-xs text-slate-700 font-medium leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200">
                        {n.message}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 7: REPORTS */}
          {selectedTab === 'reports' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-black text-slate-900">Trade Attendance Report</h2>
                  <p className="text-xs text-slate-500">Day-wise and Monthly CSV Exports</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
                  <h4 className="text-sm font-black text-slate-900">Day-Wise Export</h4>
                  <p className="text-xs text-slate-500">
                    Export attendance record for date: {DateUtils.formatDateForDisplay(selectedDate)}
                  </p>
                  <button
                    onClick={() => handleExportCsv('day')}
                    className="w-full py-2.5 rounded-xl bg-[#386B39] text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-sm cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Day CSV ({todayAttendance.length} records)</span>
                  </button>
                </div>

                <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
                  <h4 className="text-sm font-black text-slate-900">Month-Wise Export</h4>
                  <p className="text-xs text-slate-500">
                    Export cumulative monthly records for {DateUtils.getCurrentMonthYear()}
                  </p>
                  <button
                    onClick={() => handleExportCsv('month')}
                    className="w-full py-2.5 rounded-xl bg-[#2E627B] text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-sm cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Month CSV ({monthlyAttendance.length} records)</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      <DeveloperCreditFooter />

      {/* Manual Attendance Correction Dialog */}
      {correctingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs">
            <h3 className="text-sm font-black text-slate-900">Manual Attendance Correction</h3>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <p className="font-bold text-slate-900">
                Trainee: {correctingRecord.traineeName} ({correctingRecord.traineeUniqueId})
              </p>
              <p className="text-slate-500">Date: {DateUtils.formatDateForDisplay(correctingRecord.date)}</p>
              <p className="text-slate-500">Current Status: {correctingRecord.attendanceStatus.toUpperCase()}</p>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Select Corrected Status:</label>
              <div className="flex flex-wrap gap-1.5">
                {['present', 'late', 'absent', 'half_day', 'leave'].map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setCorrectionStatus(st)}
                    className={`px-3 py-1.5 rounded-xl font-bold capitalize transition-all cursor-pointer ${
                      correctionStatus === st
                        ? 'bg-[#386B39] text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {st.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Reason for Correction (Mandatory):</label>
              <textarea
                rows={2}
                value={correctionReason}
                onChange={(e) => setCorrectionReason(e.target.value)}
                placeholder="e.g. Approved on duty / medical certificate verified"
                className="w-full p-2.5 rounded-xl border border-slate-200 text-xs bg-slate-50/50 outline-hidden focus:ring-2 focus:ring-[#386B39]"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setCorrectingRecord(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCorrection}
                disabled={!correctionReason.trim()}
                className="px-5 py-2 rounded-xl bg-[#386B39] text-white font-bold hover:bg-[#2e592f] shadow-sm disabled:opacity-40 cursor-pointer"
              >
                Save Correction
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Trainee Rejection Dialog */}
      {rejectingTraineeUid && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs">
            <h3 className="text-sm font-black text-slate-900">Reject Trainee Application</h3>
            <p className="text-slate-500">Provide official reason for rejecting this admission application:</p>
            <textarea
              rows={3}
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="e.g. Incomplete eligibility documents / trade quota full"
              className="w-full p-2.5 rounded-xl border border-slate-200 text-xs bg-slate-50/50 outline-hidden focus:ring-2 focus:ring-red-600"
            />
            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setRejectingTraineeUid(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleRejectTrainee}
                className="px-5 py-2 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 shadow-sm cursor-pointer"
              >
                Reject Application
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Diary Note Modal */}
      {showAddDiaryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs max-h-[90vh] overflow-y-auto">
            <h3 className="text-sm font-black text-slate-900">
              {editingDiaryNote ? 'Edit Diary Note' : 'Add Trainee Diary Note'}
            </h3>

            {!editingDiaryNote && (
              <div>
                <label className="block font-bold text-slate-700 mb-1">Target Trainee *</label>
                <select
                  value={targetTraineeForDiary?.uid || ''}
                  onChange={(e) => {
                    const t = approvedTrainees.find((tr) => tr.uid === e.target.value);
                    if (t) setTargetTraineeForDiary(t);
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-800"
                >
                  {approvedTrainees.map((t) => (
                    <option key={t.uid} value={t.uid}>
                      {t.name} ({t.traineeId})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Quick Categories */}
            <div>
              <label className="block font-bold text-slate-500 text-[10px] uppercase mb-1">
                Quick Category Suggestions:
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Conduct',
                  'Discipline',
                  'Academic',
                  'Practical Test',
                  'Attendance Issue',
                  'Commendation',
                  'General Remark',
                ].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setDiaryTitle(cat)}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-[11px] font-semibold text-slate-700 cursor-pointer"
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Note Title / Category *</label>
              <input
                type="text"
                value={diaryTitle}
                onChange={(e) => setDiaryTitle(e.target.value)}
                placeholder="e.g. Practical Conduct, Absence Note"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Diary Details / Remarks *</label>
              <textarea
                rows={4}
                value={diaryContent}
                onChange={(e) => setDiaryContent(e.target.value)}
                placeholder="Enter detailed note for trainee and parent..."
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => {
                  setShowAddDiaryModal(false);
                  setEditingDiaryNote(null);
                }}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveDiaryNote}
                disabled={!diaryTitle.trim() || !diaryContent.trim()}
                className="px-5 py-2 rounded-xl bg-[#386B39] text-white font-bold hover:bg-[#2e592f] shadow-sm disabled:opacity-40 cursor-pointer"
              >
                {editingDiaryNote ? 'Update Note' : 'Save Note'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Broadcast Announcement Modal */}
      {showBroadcastModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs">
            <h3 className="text-sm font-black text-slate-900">Send Trade Announcement</h3>
            <p className="text-slate-500">
              Send announcement to all trainees in {currentTrade?.tradeName} or select a specific trainee.
            </p>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Recipient Filter *</label>
              <select
                value={broadcastTargetTraineeId || ''}
                onChange={(e) => setBroadcastTargetTraineeId(e.target.value || null)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-800"
              >
                <option value="">All {currentTrade?.tradeName} Trainees (Broadcast)</option>
                {approvedTrainees.map((t) => (
                  <option key={t.uid} value={t.uid}>
                    {t.name} ({t.traineeId})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Notification Title *</label>
              <input
                type="text"
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                placeholder="e.g. Workshop Session Rescheduled"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Notification Message *</label>
              <textarea
                rows={3}
                value={broadcastMessage}
                onChange={(e) => setBroadcastMessage(e.target.value)}
                placeholder="Enter detailed announcement text..."
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowBroadcastModal(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSendBroadcast}
                disabled={!broadcastTitle.trim() || !broadcastMessage.trim()}
                className="px-5 py-2 rounded-xl bg-[#386B39] text-white font-bold hover:bg-[#2e592f] shadow-sm disabled:opacity-40 cursor-pointer"
              >
                Send Notification
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Trainee History Modal */}
      {historyModalTrainee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs max-h-[85vh] flex flex-col">
            <h3 className="text-sm font-black text-slate-900">
              Attendance History: {historyModalTrainee.name}
            </h3>
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-0.5 text-[11px]">
              <p className="font-bold text-[#386B39]">ID: {historyModalTrainee.traineeId}</p>
              <p className="text-slate-500">Parent PIN: {historyModalTrainee.parentAccessPin}</p>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {historyRecords.length === 0 ? (
                <p className="text-center py-6 text-slate-400">No past attendance records found.</p>
              ) : (
                historyRecords.map((r) => (
                  <div
                    key={r.attendanceId || `${r.traineeId}_${r.date}`}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-slate-800 block">{DateUtils.formatDateForDisplay(r.date)}</span>
                      <span className="text-[10px] text-slate-500">
                        In: {DateUtils.formatTime(r.punchInTime)} | Out: {DateUtils.formatTime(r.punchOutTime)}
                      </span>
                    </div>
                    <StatusBadge status={r.attendanceStatus} />
                  </div>
                ))
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setHistoryModalTrainee(null)}
                className="px-4 py-2 rounded-xl bg-[#386B39] text-white font-bold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Trainee Modify Modal */}
      {modifyingTrainee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-3 text-xs max-h-[90vh] overflow-y-auto">
            <h3 className="text-sm font-black text-slate-900">Modify Trainee Details</h3>
            <p className="text-slate-500 font-mono text-[11px]">ID: {modifyingTrainee.traineeId}</p>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Full Name *</label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Father / Parentage</label>
              <input
                type="text"
                value={editParentage}
                onChange={(e) => setEditParentage(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Trainee Contact No.</label>
              <input
                type="tel"
                value={editContact}
                onChange={(e) => setEditContact(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Father/Guardian Contact No.</label>
              <input
                type="tel"
                value={editGuardianContact}
                onChange={(e) => setEditGuardianContact(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Address</label>
              <input
                type="text"
                value={editAddress}
                onChange={(e) => setEditAddress(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setModifyingTrainee(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveTraineeModify}
                disabled={!editName.trim()}
                className="px-5 py-2 rounded-xl bg-[#386B39] text-white font-bold hover:bg-[#2e592f] shadow-sm disabled:opacity-40 cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
