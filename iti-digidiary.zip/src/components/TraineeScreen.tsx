import React, { useState, useEffect } from 'react';
import {
  ClipboardList,
  BookOpen,
  Megaphone,
  Copy,
  Check,
  MapPin,
  Clock,
  LogIn,
  LogOut,
  Search,
  X,
  AlertTriangle,
  Calendar,
  Layers,
  Sparkles,
  RefreshCw,
  Hourglass,
  History,
} from 'lucide-react';
import { TraineeProfile, AttendanceRecord, DiaryNote, InstituteNotification } from '../types';
import { useAuth } from '../context/AuthContext';
import {
  ItiTopAppBar,
  StatusBadge,
  GeofenceDistanceCard,
  EmptyStateView,
  DeveloperCreditFooter,
} from './CommonComponents';
import {
  getTodayAttendance,
  getTraineeAttendanceHistory,
  getDiaryNotesForTrainee,
  getNotifications,
  punchIn,
  punchOut,
} from '../firebase/service';
import { DateUtils, resolveAttendanceStatus } from '../utils/itiUtils';

interface TraineeScreenProps {
  trainee: TraineeProfile;
  onLogout: () => void;
}

export const TraineeScreen: React.FC<TraineeScreenProps> = ({ trainee, onLogout }) => {
  const { instituteSettings, locationStatus, isCheckingLocation, refreshLocation, reloadProfileData } = useAuth();

  const [selectedTab, setSelectedTab] = useState<'attendance' | 'diary' | 'notifications'>('attendance');
  const [copiedId, setCopiedId] = useState(false);

  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord | null>(null);
  const [attendanceHistory, setAttendanceHistory] = useState<AttendanceRecord[]>([]);
  const [diaryNotes, setDiaryNotes] = useState<DiaryNote[]>([]);
  const [notifications, setNotifications] = useState<InstituteNotification[]>([]);

  const [isLoadingPunch, setIsLoadingPunch] = useState(false);
  const [showPunchConfirm, setShowPunchConfirm] = useState<'in' | 'out' | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Diary search
  const [diarySearch, setDiarySearch] = useState('');

  // Notifications filter
  const [notifFilter, setNotifFilter] = useState<'all' | 'broadcast' | 'personal'>('all');

  // Selected date for attendance timeline & monthly inspection (defaults to current date/month)
  const [selectedAttendanceDate, setSelectedAttendanceDate] = useState<string>(DateUtils.getTodayDateString());

  const loadData = async () => {
    try {
      const today = await getTodayAttendance(trainee.uid);
      setTodayAttendance(today);
      const hist = await getTraineeAttendanceHistory(trainee.uid, trainee.traineeId);
      setAttendanceHistory(hist);
      const notes = await getDiaryNotesForTrainee(trainee.uid);
      setDiaryNotes(notes);
      const notifs = await getNotifications('trainee', trainee.tradeId, trainee.uid);
      setNotifications(notifs);
    } catch {}
  };

  useEffect(() => {
    loadData();
    refreshLocation();
  }, [trainee.uid]);

  const handleCopyTraineeId = () => {
    navigator.clipboard.writeText(trainee.traineeId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handlePunchIn = async () => {
    setActionMessage(null);
    setActionError(null);
    setIsLoadingPunch(true);
    const loc = locationStatus || (await refreshLocation());
    if (!loc) {
      setIsLoadingPunch(false);
      setActionError('GPS location unavailable. Please enable High Accuracy location and retry.');
      return;
    }
    const res = await punchIn(trainee, loc.currentLat, loc.currentLng);
    setIsLoadingPunch(false);
    if (res.success && res.record) {
      setTodayAttendance(res.record);
      setActionMessage(`Punch In recorded successfully at ${DateUtils.formatTime(res.record.punchInTime)}.`);
      loadData();
    } else {
      setActionError(res.error || 'Failed to punch in.');
    }
  };

  const handlePunchOut = async () => {
    setActionMessage(null);
    setActionError(null);
    setIsLoadingPunch(true);
    const loc = locationStatus || (await refreshLocation());
    if (!loc) {
      setIsLoadingPunch(false);
      setActionError('GPS location unavailable. Please enable High Accuracy location and retry.');
      return;
    }
    const res = await punchOut(trainee, loc.currentLat, loc.currentLng);
    setIsLoadingPunch(false);
    if (res.success && res.record) {
      setTodayAttendance(res.record);
      setActionMessage(`Punch Out recorded successfully at ${DateUtils.formatTime(res.record.punchOutTime)}.`);
      loadData();
    } else {
      setActionError(res.error || 'Failed to punch out.');
    }
  };

  // Filtered diary
  const filteredDiary = diaryNotes.filter(
    (n) =>
      !diarySearch.trim() ||
      n.title.toLowerCase().includes(diarySearch.toLowerCase()) ||
      n.content.toLowerCase().includes(diarySearch.toLowerCase()) ||
      n.instructorName.toLowerCase().includes(diarySearch.toLowerCase())
  );

  // Filtered notifications
  const filteredNotifs = notifications.filter((n) => {
    if (notifFilter === 'broadcast') return !n.targetUserId;
    if (notifFilter === 'personal') return n.targetUserId === trainee.uid || n.targetUserId === trainee.traineeId;
    return true;
  });

  // Selected Month calculations
  const selectedYearMonth = selectedAttendanceDate
    ? selectedAttendanceDate.substring(0, 7)
    : DateUtils.getTodayDateString().substring(0, 7);

  const selectedMonthDisplay = (() => {
    try {
      const [y, m] = selectedYearMonth.split('-');
      const d = new Date(Number(y), Number(m) - 1, 1);
      return d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    } catch {
      return selectedYearMonth;
    }
  })();

  // Filter attendance records for the selected month (active timeline list)
  const monthlyAttendanceRecords = attendanceHistory
    .filter((h) => h.date && h.date.startsWith(selectedYearMonth))
    .sort((a, b) => b.date.localeCompare(a.date));

  // Compute total institute working days (excluding Sundays and marked holidays)
  const currentMonthWorkingDaysInfo = DateUtils.getWorkingDaysInMonth(
    selectedYearMonth,
    instituteSettings.workingDays || ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    instituteSettings.holidays || [],
    selectedYearMonth === DateUtils.getTodayDateString().substring(0, 7) ? DateUtils.getTodayDateString() : undefined
  );
  const presentWorkingDays = currentMonthWorkingDaysInfo.totalWorkingDays;

  // Metrics
  const presentDays = attendanceHistory.filter(
    (h) => h.attendanceStatus === 'present' || h.attendanceStatus === 'late'
  ).length;
  const lateDays = attendanceHistory.filter((h) => h.attendanceStatus === 'late').length;
  const absentDays = attendanceHistory.filter((h) => h.attendanceStatus === 'absent').length;
  const totalDays = attendanceHistory.length;
  const attendanceRate = totalDays > 0 ? (presentDays / totalDays) * 100 : 0;

  const isApproved = trainee.status === 'approved';
  const isInsideRadius = locationStatus?.isWithinRadius === true;
  const hasPunchedIn = !!todayAttendance?.punchInTime;
  const hasPunchedOut = !!todayAttendance?.punchOutTime;

  return (
    <div className="min-h-screen bg-[#FBFDF8] flex flex-col justify-between selection:bg-[#386B39] selection:text-white">
      <div>
        {/* Top App Bar */}
        <ItiTopAppBar
          title={`Welcome, ${trainee.name}`}
          subtitle={`Trade: ${trainee.tradeName}`}
          roleLabel="Trainee"
          notificationCount={notifications.length}
          onNotificationClick={() => setSelectedTab('notifications')}
          onRefresh={() => {
            loadData();
            refreshLocation();
            reloadProfileData();
          }}
          onLogout={onLogout}
        />

        {/* Tab Row matching Android Material3 TabRow */}
        <div className="bg-white border-b border-slate-200/80 shadow-xs sticky top-[57px] z-30">
          <div className="max-w-3xl mx-auto flex items-center justify-around">
            {[
              { id: 'attendance', label: 'Attendance', icon: Calendar },
              { id: 'diary', label: 'Diary', icon: BookOpen },
              { id: 'notifications', label: 'Notifications', icon: Megaphone },
            ].map((tab) => {
              const Icon = tab.icon;
              const isSelected = selectedTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id as any)}
                  type="button"
                  className={`flex-1 py-3 px-2 flex items-center justify-center space-x-2 text-xs font-bold transition-all border-b-2 cursor-pointer ${
                    isSelected
                      ? 'border-[#386B39] text-[#386B39]'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-[#386B39]' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Body */}
        <main className="max-w-3xl mx-auto p-4 sm:p-5 space-y-4">
          {/* Action Alerts */}
          {actionMessage && (
            <div className="p-3 rounded-2xl bg-[#386B39]/15 border border-[#386B39]/30 text-xs font-semibold text-[#386B39] flex items-center justify-between">
              <span>{actionMessage}</span>
              <button onClick={() => setActionMessage(null)} className="p-1 hover:bg-[#386B39]/20 rounded-lg">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {actionError && (
            <div className="p-3 rounded-2xl bg-red-50 border border-red-200 text-xs font-semibold text-red-700 flex items-center justify-between">
              <span>{actionError}</span>
              <button onClick={() => setActionError(null)} className="p-1 hover:bg-red-100 rounded-lg">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* TAB 1: ATTENDANCE */}
          {selectedTab === 'attendance' && (
            <div className="space-y-4">
              {/* Trainee Identity Card */}
              <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">
                      TRAINEE PORTAL
                    </span>
                    <h2 className="text-lg font-black text-slate-900 mt-0.5">{trainee.name}</h2>
                    <p className="text-xs text-slate-500 font-medium">Father: {trainee.parentage}</p>
                  </div>
                  <StatusBadge status={trainee.status} />
                </div>

                {/* Chips Row */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs font-bold text-slate-800">
                    <span>ID: {trainee.traineeId}</span>
                    <button
                      onClick={handleCopyTraineeId}
                      className="p-1 hover:bg-slate-200 rounded-md text-slate-600 transition-colors"
                      title="Copy Trainee ID"
                    >
                      {copiedId ? <Check className="w-3 h-3 text-[#386B39]" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>

                  <div className="px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs font-bold text-slate-800">
                    <span>{trainee.tradeName}</span>
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <span className="text-xs font-extrabold text-[#386B39]">
                    Parent PIN: {trainee.parentAccessPin || '1234'}
                  </span>
                </div>
              </div>

              {/* Status Warning if not approved */}
              {!isApproved && (
                <div className="p-4 rounded-3xl bg-[#D8E7D8]/60 border border-[#386B39]/30 text-center space-y-1.5">
                  <Hourglass className="w-8 h-8 text-[#386B39] mx-auto" />
                  <h4 className="text-sm font-extrabold text-[#111F11]">
                    Account Status: {trainee.status.toUpperCase()}
                  </h4>
                  <p className="text-xs text-slate-600 max-w-md mx-auto">
                    {trainee.status === 'rejected'
                      ? `Admission rejected: ${trainee.rejectionReason || 'Please contact ITI administration.'}`
                      : trainee.status === 'inactive' || trainee.status === 'deactivated'
                      ? 'Your account has been deactivated by administration. Attendance marking is disabled.'
                      : 'Your trainee registration is awaiting verification by the ITI Administration / Instructor. GPS Attendance punching will unlock upon approval.'}
                  </p>
                </div>
              )}

              {/* GPS Geofence Status Card */}
              <GeofenceDistanceCard
                distanceMeters={locationStatus?.distanceMeters}
                isWithinRadius={locationStatus?.isWithinRadius}
                radiusMeters={instituteSettings.radiusMeters}
                isChecking={isCheckingLocation}
                onCheckGps={refreshLocation}
              />

              {/* Today's Punch Action Card */}
              <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">
                      TODAY'S ATTENDANCE
                    </span>
                    <h3 className="text-sm font-extrabold text-slate-800">
                      {DateUtils.formatDateForDisplay(DateUtils.getTodayDateString())}
                    </h3>
                  </div>
                  <StatusBadge status={resolveAttendanceStatus(todayAttendance?.attendanceStatus, DateUtils.getTodayDateString(), instituteSettings.cutoffTime)} />
                </div>

                {/* Status Times */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-center justify-around">
                  <div className="text-center">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Punch In</span>
                    <span className="text-sm font-black text-slate-800">
                      {DateUtils.formatTime(todayAttendance?.punchInTime)}
                    </span>
                  </div>
                  <div className="h-7 w-[1px] bg-slate-200" />
                  <div className="text-center">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Punch Out</span>
                    <span className="text-sm font-black text-slate-800">
                      {DateUtils.formatTime(todayAttendance?.punchOutTime)}
                    </span>
                  </div>
                </div>

                {/* Big Action Buttons */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setShowPunchConfirm('in')}
                    disabled={!isApproved || !isInsideRadius || hasPunchedIn || isLoadingPunch || DateUtils.isPastCutoff(instituteSettings.cutoffTime)}
                    type="button"
                    className="py-4 rounded-2xl bg-[#386B39] hover:bg-[#2e592f] text-white font-black text-xs sm:text-sm tracking-wider shadow-md shadow-[#386B39]/20 flex items-center justify-center space-x-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-all active:scale-98"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>PUNCH IN</span>
                  </button>

                  <button
                    onClick={() => setShowPunchConfirm('out')}
                    disabled={!isApproved || !isInsideRadius || !hasPunchedIn || hasPunchedOut || isLoadingPunch}
                    type="button"
                    className="py-4 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-black text-xs sm:text-sm tracking-wider flex items-center justify-center space-x-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-all active:scale-98"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>PUNCH OUT</span>
                  </button>
                </div>

                {!isInsideRadius && (
                  <p className="text-[11px] font-semibold text-[#BA1A1A] text-center">
                    ⚠️ You must be within {Math.round(instituteSettings.radiusMeters)}m of the ITI campus to punch attendance.
                  </p>
                )}
              </div>

              {/* Attendance Statistics Summary - 4 Column Natural Cards */}
              <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3.5">
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">
                  ATTENDANCE SUMMARY
                </span>

                {/* 4 Metric Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                    <span className="text-[10px] font-extrabold text-slate-500 uppercase block leading-tight">
                      PRESENT WORKING DAYS
                    </span>
                    <span className="text-xl font-black text-slate-900 block mt-0.5">{presentWorkingDays}</span>
                    <span className="text-[10px] text-slate-400">Total Working</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                    <span className="text-[10px] font-extrabold text-slate-500 uppercase block">PRESENT</span>
                    <span className="text-xl font-black text-[#386B39] block mt-0.5">{presentDays}</span>
                    <span className="text-[10px] text-slate-400">Days</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                    <span className="text-[10px] font-extrabold text-slate-500 uppercase block">ABSENT</span>
                    <span className="text-xl font-black text-[#BA1A1A] block mt-0.5">{absentDays}</span>
                    <span className="text-[10px] text-slate-400">Days</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-[#386B39] text-white text-center shadow-xs">
                    <span className="text-[10px] font-extrabold text-white/80 uppercase block">RATE</span>
                    <span className="text-xl font-black text-white block mt-0.5">{attendanceRate.toFixed(0)}%</span>
                    <span className="text-[10px] text-white/80">Overall</span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="space-y-1.5 pt-1">
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        attendanceRate >= 75 ? 'bg-[#386B39]' : 'bg-[#9C6800]'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(0, attendanceRate))}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                    <span>Total Enrolled Days: {totalDays}</span>
                    <span>Late Arrivals: {lateDays}</span>
                  </div>
                </div>
              </div>

              {/* Instructor Diary Notes */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-extrabold text-slate-900">Instructor Diary Notes</h3>
                  {diaryNotes.length > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-[#D8E7D8] text-[#111F11] text-xs font-bold">
                      {diaryNotes.length}
                    </span>
                  )}
                </div>

                {diaryNotes.length === 0 ? (
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-center text-xs text-slate-500">
                    No instructor diary notes added yet.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {diaryNotes.slice(0, 3).map((note) => (
                      <div key={note.noteId} className="bg-white p-4 rounded-2xl border border-slate-200/80 space-y-2 shadow-xs">
                        <div className="flex items-start justify-between">
                          <h4 className="text-xs font-black text-slate-900">{note.title}</h4>
                          <span className="text-[10px] font-semibold text-slate-400">
                            {DateUtils.formatDateForDisplay(note.dateString || DateUtils.getTodayDateString())}
                          </span>
                        </div>
                        <p className="text-xs text-slate-700 font-medium leading-relaxed">{note.content}</p>
                        <span className="text-[10px] font-bold text-[#386B39] block">
                          Posted by Instructor: {note.instructorName}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Recent Attendance Timeline with Date Picker */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900">Recent Attendance Timeline</h3>
                    <p className="text-[11px] text-slate-500">
                      Attendance for {selectedMonthDisplay} ({monthlyAttendanceRecords.length} records logged)
                    </p>
                  </div>

                  {/* Date Picker */}
                  <div className="flex items-center space-x-2 bg-slate-50 px-3 py-1.5 rounded-2xl border border-slate-200 self-start sm:self-auto">
                    <label htmlFor="trainee-attendance-date" className="text-xs font-bold text-slate-600 flex items-center space-x-1.5 shrink-0">
                      <Calendar className="w-3.5 h-3.5 text-[#386B39]" />
                      <span>Select Date:</span>
                    </label>
                    <input
                      id="trainee-attendance-date"
                      type="date"
                      value={selectedAttendanceDate}
                      onChange={(e) => setSelectedAttendanceDate(e.target.value || DateUtils.getTodayDateString())}
                      className="px-2 py-1 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-800 focus:ring-2 focus:ring-[#386B39] outline-hidden cursor-pointer"
                    />
                  </div>
                </div>

                {monthlyAttendanceRecords.length === 0 ? (
                  <EmptyStateView
                    icon={<History className="w-8 h-8" />}
                    title={`No Attendance in ${selectedMonthDisplay}`}
                    subtitle="Select another date to view different monthly records, or punch your attendance today."
                  />
                ) : (
                  <div className="space-y-2">
                    {monthlyAttendanceRecords.map((rec) => {
                      const isSelectedDate = rec.date === selectedAttendanceDate;
                      const isHolidayDate = DateUtils.isHoliday(rec.date, instituteSettings.holidays);
                      return (
                        <div
                          key={rec.attendanceId || `${rec.traineeId}_${rec.date}`}
                          className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between shadow-xs text-xs ${
                            isSelectedDate
                              ? 'bg-[#D8E7D8]/30 border-[#386B39] ring-1 ring-[#386B39]'
                              : 'bg-white border-slate-200/80 hover:bg-slate-50'
                          }`}
                        >
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-bold text-slate-900">
                                {DateUtils.formatDateForDisplay(rec.date)}
                              </span>
                              {isSelectedDate && (
                                <span className="px-1.5 py-0.2 rounded-sm text-[9px] font-black bg-[#386B39] text-white">
                                  Selected Date
                                </span>
                              )}
                              {isHolidayDate && (
                                <span className="px-1.5 py-0.2 rounded-sm text-[9px] font-bold bg-amber-100 text-amber-800">
                                  Holiday
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-500 mt-0.5 block">
                              In: {DateUtils.formatTime(rec.punchInTime)} | Out: {DateUtils.formatTime(rec.punchOutTime)}
                            </span>
                          </div>
                          <StatusBadge status={rec.attendanceStatus} />
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: DIARY */}
          {selectedTab === 'diary' && (
            <div className="space-y-3.5">
              <div>
                <h2 className="text-base font-black text-slate-900">Instructor Diary Notes</h2>
                <p className="text-xs text-slate-500">
                  Remarks, feedback &amp; notes posted by your trade instructor
                </p>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={diarySearch}
                  onChange={(e) => setDiarySearch(e.target.value)}
                  placeholder="Search diary notes..."
                  className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-xs bg-white focus:ring-2 focus:ring-[#386B39] outline-hidden"
                />
              </div>

              {filteredDiary.length === 0 ? (
                <EmptyStateView
                  icon={<BookOpen className="w-8 h-8" />}
                  title="No Diary Notes"
                  subtitle={
                    diarySearch.trim()
                      ? `No notes match '${diarySearch}'.`
                      : 'Your instructor has not added any diary remarks yet.'
                  }
                />
              ) : (
                <div className="space-y-3">
                  {filteredDiary.map((note) => (
                    <div key={note.noteId} className="bg-white p-4 rounded-2xl border border-slate-200/80 space-y-2 shadow-xs">
                      <div className="flex items-start justify-between">
                        <h4 className="text-xs sm:text-sm font-black text-slate-900">{note.title}</h4>
                        <span className="text-[10px] font-semibold text-slate-400">
                          {DateUtils.formatDateForDisplay(note.dateString || DateUtils.getTodayDateString())}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 font-medium leading-relaxed">{note.content}</p>
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                        <span className="font-bold text-[#386B39]">Posted by: {note.instructorName}</span>
                        <span className="text-slate-400">{note.tradeName}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: NOTIFICATIONS */}
          {selectedTab === 'notifications' && (
            <div className="space-y-3.5">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-[#D8E7D8] text-[#386B39] flex items-center justify-center shadow-xs">
                  <Megaphone className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm sm:text-base font-black text-slate-900">Announcements &amp; Notices</h2>
                  <p className="text-[11px] text-slate-500">
                    Broadcasts and alerts from administration and your trade instructor
                  </p>
                </div>
              </div>

              {/* Filter Chips */}
              <div className="flex items-center space-x-2 text-xs">
                <button
                  onClick={() => setNotifFilter('all')}
                  className={`px-3 py-1.5 rounded-full font-bold transition-all cursor-pointer ${
                    notifFilter === 'all'
                      ? 'bg-[#386B39] text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  All ({notifications.length})
                </button>
                <button
                  onClick={() => setNotifFilter('broadcast')}
                  className={`px-3 py-1.5 rounded-full font-bold transition-all cursor-pointer ${
                    notifFilter === 'broadcast'
                      ? 'bg-[#386B39] text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Broadcasts
                </button>
                <button
                  onClick={() => setNotifFilter('personal')}
                  className={`px-3 py-1.5 rounded-full font-bold transition-all cursor-pointer ${
                    notifFilter === 'personal'
                      ? 'bg-[#386B39] text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Personal Alerts
                </button>
              </div>

              {filteredNotifs.length === 0 ? (
                <EmptyStateView
                  icon={<Megaphone className="w-8 h-8" />}
                  title="No Announcements"
                  subtitle="Broadcasts and notifications will appear here."
                />
              ) : (
                <div className="space-y-3">
                  {filteredNotifs.map((notif) => (
                    <div key={notif.notificationId} className="bg-white p-4 rounded-2xl border border-slate-200/80 space-y-2 shadow-xs">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="text-xs sm:text-sm font-black text-slate-900">{notif.title}</h4>
                          <span className="text-[10px] text-slate-400 font-medium">
                            {notif.senderName} • {DateUtils.formatDateTime(notif.timestamp)}
                          </span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold shrink-0 ${
                            notif.targetUserId ? 'bg-[#9C6800]/15 text-[#9C6800]' : 'bg-[#386B39]/15 text-[#386B39]'
                          }`}
                        >
                          {notif.targetUserId ? 'PERSONAL ALERT' : 'TRADE BROADCAST'}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 font-medium leading-relaxed">
                        {notif.message}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Punch Confirmation Modal */}
      {showPunchConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 sm:p-6 max-w-sm w-full shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center space-x-2.5 text-[#386B39] font-black text-sm">
              <Clock className="w-5 h-5" />
              <h3>Confirm GPS Punch {showPunchConfirm === 'in' ? 'In' : 'Out'}</h3>
            </div>
            
            <p className="text-slate-600 font-medium leading-relaxed">
              Are you sure you want to log your attendance punch-{showPunchConfirm === 'in' ? 'in' : 'out'} at this time? Your precise GPS location will be verified against the ITI campus boundary.
            </p>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowPunchConfirm(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold cursor-pointer transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  const mode = showPunchConfirm;
                  setShowPunchConfirm(null);
                  if (mode === 'in') {
                    await handlePunchIn();
                  } else {
                    await handlePunchOut();
                  }
                }}
                className="px-5 py-2 rounded-xl bg-[#386B39] hover:bg-[#2e592f] text-white font-bold shadow-md cursor-pointer transition-all"
              >
                Confirm Punch
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Developer Credit Footer */}
      <DeveloperCreditFooter />
    </div>
  );
};
