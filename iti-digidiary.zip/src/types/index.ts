export type UserRole = 'admin' | 'instructor' | 'trainee' | 'parent';

export type AccountStatus = 'pending' | 'approved' | 'rejected' | 'inactive' | 'deactivated';

export type AttendanceStatusType = 'present' | 'late' | 'absent' | 'half_day' | 'leave' | 'not_marked';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: string;
  status: string;
  createdAt?: number;
  updatedAt?: number;
}

export interface AdminProfile {
  uid: string;
  name: string;
  email: string;
  role: 'admin';
  status: 'approved';
  createdAt?: number;
}

export interface InstructorProfile {
  uid: string;
  name: string;
  email: string;
  contact: string;
  tradeId: string;
  tradeName: string;
  role: 'instructor';
  status: string; // 'pending' | 'approved' | 'inactive'
  createdAt?: number;
  updatedAt?: number;
  approvedAt?: number;
  approvedBy?: string;
  tempPassword?: string;
}

export interface TraineeProfile {
  uid: string;
  traineeId: string; // e.g. "ITI-2026-00001" or "PENDING"
  name: string;
  parentage: string;
  guardianContact: string;
  email: string;
  contact: string;
  address: string;
  tradeId: string;
  tradeName: string;
  instructorId: string;
  instructorName: string;
  role: 'trainee';
  status: string; // 'pending' | 'approved' | 'inactive' | 'deactivated' | 'rejected'
  rejectionReason?: string;
  parentAccessPin: string; // 4-digit PIN e.g. "1234"
  createdAt?: number;
  updatedAt?: number;
  approvedAt?: number;
  approvedBy?: string;
  tempPassword?: string;
}

export interface Trade {
  tradeId: string;
  tradeName: string;
  tradeCode: string;
  scheme: string; // 'CTS', 'Self Finance', 'PMKVY', 'Other'
  duration: string; // '1 Year', '2 Years', etc.
  totalSeats?: number;
  description?: string;
  status: 'active' | 'inactive';
  createdAt?: number;
  updatedAt?: number;
}

export interface AttendanceRecord {
  attendanceId: string;
  traineeId: string; // User UID
  traineeUniqueId: string; // Formatted ID e.g. ITI-2026-00001
  traineeName: string;
  tradeId: string;
  tradeName: string;
  instructorId: string;
  date: string; // YYYY-MM-DD
  punchInTime?: number | null;
  punchOutTime?: number | null;
  punchInLatitude?: number | null;
  punchInLongitude?: number | null;
  punchOutLatitude?: number | null;
  punchOutLongitude?: number | null;
  punchInDistance?: number | null;
  punchOutDistance?: number | null;
  attendanceStatus: string; // 'present' | 'late' | 'absent' | 'half_day' | 'leave' | 'not_marked'
  remarks?: string | null;
  createdAt?: number;
  updatedAt?: number;
}

export interface Holiday {
  id: string; // unique id e.g. "hol_2026-09-15"
  date: string; // YYYY-MM-DD
  title: string; // e.g. "Republic Day", "Eid", "Independence Day"
  description?: string;
  createdAt?: number;
  createdBy?: string;
}

export interface InstituteSettings {
  settingsId: string;
  instituteName: string;
  instituteAddress: string;
  latitude: number;
  longitude: number;
  radiusMeters: number; // default 100m
  reportingTime: string; // "09:00"
  lateTimeThreshold: string; // "09:15"
  workingDays: string[];
  holidays?: Holiday[];
  gracePeriodMinutes?: number;
  shift1Timing?: string;
  shift2Timing?: string;
  cutoffTime?: string;
  updatedAt?: number;
  updatedBy?: string;
}

export interface AttendanceCorrection {
  correctionId: string;
  attendanceId: string;
  traineeId: string;
  traineeUniqueId: string;
  traineeName: string;
  date: string;
  correctedBy: string;
  correctedByName: string;
  correctedByRole: string;
  oldValue: string;
  newValue: string;
  reason: string;
  timestamp: number;
}

export interface InstituteNotification {
  notificationId: string;
  title: string;
  message: string;
  targetRole: string; // 'all' | 'both' | 'instructor' | 'trainee' | 'parent' | 'admin'
  targetTradeId?: string | null;
  targetUserId?: string | null;
  senderName: string;
  senderRole?: string | null; // 'admin' | 'instructor'
  senderUserId?: string | null;
  timestamp: number;
  isRead?: boolean;
}

export interface AuditLogEntry {
  logId: string;
  action: string;
  actionType?: string;
  description?: string;
  performedBy: string;
  performedByName: string;
  performedByRole: string;
  targetId: string;
  targetType: string;
  oldValue?: string | null;
  newValue?: string | null;
  reason?: string | null;
  timestamp: number;
}

export interface DashboardStats {
  totalTrades: number;
  totalInstructors: number;
  totalTrainees: number;
  presentToday: number;
  absentToday: number;
  lateToday: number;
  pendingTraineeApprovals: number;
  pendingInstructorRegistrations: number;
  attendancePercentage: number;
}

export interface DistanceResult {
  distanceMeters: number;
  isWithinRadius: boolean;
  currentLat: number;
  currentLng: number;
  instituteLat: number;
  instituteLng: number;
  allowedRadiusMeters: number;
  statusMessage: string;
}

export interface DiaryNote {
  noteId: string;
  traineeId: string;
  traineeName: string;
  tradeId: string;
  tradeName: string;
  instructorId: string;
  instructorName: string;
  title: string;
  content: string;
  timestamp: number;
  dateString: string;
}

export interface TradeAttendanceStat {
  trade: Trade;
  totalTrainees: number;
  presentTrainees: number;
  lateTrainees: number;
  absentTrainees: number;
  percentage: number;
  assignedInstructorName: string;
}
